package MDSSED.utils;

import java.util.List;

public class Device {
	private String device;
	private List<Attribute> attrs;

	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public List<Attribute> getAttrs() {
		return attrs;
	}
	public void setAttrs(List<Attribute> attrs) {
		this.attrs = attrs;
	}

}
