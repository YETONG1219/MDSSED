package MDSSED.utils;

import java.util.ArrayList;
import java.util.List;

import MDSSED.utils.Attribute;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.Transition;

public class GenNotSatisfy {
	//T7:��������������㣩����
	public static String main( BehaviourStateMachine umlModel,  List<Device> devices) {
		   //umlModel��ȡUMLģ��,devices��ȡ�豸���Կ��ܵ�ֵ
		   String threat = "";
		   List<Transition> trans = umlModel.getTrans();
		   List<DeviceAttrValue> vars = genVars(trans,devices);
			List<String> VARList = new ArrayList<String>();
			String VAR = "";//ģ��ı���
			//����VAR---������condition����
			if(devices!=null && devices.size()>0) {
				for(Device device:devices) {
					String dName = device.getDevice().replace(" ","");
					dName = toLowerCaseFirstOne(dName);
					List<Attribute> attrs =device.getAttrs();
					if(attrs != null && attrs.size()>0) {
						for(Attribute attr:attrs) {
							String aName = attr.getAttr().replace(" ", "");						
							if(vars!=null && vars.size()>0) {
								for(DeviceAttrValue v:vars) {
									if(v.getDevice().equals(dName) && v.getAttribute().equals(aName) && !VARList.contains(dName + "_" + aName)) {
										//��������д��ڸ��豸���ԣ��ͼ������
										VARList.add(dName + "_" + aName);
										VAR = VAR + "\t" + dName + "_" + aName + " :{";
										List<String> values = attr.getValues();
										if(values!=null && values.size()>0) {
											for(String value:values) {
												if(v.getTrueOrFalse().equals("==") && !value.equals(v.getValue()))
													VAR = VAR + value + ", ";
												if(v.getTrueOrFalse().equals("!=") && value.equals(v.getValue()))
													VAR = VAR + value + ", ";
											}
											VAR = VAR.substring(0,VAR.length() - 2);//ɾ������ġ��� ��
											VAR = VAR + "};\r\n";											
										} 
									}
								}

							}
						}
					}
				}
			}
			if(!VAR.equals("")) {
				VAR = "VAR\r\n" + VAR;
				threat = "MODULE threat7\r\n" + VAR;
			}
		   
		   System.out.println("-------threat7-------\r\n" + threat);
		return threat;
	}
	public static List<DeviceAttrValue> genVars(List<Transition> trans, List<Device> devices) {
		//���������а����ı���
		List<DeviceAttrValue> vars = new ArrayList<DeviceAttrValue>();
		if(trans!=null && trans.size()>0) {
			for(Transition tran:trans) {
				if(satThreatOccurCondition(tran)) {
					List<Condition> cons = tran.getConditions();
					if(cons!=null && cons.size()>0) {
						for(Condition con:cons) {
							DeviceAttrValue DAV = con.getDeviceAttrValue();
							vars.add(DAV);
						}
					}					
				}
			}
		}
		return vars;
	}
	
	public static boolean satThreatOccurCondition(Transition tran) {
		//����T7�ķ�����������app��condition��ĳ���豸�����ԣ�����condition��ִ��action��
		if(tran.getConditions()!=null && tran.getActions()!=null)
			return true;
		return false;
	}
	//����ĸתСд
	public static String toLowerCaseFirstOne(String s)
	{
	  if(Character.isLowerCase(s.charAt(0)))
	      return s;
	  else
	      return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0))).append(s.substring(1)).toString();
	}
}
