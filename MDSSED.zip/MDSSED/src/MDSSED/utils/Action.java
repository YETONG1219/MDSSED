package MDSSED.utils;

import java.util.ArrayList;
import java.util.List;


public class Action {
	private String action;
	private String commandDevice;
	private String command;
	private List<String> commandArgs;


	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCommandDevice() {
		return commandDevice;
	}
	public void setCommandDevice(String commandDevice) {
		this.commandDevice = commandDevice;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public List<String> getCommandArgs() {
		return commandArgs;
	}
	public void setCommandArgs(List<String> commandArgs) {
		this.commandArgs = commandArgs;
	}
	public void init(String action) {
		String message = "";
		if(action.contains("runIn")) {
			String s1[] = action.split(", ");
			action = s1[1];
			action = action.substring(0,action.length() - 1);
		}
		if(action.contains("sendSms")) {
			String s1[] = action.split(", ");
			message = s1[1];
			message = action.substring(0,action.length() - 1);
			setCommandDevice("phone");
			setCommand("sendSms");
			List<String> commandArgs = new ArrayList<String>();
		    commandArgs.add(message);
			setCommandArgs(commandArgs);

		}
		else {
			String[] s = action.split("\\.");
			if(s!=null && s.length>0) {
				setCommandDevice(s[0]);
				s = s[1].split("\\(");
				if(s!=null && s.length>0) {
					setCommand(s[0]);
					s = s[1].split("\\)");
					if(s!=null && s.length>0) {
						List<String> commandArgs = new ArrayList<String>();
						for(String arg:s) {
							commandArgs.add(arg);
						}
						setCommandArgs(commandArgs);
					}
				}
			}
		}
	}
}