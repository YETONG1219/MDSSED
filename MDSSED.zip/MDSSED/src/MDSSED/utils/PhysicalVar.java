package MDSSED.utils;

import java.util.List;
public class PhysicalVar {
	private String name;
	private String type;
	private List<String> enumerationValues;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type=type;
	}
	public List<String> getEnumerationValues() {
		return enumerationValues;
	}
	public void setenumerationValues(List<String> enumerationValues) {
		this.enumerationValues=enumerationValues;
	}

}
