package MDSSED.utils;

import java.util.List;
//�����е����������ͣ��������֣����ͺ�ֵ��ֵ������ö�����ͣ����ͣ������ͻ��ַ�������
public class PhysicalVar {
	private String name;
	private String type;
	private List<String> enumerationValues;
//	private int intValue;
//	private float floatValue;
//	private String stringValue; 


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type=type;
	}
	public List<String> getEnumerationValues() {
		return enumerationValues;
	}
	public void setenumerationValues(List<String> enumerationValues) {
		this.enumerationValues=enumerationValues;
	}
//	public int getIntValue() {
//		return intValue;
//	}
//	public void setIntValue(int intValue) {
//		this.intValue=intValue;
//	}
//	public float getFloatValue() {
//		return floatValue;
//	}
//	public void setFloatValue(float floatValue) {
//		this.floatValue=floatValue;
//	}
//	public String getStringValue() {
//		return stringValue;
//	}
//	public void setStringValue(String stringValue) {
//		this.stringValue=stringValue;
//	}

}
