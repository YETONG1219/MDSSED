package MDSSED.utils;

import java.util.List;

public class Attribute {
	private String attr;
	private List<String> values;


	public String getAttr() {
		return attr;
	}
	public void setAttr(String attr) {
		this.attr = attr;
	}
		
	public List<String> getValues() {
		return values;
	}
	public void setValues(List<String> values) {
		this.values=values;
	}
//	public int getIntValue() {
//		return intValue;
//	}
//	public void setIntValue(int intValue) {
//		this.intValue=intValue;
//	}
//	public float getFloatValue() {
//		return floatValue;
//	}
//	public void setFloatValue(float floatValue) {
//		this.floatValue=floatValue;
//	}
//	public String getStringValue() {
//		return stringValue;
//	}
//	public void setStringValue(String stringValue) {
//		this.stringValue=stringValue;
//	}

}
