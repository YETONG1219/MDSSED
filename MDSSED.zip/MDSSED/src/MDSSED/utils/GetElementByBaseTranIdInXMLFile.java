package MDSSED.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;



public class GetElementByBaseTranIdInXMLFile {

	public static List<Element> getElement(String id, String fileName) throws DocumentException{

    	   File xmlFile = new File(fileName);
    	   SAXReader sax = new SAXReader();
    	   Document document = sax.read(xmlFile);
    	   Element root = document.getRootElement();
    	   List<Element> element = new ArrayList<Element>(); 
    	   element = GetElementByBaseTranIdInXMLFile.getNodes(id,root,element,fileName);

       
   	return element;
	}


public static List<Element> getNodes(String id,Element node,List<Element> element,String fileName) {



	if( node.attributeValue("base_Transition")!=null&&node.attributeValue("base_Transition").equals(id)) {
		element.add(node);
	}

    List<Element> listElement = node.elements();
    for (Element e : listElement) {
    	element = getNodes(id,e,element,fileName);
    }
	return  element;   
}	
}
