package MDSSED.utils;

public class Trigger {
	private String trigger;
	private DeviceAttrValue deviceAttrValue;
	public String getTrigger() {
		return trigger;
	}
	public void setTrigger(String trigger) {
		this.trigger = trigger;
	}
	public DeviceAttrValue getDeviceAttrValue() {
		return deviceAttrValue;
	}
	public void setDeviceAttrValue(DeviceAttrValue deviceAttrValue) {
		this.deviceAttrValue = deviceAttrValue;
	}
	
	public void init(String trigger) {
		trigger = trigger.replace(" ", "");//ɾ���ո�
		trigger = trigger.replace("&quot;", "");//ɾ������
		trigger = trigger.replace("\"", "");//ɾ������
		DeviceAttrValue deviceAttrValue = new DeviceAttrValue();
		String trueOrFalse = "";
		String[] s = trigger.split("\\.");
		if(s!=null && s.length>0) {
			deviceAttrValue.setDevice(s[0]);
			if(s[1].contains("=="))
				trueOrFalse = "==";
			if(s[1].contains("!="))
				trueOrFalse = "!=";
			deviceAttrValue.setTrueOrFalse(trueOrFalse); 
			if(s[1].contains(trueOrFalse)) {
				s = s[1].split(trueOrFalse);
				if(s[0]!=null && s[0].length()>0) {
					deviceAttrValue.setAttribute(s[0]);
				}
				if(s[1]!=null && s[1].length()>0) {
					deviceAttrValue.setValue(s[1]);					
				}
			}
		}
		this.deviceAttrValue = deviceAttrValue;
	}
}