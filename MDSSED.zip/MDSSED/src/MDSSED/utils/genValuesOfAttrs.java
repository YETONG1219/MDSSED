package MDSSED.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class genValuesOfAttrs {
	public static List <Device> gen(String capabilityFile) throws IOException{

//	public static void main(String[] Arg) throws IOException{
//		   String capabilityFile = "D:\\NuSMV-2.6.0-win64\\NuSMV-2.6.0-win64\\bin\\capabilities.txt"; 
//		   String preferencesFile = "D:\\NuSMV-2.6.0-win64\\NuSMV-2.6.0-win64\\bin\\preferences.txt";
//		   String fileContent = "";
		   List<Device> devices = new ArrayList<Device>();
		   devices = readFile(capabilityFile);
		   if(devices!=null && devices.size()>0) {
			   for(Device device:devices) {
//				System.out.println("-------device------" +device.getDevice());
				List<Attribute> attrs = device.getAttrs();
				if(attrs!=null && attrs.size()>0) {
					for(Attribute attr:attrs) {
//						System.out.println("		attr:" + attr.getAttr());
						List<String> values = attr.getValues();
						if(values!=null && values.size()>0) {
//							System.out.println("		value:");
							for(String v:values) {
//								System.out.println("		" +v);
							}
						}
					}
				}				
			   }
		   }
		   return devices;

	}

  public static List<Device> readFile(String fileName) throws IOException  {
	   //���ж�ȡ�ļ�
		FileInputStream inputStream = new FileInputStream(fileName);
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			
		List<Device> dList = new ArrayList<Device>();
		String str = null;
		Device device = null;
		List<Attribute> attrs = null;
		Attribute attr = null;
		List<String> values = null;
		int flag = 0; //1��ʾ��ʼ���豸��2��ʾ�����ԣ�3��ʾ��ʼ�����Ե�ֵ��4��ʾ���ڶ����Ե�ֵ��0��ʾ������ȡһ���豸����������
		boolean isEnum = false;
		while((str = bufferedReader.readLine()) != null)
		{
//			System.out.println(str);
			if(flag == 4 ) {
				if(str.contains("-")) {
					str.replace("-", "");
					str.replace(" ", "");
					str.replace("'", "");
					values.add(str);
//					System.out.println("����ֵ"+str);
				}
				else {
					attr.setValues(values);
					attrs.add(attr);
					flag = 2;

				}
			}
			if(flag == 3 && str.contains("commands") && isEnum == false) {
				flag = 0;
			}
			if(flag == 3 && str.contains("type: ENUM")) {
				isEnum = true;
			}
			if(flag == 3 && (str.contains("minimum"))) {
				values = new ArrayList<String>();
				values.add(str);
//				System.out.println("��������ֵ"+str);
				flag = 3 ;
			}
			if(flag == 3 && str.contains("maximum")) {
				values.add(str);
//				System.out.println("��������ֵ"+str);
				flag = 3 ;
				attr.setValues(values);
				attrs.add(attr);
				flag = 2;
			}
			if(flag == 3 && str.contains("values:")) {
				if(isEnum == true) {
					values = new ArrayList<String>();
					flag = 4;					
				}
				else {
					flag = 0;
				}
			}
		
			if(flag == 2) {
				if(!str.equals("") && str.substring(0,2).equals("  ") && str.substring(2,3).equals(" ")==false) {
					str = str.replace(":", "");
					attr = new Attribute();
					attr.setAttr(str);
					isEnum = false;
					flag = 3;					
				}
				else {
					flag = 0;
					device.setAttrs(attrs);
//					System.out.println("��������");	

					dList.add(device);
//					System.out.println("�����豸��" + device.getDevice());	

				}
			}
			if(flag == 1 && str.contains("attributes:")) {
				if(!str.contains("attributes: {")) {
					//���Բ�Ϊ��
//					System.out.println("contain attrs");
					attrs = new ArrayList<Attribute>();
//					new ArrayList<String>()
					flag = 2;					
				}
				else {
					flag = 0;
				}

			}
			if((flag == 0 ||(flag == 3 && isEnum == false)) && str.contains("name:") && (str.contains("- name:")==false) ) {
				device = new Device();
				device.setDevice(str.split(": ")[1]);
//				System.out.println("�����豸��" + device.getDevice());
				flag = 1;
				isEnum = false;
			}
		}
		//close
		inputStream.close();
		bufferedReader.close();
		return dList;
  }
}
