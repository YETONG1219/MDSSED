package MDSSED.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class genValuesOfAttrs {
	public static List <Device> gen(String capabilityFile) throws IOException{

		   List<Device> devices = new ArrayList<Device>();
		   devices = readFile(capabilityFile);
		   return devices;

	}

  public static List<Device> readFile(String fileName) throws IOException  {
		FileInputStream inputStream = new FileInputStream(fileName);
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			
		List<Device> dList = new ArrayList<Device>();
		String str = null;
		Device device = null;
		List<Attribute> attrs = null;
		Attribute attr = null;
		List<String> values = null;
		int flag = 0; 
		/*flag = 1 : start reading the device, 
		flag = 2 : read the attribute, 
		flag = 3 : start reading the value of the attribute, 
		flag = 4 : the value of the attribute is being read, 
		flag = 0 : end reading all attributes of a device.*/
		boolean isEnum = false;
		while((str = bufferedReader.readLine()) != null)
		{
//			System.out.println(str);
			if(flag == 4 ) {
				if(str.contains("-")) {
					str.replace("-", "");
					str.replace(" ", "");
					str.replace("'", "");
					values.add(str);
//					System.out.println("add the value:"+str);
				}
				else {
					attr.setValues(values);
					attrs.add(attr);
					flag = 2;

				}
			}
			if(flag == 3 && str.contains("commands") && isEnum == false) {
				flag = 0;
			}
			if(flag == 3 && str.contains("type: ENUM")) {
				isEnum = true;
			}
			if(flag == 3 && (str.contains("minimum"))) {
				values = new ArrayList<String>();
				values.add(str);
				flag = 3 ;
			}
			if(flag == 3 && str.contains("maximum")) {
				values.add(str);
				flag = 3 ;
				attr.setValues(values);
				attrs.add(attr);
				flag = 2;
			}
			if(flag == 3 && str.contains("values:")) {
				if(isEnum == true) {
					values = new ArrayList<String>();
					flag = 4;					
				}
				else {
					flag = 0;
				}
			}
		
			if(flag == 2) {
				if(!str.equals("") && str.substring(0,2).equals("  ") && str.substring(2,3).equals(" ")==false) {
					str = str.replace(":", "");
					attr = new Attribute();
					attr.setAttr(str);
					isEnum = false;
					flag = 3;					
				}
				else {
					flag = 0;
					device.setAttrs(attrs);
//					System.out.println("set the attribute");	

					dList.add(device);
//					System.out.println("add the device��" + device.getDevice());	

				}
			}
			if(flag == 1 && str.contains("attributes:")) {
				if(!str.contains("attributes: {")) {
					attrs = new ArrayList<Attribute>();
					flag = 2;					
				}
				else {
					flag = 0;
				}

			}
			if((flag == 0 ||(flag == 3 && isEnum == false)) && str.contains("name:") && (str.contains("- name:")==false) ) {
				device = new Device();
				device.setDevice(str.split(": ")[1]);
				flag = 1;
				isEnum = false;
			}
		}
		inputStream.close();
		bufferedReader.close();
		return dList;
  }
}
