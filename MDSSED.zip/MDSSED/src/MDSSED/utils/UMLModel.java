package MDSSED.utils;

import java.util.List;

public class UMLModel {
	private List<Transition> trans;//List of transitions
	private List<State> states;//List of states



	public List<Transition> getTransitions() {
		return trans;
	}
	public void setTransitions(List<Transition> trans) {
		this.trans = trans;
	}
	public List<State> getStates() {
		return states;
	}
	public void setStates(List<State> states) {
		this.states = states;
	}


}