package MDSSED.utils;

public class Condition {
	private String condition;
	private DeviceAttrValue deviceAttrValue;
	private String conForVerif;
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public DeviceAttrValue getDeviceAttrValue() {
		return deviceAttrValue;
	}
	public void setDeviceAttrValue(DeviceAttrValue deviceAttrValue) {
		this.deviceAttrValue = deviceAttrValue;
	}
	public void init(String condition) {
		if(!condition.contains("now()")) {
			condition = condition.replace(" ", "");
			condition = condition.replace("&quot;", "");
			condition = condition.replace("\"", "");
	
			DeviceAttrValue deviceAttrValue = new DeviceAttrValue();
			String trueOrFalse = "";
			String[] s = condition.split("\\.");
			if(s!=null && s.length>0) {
				deviceAttrValue.setDevice(s[0]);
				if(s[1].contains("=="))
					trueOrFalse = "==";
				if(s[1].contains("!="))
					trueOrFalse = "!=";
				deviceAttrValue.setTrueOrFalse(trueOrFalse);
				if(s[1].contains(trueOrFalse)) {
					s = s[1].split(trueOrFalse);
					if(s[0]!=null && s[0].length()>0) {
						deviceAttrValue.setAttribute(s[0]);
					}
					if(s[1]!=null && s[1].length()>0) {
						deviceAttrValue.setValue(s[1]);					
					}
				}
			}
			this.deviceAttrValue = deviceAttrValue;
		}
	}
}