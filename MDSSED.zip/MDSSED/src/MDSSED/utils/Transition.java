package MDSSED.utils;

import java.util.List;

public class Transition {
	private State source;
	private State target;
	private List<Trigger> triggers;
	private List<Condition> conditions;
	private List<Action> actions;


	public State getSource() {
		return source;
	}
	public void setSource(State source) {
		this.source = source;
	}
	public State getTarget() {
		return target;
	}
	public void setTarget(State target) {
		this.target = target;
	}
	public List<Trigger> getTriggers() {
		return triggers;
	}
	public void setTrigger(List<Trigger> triggers) {
		this.triggers = triggers;
	}
	public List<Condition> getConditions() {
		return conditions;
	}
	public void setCondition(List<Condition> conditions) {
		this.conditions = conditions;
	}
	public List<Action> getActions() {
		return actions;
	}
	public void setActions(List<Action> actions) {
		this.actions = actions;
	}

}