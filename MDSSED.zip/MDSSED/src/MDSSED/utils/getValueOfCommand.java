package MDSSED.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class getValueOfCommand {

  public static String getValue(String fileName, String device, String command) throws IOException  {
	   //��ȡ�������õ�ֵ
	    String value = "";
		FileInputStream inputStream = new FileInputStream(fileName);
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			
		String str = null;
		int flag = 0; //0��ʾ��ʼ���豸��1��ʾ�������2��ʾ��ʼ���������ü���ֵ,3��ʾ����
		while((str = bufferedReader.readLine()) != null)
		{
		
			if(flag == 3)
				break;
			if(flag == 2) {
				if(str.contains("value:")) {
					value = str.split("value: ")[1];
					flag = 3;
				}
			}
			if(flag == 1) {
				if(str.contains("command") && str.contains(command)) {
					flag = 2;
				}

			}
			if(flag == 0  && str.contains("name:") && (str.contains("- name:")==false) ) {
				String dName = str.split(": ")[1];
				dName = dName.replace(" ", "");
//				System.out.println("�����豸��" + dName);
				if(device.equalsIgnoreCase(dName)) {
//					System.out.println("�ҵ�Ŀ���豸��" + dName);
					flag = 1;
				}
			}
		}
		//close
		inputStream.close();
		bufferedReader.close();
		return value;
  }
}
