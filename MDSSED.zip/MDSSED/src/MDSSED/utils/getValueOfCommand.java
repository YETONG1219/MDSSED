package MDSSED.utils;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;


public class getValueOfCommand {

  public static String getValue(String fileName, String device, String command) throws IOException  {
	    String value = "";
		FileInputStream inputStream = new FileInputStream(fileName);
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			
		String str = null;
		int flag = 0; /*1 means start reading the device, 2 means read the attribute,
		3 means start reading the value of the attribute, 4 means the value of the attribute is being read, 
		and 0 means end reading all attributes of a device*/
		while((str = bufferedReader.readLine()) != null)
		{
		
			if(flag == 3)
				break;
			if(flag == 2) {
				if(str.contains("value:")) {
					value = str.split("value: ")[1];
					flag = 3;
				}
			}
			if(flag == 1) {
				if(str.contains("command") && str.contains(command)) {
					flag = 2;
				}

			}
			if(flag == 0  && str.contains("name:") && (str.contains("- name:")==false) ) {
				String dName = str.split(": ")[1];
				dName = dName.replace(" ", "");
				if(device.equalsIgnoreCase(dName)) {
					flag = 1;
				}
			}
		}

		inputStream.close();
		bufferedReader.close();
		return value;
  }
}
