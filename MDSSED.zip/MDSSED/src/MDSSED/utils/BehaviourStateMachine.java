package MDSSED.utils;

import java.util.List;

public class BehaviourStateMachine {
	private String name;
	private List<State> initStates;
	private List<State> states;
	private List<Transition> trans;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<State> getInitStates() {
		return initStates;
	}
	public void setInitStates(List<State> initStates) {
		this.initStates = initStates;
	}
	public List<State> getStates() {
		return states;
	}
	public void setStates(List<State> states) {
		this.states = states;
	}
	public List<Transition> getTrans() {
		return trans;
	}
	public void setTrans(List<Transition> trans) {
		this.trans = trans;
	}
}