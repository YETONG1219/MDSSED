package MDSSED.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;



public class GetElementByEnumTypeName {
	public static Element getElement(String name, String fileName) throws DocumentException{

    	   File xmlFile = new File(fileName);
    	   SAXReader sax = new SAXReader();
    	   Document document = sax.read(xmlFile);
    	   Element root = document.getRootElement();
    	   Element element = GetElementByEnumTypeName.getNodes(name,root,null,fileName);

       
   	return element;
	}


public static Element getNodes(String name,Element node,Element element,String fileName) {

	if(node.attributeValue("type")!=null && node.attributeValue("type").equals("uml:Enumeration")) {
		if( node.attributeValue("name")!=null&&node.attributeValue("name").equals(name)) {
			element = node;
		}
	}

    List<Element> listElement = node.elements();
    for (Element e : listElement) {
    	element = getNodes(name,e,element,fileName);
    }
	return  element;   
}	
}
