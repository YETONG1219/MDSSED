package MDSSED.utils;

import java.util.List;

import org.dom4j.DocumentException;
import org.w3c.dom.Element;


public class ClassStereotype {
	private String baseClassName;//Ӧ�ù����͵��������
	private String baseClassId;//Ӧ�ù����͵����ID
	private String stereotypeName;//Ӧ�õĹ�������
//	private List<Property> properties;//�����͵�����(��������ֵ)

	public String getBaseClassID() {
		return baseClassId;
	}
	public void setBaseClassID(String baseClassId) {
		this.baseClassId = baseClassId;
	}
	public String getBaseClassName() {
		return baseClassName;
	}
	public void setBaseClassName(String baseClassName) {
		this.baseClassName = baseClassName;
	}
	public String getStereotypeName() {
		return stereotypeName;
	}
	public void setStereotypeName(String stereotypeName) {
		this.stereotypeName = stereotypeName;
	}
	
//	public List<Property> getProperties() {
//		return properties;
//	}
//	public void setProperites(List<Property> properties) {
//		this.properties=properties;
//	}
	public void setClassNameByClassId(String XMLFileName) throws DocumentException {
		org.dom4j.Element e =  GetElementByIdInXMLFile.getElement(this.getBaseClassID(),XMLFileName);
		baseClassName = e.attributeValue("name");
	}
}