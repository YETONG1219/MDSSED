package MDSSED.utils;


public class DeviceAttrValue {
	private String device;
	private String attribute;
	private String value;
	private String trueOrFalse;

	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getAttribute() {
		return attribute;
	}
	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}
	public String getValue() {
		return value;
	}	
	public void setValue(String value) {
		this.value = value;
	}
	public String getTrueOrFalse() {
		return trueOrFalse;
	}
	public void setTrueOrFalse(String trueOrFalse) {
		this.trueOrFalse = trueOrFalse;
	}
}