package MDSSED.utils;

import java.util.ArrayList;
import java.util.List;

public class State {
	private String state;
	private List<String> deviceStates;
	private List<DeviceAttrValue> deviceAttrValues;
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<String> getDeviceStates() {
		return deviceStates;
	}
	public void setDeviceStates(List<String> deviceStates) {
		this.deviceStates = deviceStates;
	}
	public List<DeviceAttrValue> getDeviceAttrValues() {
		return deviceAttrValues;
	}
	public void setDeviceAttrValues(List<DeviceAttrValue> deviceAttrValues) {
		this.deviceAttrValues = deviceAttrValues;
	}
	
	public List<DeviceAttrValue> init(List<String> deviceStates) {
		setDeviceStates(deviceStates);
		List<DeviceAttrValue> deviceAttrValues =new ArrayList <DeviceAttrValue>();
		if(deviceStates!=null && deviceStates.size()>0) {
			for(String deviceState:deviceStates) {
				if(!(deviceState.contains("now()") || deviceState.contains("time"))) {
	//				System.out.println("Class State: initState----------" + deviceState);
					deviceState = deviceState.replace(" ", "");
					deviceState = deviceState.replace("&quot;", "");
					deviceState = deviceState.replace("\"", "");
	
					DeviceAttrValue deviceAttrValue = new DeviceAttrValue();
					String trueOrFalse = "";
					String[] s = deviceState.split("\\.");
					if(s!=null && s.length>0) {
						deviceAttrValue.setDevice(s[0]);
						if(s[1].contains("=="))
							trueOrFalse = "==";
						if(s[1].contains("!="))
							trueOrFalse = "!=";
						deviceAttrValue.setTrueOrFalse(trueOrFalse); 
						if(s[1].contains(trueOrFalse)) {
							s = s[1].split(trueOrFalse);
							if(s[0]!=null && s[0].length()>0) {
								deviceAttrValue.setAttribute(s[0]);
							}
							if(s[1]!=null && s[1].length()>0) {
								deviceAttrValue.setValue(s[1]);					
							}
						}	
					}
	//				System.out.println("Class State: initState----------" + deviceAttrValue.getDevice()+deviceAttrValue.getAttribute());
					deviceAttrValues.add(deviceAttrValue);
				}
			}
			setDeviceAttrValues(deviceAttrValues);
		}
		return deviceAttrValues;
	}
}