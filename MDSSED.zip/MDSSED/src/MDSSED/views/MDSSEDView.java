package MDSSED.views;


import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.*;

import MDSSED.handlers.UML2Groovy;
import MDSSED.handlers.Verify;

import MDSSED.utils.XMLFileFilter;


import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.dom4j.DocumentException;

//import org.dom4j.DocumentException;

import org.eclipse.ui.*;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.swing.JFileChooser;
import javax.swing.JFrame;


/**
 * This sample class demonstrates how to plug-in a new
 * workbench view. The view shows data obtained from the
 * model. The sample creates a dummy model on the fly,
 * but a real implementation would connect to the model
 * available either in this or another plug-in (e.g. the workspace).
 * The view is connected to the model using a content provider.
 * <p>
 * The view uses a label provider to define how model
 * objects should be presented in the view. Each
 * view can present the same model objects using
 * different labels and icons, if needed. Alternatively,
 * a single label provider can be shared between views
 * in order to ensure that objects of the same type are
 * presented in the same way everywhere.
 * <p>
 */

public class MDSSEDView extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "MDSSED.views.MDEESDView";

	@Inject IWorkbench workbench;
	@Override
	public void createPartControl(Composite parent) {

		try {
			todo(parent);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void todo(Composite parent) throws DocumentException{
		TabFolder tabFolder = new TabFolder(parent,SWT.BORDER);

        TabItem tabItem1 = new TabItem(tabFolder,SWT.NONE);
        tabItem1.setText("MDSSED Verification");
        TabItem tabItem2 = new TabItem(tabFolder,SWT.NONE);
        tabItem2.setText("MDSSED Code Generation");
        Composite compsoite1 = new Composite(tabFolder,SWT.NONE|SWT.V_SCROLL);
        tabItem1.setControl(compsoite1);
        RowLayout layout = new RowLayout(SWT.VERTICAL);
        compsoite1.setLayout(layout);
			Label lable = new Label(compsoite1,1);
			lable.setLayoutData(new RowData(150, 40));
			lable.setText("Verification of Models:");
			Button btnChooseUMLFile = new Button(compsoite1, 1);
			btnChooseUMLFile.setLayoutData(new RowData(150, 40));
			btnChooseUMLFile.setText("Verify");
			Text text = new Text(compsoite1, SWT.WRAP|SWT.V_SCROLL);
			text.setBounds(150,150,1600,1800);
			text.setLayoutData(new RowData(1600, 1200));			
			btnChooseUMLFile.addSelectionListener(new SelectionAdapter() {
    			public void widgetSelected(SelectionEvent e) {
    				    text.setText("");

    					String  UMLFileName = "";
        				JFrame frame = new JFrame();
        				String dir = "E:\\papyrus\\MDSSED";

        				JFileChooser chooser = new JFileChooser();
        				chooser.setCurrentDirectory(new File(dir));
        				chooser.setDialogTitle("Choose UML model"); 	
        			    XMLFileFilter xmlFilter = new XMLFileFilter();   
        			    chooser.addChoosableFileFilter(xmlFilter);
        			    chooser.setFileFilter(xmlFilter);
        			

        				int flag = chooser.showOpenDialog(frame);
        				if (flag == JFileChooser.APPROVE_OPTION) {
        					System.out.println("Choose the file��" + chooser.getSelectedFile().getAbsolutePath());
        					UMLFileName = chooser.getSelectedFile().getAbsolutePath();
        				    try {
        				    	List<String> resultList = null;
        				    	long stime = System.currentTimeMillis();
        				    	resultList = Verify.main(UMLFileName);
        				    	long etime = System.currentTimeMillis();
        				        // Calculate execution time
        				        System.out.printf("Time cost for formal modeling and verification��%d ms.", (etime - stime));
        				    	if(resultList!=null && resultList.size()>0) {
        				    		for(String res:resultList) {
                		    			text.append(res);        				    			
        				    		}
        				    	}

							} catch (DocumentException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
        				}
    			}
    		});
		     Composite compsoite2 = new Composite(tabFolder,SWT.NONE|SWT.V_SCROLL);
		        tabItem2.setControl(compsoite2);
		        RowLayout layout2 = new RowLayout(SWT.VERTICAL);
		        compsoite2.setLayout(layout2);
					Label lable2= new Label(compsoite2,1);
					lable2.setLayoutData(new RowData(150, 40));
					lable2.setText("Code Generation:");
					Button btnChooseUMLFile2 = new Button(compsoite2, 1);
					btnChooseUMLFile2.setLayoutData(new RowData(150, 40));
					btnChooseUMLFile2.setText("Generate Code");
					Text text2 = new Text(compsoite2, SWT.WRAP|SWT.V_SCROLL);
					text2.setBounds(150,150,1600,1800);
					text2.setLayoutData(new RowData(1600, 1200));			
					btnChooseUMLFile2.addSelectionListener(new SelectionAdapter() {
		    			public void widgetSelected(SelectionEvent e) {
		    				    text2.setText("");
		    					String  UMLFileName = "";
		        				JFrame frame = new JFrame();
		        				String dir = "E:\\papyrus\\MDSSED";//UML file dictionary.

		        				JFileChooser chooser = new JFileChooser();
		        				chooser.setCurrentDirectory(new File(dir));
		        				chooser.setDialogTitle("Choose UML model"); 	
		        			    XMLFileFilter xmlFilter = new XMLFileFilter();   
		        			    chooser.addChoosableFileFilter(xmlFilter);
		        			    chooser.setFileFilter(xmlFilter);
		        			 
		        				int flag = chooser.showOpenDialog(frame);
		        				if (flag == JFileChooser.APPROVE_OPTION) {
		        					System.out.println("The chosen file is: " + chooser.getSelectedFile().getAbsolutePath());
		        					UMLFileName = chooser.getSelectedFile().getAbsolutePath();
		        				    try {
		        				    	long stime = System.currentTimeMillis();

		        				    	String resultList = "";
		        				    	resultList = UML2Groovy.main(UMLFileName);
		        				    	long etime = System.currentTimeMillis();
		        				        System.out.printf("Time cost for code generation��%d ms.", (etime - stime));
		                		    	text2.append(resultList);        				    			

									} catch (DocumentException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
		        				}
		    			}
		    		});
	}

	@Override
	public void setFocus() {
		
	}
}
