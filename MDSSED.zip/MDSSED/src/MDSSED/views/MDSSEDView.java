package MDSSED.views;


import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.*;

import MDSSED.handlers.UML2Groovy;
import MDSSED.handlers.UML2NuSMV;
import MDSSED.handlers.Verify;
import MDSSED.utils.Device;
import MDSSED.utils.UMLModel;
import MDSSED.utils.XMLFileFilter;

import org.eclipse.jface.viewers.*;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
//import org.dom4j.DocumentException;
import org.eclipse.jface.action.*;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.*;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileFilter;


/**
 * This sample class demonstrates how to plug-in a new
 * workbench view. The view shows data obtained from the
 * model. The sample creates a dummy model on the fly,
 * but a real implementation would connect to the model
 * available either in this or another plug-in (e.g. the workspace).
 * The view is connected to the model using a content provider.
 * <p>
 * The view uses a label provider to define how model
 * objects should be presented in the view. Each
 * view can present the same model objects using
 * different labels and icons, if needed. Alternatively,
 * a single label provider can be shared between views
 * in order to ensure that objects of the same type are
 * presented in the same way everywhere.
 * <p>
 */

public class MDSSEDView extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "MDSSED.views.MDEESDView";

	@Inject IWorkbench workbench;
	@Override
	public void createPartControl(Composite parent) {

		try {
			todo(parent);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void todo(Composite parent) throws DocumentException{
        String  UMLFileName = "";
		TabFolder tabFolder = new TabFolder(parent,SWT.BORDER);

        TabItem tabItem1 = new TabItem(tabFolder,SWT.NONE);
        tabItem1.setText("MDSSED Verification");
        TabItem tabItem2 = new TabItem(tabFolder,SWT.NONE);
        tabItem2.setText("MDSSED Code Generation");
        Composite compsoite1 = new Composite(tabFolder,SWT.NONE|SWT.V_SCROLL);
        tabItem1.setControl(compsoite1);
        RowLayout layout = new RowLayout(SWT.VERTICAL);
        compsoite1.setLayout(layout);
			Label lable = new Label(compsoite1,1);
			lable.setLayoutData(new RowData(150, 40));
			lable.setText("Verification of Models:");
			Button btnChooseUMLFile = new Button(compsoite1, 1);
			btnChooseUMLFile.setLayoutData(new RowData(150, 40));
			btnChooseUMLFile.setText("Verify");
			Text text = new Text(compsoite1, SWT.WRAP|SWT.V_SCROLL);
			text.setBounds(150,150,1600,1800);
			text.setLayoutData(new RowData(1600, 1200));			
			btnChooseUMLFile.addSelectionListener(new SelectionAdapter() {
    			public void widgetSelected(SelectionEvent e) {
    				    text.setText("");
    				// ����һ��JFrame���Ϊparent���
    					String  UMLFileName = "";
        				JFrame frame = new JFrame();
        				String dir = "E:\\papyrus\\MDSSED";

        				JFileChooser chooser = new JFileChooser();
        				chooser.setCurrentDirectory(new File(dir));
        				chooser.setDialogTitle("Choose UML model"); 	
        			    XMLFileFilter xmlFilter = new XMLFileFilter();   
        			    chooser.addChoosableFileFilter(xmlFilter);
        			    chooser.setFileFilter(xmlFilter);
        			 
        			    //��ѡ�����ļ������ӡѡ����ʲô�ļ�
        				int flag = chooser.showOpenDialog(frame);
        				if (flag == JFileChooser.APPROVE_OPTION) {
        					System.out.println("�û�ѡ���ļ���" + chooser.getSelectedFile().getAbsolutePath());
        					UMLFileName = chooser.getSelectedFile().getAbsolutePath();
        				    try {
        				    	List<String> resultList = null;
        				    	long stime = System.currentTimeMillis();
        				    	resultList = Verify.main(UMLFileName);
        				    	long etime = System.currentTimeMillis();
        				        // ����ִ��ʱ��
        				        System.out.printf("��ִ֤��ʱ����%d ����.", (etime - stime));
        				    	if(resultList!=null && resultList.size()>0) {
        				    		for(String res:resultList) {
                		    			text.append(res);        				    			
        				    		}
        				    	}

							} catch (DocumentException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
        				}
    			}
    		});
		     Composite compsoite2 = new Composite(tabFolder,SWT.NONE|SWT.V_SCROLL);
		        tabItem2.setControl(compsoite2);
		        RowLayout layout2 = new RowLayout(SWT.VERTICAL);
		        compsoite2.setLayout(layout2);
					Label lable2= new Label(compsoite2,1);
					lable2.setLayoutData(new RowData(150, 40));
					lable2.setText("Code Generation:");
					Button btnChooseUMLFile2 = new Button(compsoite2, 1);
					btnChooseUMLFile2.setLayoutData(new RowData(150, 40));
					btnChooseUMLFile2.setText("Generate Code");
					Text text2 = new Text(compsoite2, SWT.WRAP|SWT.V_SCROLL);
					text2.setBounds(150,150,1600,1800);
					text2.setLayoutData(new RowData(1600, 1200));			
					btnChooseUMLFile2.addSelectionListener(new SelectionAdapter() {
		    			public void widgetSelected(SelectionEvent e) {
		    				    text2.setText("");
		    				// ����һ��JFrame���Ϊparent���
		    					String  UMLFileName = "";
		        				JFrame frame = new JFrame();
		        				String dir = "E:\\papyrus\\MDSSED";

		        				JFileChooser chooser = new JFileChooser();
		        				chooser.setCurrentDirectory(new File(dir));
		        				chooser.setDialogTitle("Choose UML model"); 	
		        			    XMLFileFilter xmlFilter = new XMLFileFilter();   
		        			    chooser.addChoosableFileFilter(xmlFilter);
		        			    chooser.setFileFilter(xmlFilter);
		        			 
		        			    //��ѡ�����ļ������ӡѡ����ʲô�ļ�
		        				int flag = chooser.showOpenDialog(frame);
		        				if (flag == JFileChooser.APPROVE_OPTION) {
		        					System.out.println("�û�ѡ���ļ���" + chooser.getSelectedFile().getAbsolutePath());
		        					UMLFileName = chooser.getSelectedFile().getAbsolutePath();
		        				    try {
		        				    	long stime = System.currentTimeMillis();

		        				    	String resultList = "";
		        				    	resultList = UML2Groovy.main(UMLFileName);
		        				    	long etime = System.currentTimeMillis();
		        				        // ����ִ��ʱ��
		        				        System.out.printf("��������ִ��ʱ����%d ����.", (etime - stime));
		                		    	text2.append(resultList);        				    			

									} catch (DocumentException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
		        				}
		    			}
		    		});
//			Button btnVerify = new Button(tableGroup, 1);
//			btnVerify.setText("Verify");
//			btnVerify.addSelectionListener(new SelectionAdapter() {
//    			public void widgetSelected(SelectionEvent e) {
//    				String fileName = "E:\\papyrus\\CorDev\\case2.uml"; 
////    				try {
////						UMLModel umlModel = GetReqModelElements.main(fileName);
////					} catch (DocumentException e1) {
////						// TODO Auto-generated catch block
////						e1.printStackTrace();
////					}
//
//    			}
//    		});
//			Button btnCodeGen = new Button(tableGroup, 1);
//			btnCodeGen.setText("Generate Code for SmartThing");
//			btnCodeGen.addSelectionListener(new SelectionAdapter() {
//    			public void widgetSelected(SelectionEvent e) {
//    				String fileName = "E:\\papyrus\\CorDev\\case2.uml"; 
////    				try {
////						UMLModel umlModel = GetReqModelElements.main(fileName);
////					} catch (DocumentException e1) {
////						// TODO Auto-generated catch block
////						e1.printStackTrace();
////					}
//
//    			}
//    		});

        

//        Group tableGroup3 = new Group(compsoite1,SWT.V_SCROLL);
//        tableGroup3.setText("Risk Assessment");
//        GridData gd3 = new GridData(GridData.FILL_BOTH);
//        gd3.heightHint = 200;
//        tableGroup3.setLayoutData(gd3);
//        tableGroup3.setLayout(new GridLayout(2,false));
//        {    
//			GridData gridDatac=new GridData();
//			gridDatac.horizontalSpan=2;//����ˮƽ��Խ2����Ԫ��
//			gridDatac.horizontalAlignment=SWT.FILL;//ˮƽ���
//		
//        }
//        Group tableGroup4 = new Group(compsoite1,SWT.V_SCROLL);
//        tableGroup4.setText("Risk Treatment");
//        GridData gd4 = new GridData(GridData.FILL_BOTH);
//        gd4.heightHint = 200;
//        tableGroup4.setLayoutData(gd4);
//        tableGroup4.setLayout(new GridLayout(2,false));
//        {    
//			GridData gridDatac=new GridData();
//			gridDatac.horizontalSpan=2;//����ˮƽ��Խ2����Ԫ��
//			gridDatac.horizontalAlignment=SWT.FILL;//ˮƽ���
//
//        }
	}

	@Override
	public void setFocus() {
		
	}
}
