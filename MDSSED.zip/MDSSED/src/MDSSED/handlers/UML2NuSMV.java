package MDSSED.handlers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.DocumentException;

import MDSSED.utils.Action;
import MDSSED.utils.Attribute;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;
import MDSSED.utils.genValuesOfAttrs;
import MDSSED.utils.getValueOfCommand;
import threat.GenThreat1And5;
import threat.GenThreat2;
import threat.GenThreat3;
import threat.GenThreat4;
import threat.GenThreat6;
import threat.GenThreat7;
import threat.GenThreat8;

public class UML2NuSMV {
//	public static List<String> main(String fileName) throws DocumentException, IOException{
	public static List<String> main(BehaviourStateMachine umlModel) throws DocumentException, IOException{

//	public static void main(String[] Arg) throws Exception{
//		   String fileName = "E:\\papyrus\\MDSSED\\bundle4.uml"; 
		   File directory = new File("");//����Ϊ��
		   String dir = directory.getCanonicalPath() + "\\NuSMV-2.6.0-win64\\bin" ;
		   System.out.println("dir----" + dir);
//		   String smvFile = "D:\\NuSMV-2.6.0-win64\\NuSMV-2.6.0-win64\\bin";
		   String smvFile = dir;
		   
//		   //��ȡUMLģ��
//		   BehaviourStateMachine umlModel = GetUMLModel.main(fileName);
		   //��ȡ�����������б������ɶ�Ӧ��NuSMVģ��
//		   List<PhysicalVar> Env = umlModel.getEnv();
//		   String capabilityFile = "D:\\NuSMV-2.6.0-win64\\NuSMV-2.6.0-win64\\bin\\capabilities.txt"; 
		   String capabilityFile = directory.getCanonicalPath() + "\\NuSMV-2.6.0-win64\\bin\\capabilities.txt"; 
//		   String capabilityFile = "E:\\eclipse\\MDSSED" + "\\NuSMV-2.6.0-win64\\bin\\capabilities.txt"; 

		   List<Device> deviceAttrValues = genValuesOfAttrs.gen(capabilityFile);
		   List<State> initStates = umlModel.getInitStates();
		   List<State> states = umlModel.getStates();
		   List<Transition> trans = umlModel.getTrans();
		   List<String> statesInTrans = new ArrayList<String>();//��source ### target����ʽ�洢״̬
		   List<String> stateGroupList = new ArrayList<String>();//�洢�����state groups
		   List<String> actionGroupList = new ArrayList<String>();//�洢�����action groups,��device ### action1��action2��...�ķ�ʽ�洢
		   boolean flagSun = false; 
		   //ͳ�����г��ֵ��豸�����ԣ���������deviceģ��
		   List<DeviceAttrValue> DAVS = new ArrayList<DeviceAttrValue>();
		   String behaviourName = umlModel.getName();//ģ����
		   String behaviourMoudle = "MODULE " + behaviourName;
		   String behaviourMoudle1And5 = "";
		   String behaviourMoudle2 = "";
		   String behaviourMoudle3 = "";
		   String behaviourMoudle4 = "";
		   String behaviourMoudle6 = "";
		   String behaviourMoudle7 = "";
		   String behaviourMoudle8 = "";
		   String behaviourMoudle9 = "";

		   //��ȡ�����������
		   List<String> inList = new ArrayList<String>();
		   //���б�����ֵ
		   List<String> values = new ArrayList<String>();
		   String transText = "";//�洢transitions
		   String transTextT9 = "";//�洢transitions
		   String tranText = "";//�洢transition
		   String tranTextT9 = "";//�洢transition
		   String tranTextT9Threat = "";//�洢transition
		   String smvFile1And5 = smvFile + "\\" + behaviourName + "_T1AndT5.smv";
		   String smvFile2 = smvFile + "\\" + behaviourName + "_T2.smv";
		   String smvFile3 = smvFile + "\\" + behaviourName + "_T3.smv";
		   String smvFile4 = smvFile + "\\" + behaviourName + "_T4.smv";
		   String smvFile6 = smvFile + "\\" + behaviourName + "_T6.smv";
		   String smvFile7 = smvFile + "\\" + behaviourName + "_T7.smv";
		   String smvFile8 = smvFile + "\\" + behaviourName + "_T8.smv";
		   String smvFile9 = smvFile + "\\" + behaviourName + "_T9.smv";

		   List<String> nextList = new ArrayList<String>();//�洢transǨ��
		   List<String> nextListT9 = new ArrayList<String>();//�洢transǨ��

		   List<String> propertiesUnderThreat1And5 = new ArrayList<String>();//T1, T5��в����Ҫ��������Ե��б�
		   List<String> propertiesUnderThreat2 = new ArrayList<String>();//T2��в����Ҫ��������Ե��б�
		   List<String> propertiesUnderThreat8 = new ArrayList<String>();//T8��в����Ҫ��������Ե��б�
		   List<String> propertiesUnderThreat9= new ArrayList<String>();//T9��в����Ҫ��������Ե��б�
		   List<String> deviceInAction = null;

		    String actionListText = "";//���ɶ�������
			String stateListText = "";//����״̬����
			String init = "";//���ɳ�ʼ����
			String initActions = "";//actions��init
		   if(trans!=null && trans.size()>0) {
			   for(Transition tran:trans) {
				   State source = tran.getSource();
				   State target = tran.getTarget();
				   statesInTrans.add(source.getState() + " ### " + target.getState());//�洢Ǩ�Ƶ���ʼ״̬��Ŀ��״̬
				   List<Action> actions = tran.getActions();
				   deviceInAction = new ArrayList<String>();
				   if(actions!=null && actions.size()>0) {
					   for(Action action:actions) {
						   if(!action.getCommandDevice().equals("phone")) {
							   String actionName = action.getAction();
							   String command = action.getCommand();
							   String deviceName = action.getCommandDevice();
							   deviceInAction.add(deviceName);
							   List<String> args = action.getCommandArgs();
							   //����ÿһ��action�������뵽��Ӧ�豸��action����
							   String actionText = "";
							   if(args!=null && args.size()>0) {
								   for(String arg:args) {
									   arg = arg.replace("-", "");
									   arg = arg.replace("\"", "");
									   actionText = actionText + "_" + arg;
								   }
							   }
							   actionText = "action_" + deviceName + "_" + command + actionText;
							   //����actionGroupList�����������ͬ�豸���ϣ�����뼯�ϣ����򴴽��µļ���
							   int size = actionGroupList.size();
							   boolean exist = false;
							   for(int i=0; i<size; i++) {
								   String actionGroup = actionGroupList.get(i);
								   String device = actionGroup.split(" ### ")[0];
								   String actionList = actionGroup.split(" ### ")[1];
	//							   System.out.println("����action------" + actionList);
								   if(device.equals(deviceName)) {
									   //�Ѿ��и��豸��action�飬ֱ�Ӽ���
									   exist = true;
									   String s = actionGroup;
									   if(!s.contains(actionText)){
										   s = s + ", " + actionText;
										   actionGroupList.set(i, s);									   
									   }
								   }
							   }
							   if(exist == false) {
								   actionGroupList.add(deviceName + " ### " + actionText);
								   size++;
							   }
						  
						   }
					   }
				   }
			   }
		   }
		   //��ʼaction
		   if(actionGroupList!=null && actionGroupList.size()>0) {
			   for(String actionGroup:actionGroupList) {
				   String device = actionGroup.split(" ### ")[0];
				   String actionsInGroup = actionGroup.split(" ### ")[1];
				   actionListText = actionListText + "action_"+ device +":{None, " + actionsInGroup + "};\r\n"; 
				   initActions = initActions +"action_"+ device + " = None & ";
			   }
			   initActions = initActions.substring(0,initActions.length() - 3);//ɾ������ġ� & ��
		   }
		   
			//��ʼ״̬
			if(initStates!=null & initStates.size()>0) {
				for(State s:initStates) {
					List<DeviceAttrValue> DAVs = s.getDeviceAttrValues();
					if(DAVs!=null && DAVs.size()>0) {
						for(DeviceAttrValue DAV:DAVs) {
							String device = DAV.getDevice();
							String attr = DAV.getAttribute();
							String value = DAV.getValue();
							String trueOrFalse = DAV.getTrueOrFalse();
							String DAVText = "";
							if(trueOrFalse.equals("=="))
								DAVText = device + "_" + attr + " = " + value;
							else 
								DAVText = "(" + device + "_" + attr + " = " + value + ") = FALSE";
							if(init.contains(DAVText)==false)
								init = init + DAVText + " & ";
						}
					}
				}				   
				init = init.substring(0,init.length() - 3);//ɾ������ġ� & ��
				if(!initActions.equals("")) {
					if(!init.equals(""))
						init = "INIT\r\n" + "\t" + init + " & " + initActions + ";\r\n";		
					else
						init = "INIT\r\n" + "\t" + initActions + ";\r\n";								
				}
				else
					init = "INIT\r\n" + "\t" + init + ";\r\n";
				if(initStates!=null && initStates.size()>0) {
					init = init + "ASSIGN\r\n";
					int i = 0;
					for(State state:initStates) {
						i++;
						String initStateText = state.getState();
						init = init + "init(state" + i + ") := {" + initStateText + "};\r\n";
						//����ÿһ��InitState�ҵ�����target����û�м����б���������б�---state����洢��һ��initState��Ӧһ��(Ҫ��״̬���������ظ�)
						List<String> stateGroup = new ArrayList<String>();
						stateGroup = getStateGroup(initStateText, statesInTrans, stateGroup);
						String stateGroupText = list2String(stateGroup);
						stateGroupList.add(stateGroupText);
					}
//					init = init.substring(0,init.length() - 2);//ɾ������ġ��� ��
//					init = init + "};\r\n";
				}
			   if(stateGroupList!=null && stateGroupList.size()>0) {
				   int index = 0;
				   for(String stateGroupText:stateGroupList) {
//					   System.out.println("stateGroupText------:"+stateGroupText);
					   index++;
					   stateListText = stateListText + "state" + index + " : {" + stateGroupText + "};\r\n"; 
					   nextList = stateGroupNext(stateGroupText, index, trans, nextList);//���Ӹ���״̬��Ǩ��
					   nextListT9 = stateGroupNextT9(stateGroupText, index, trans, nextListT9);//���Ӹ���״̬��Ǩ��

				   }
			   }
			}
			   if(trans!=null && trans.size()>0) {
//				   for(Transition tran:trans) {
					   nextList = setTranForAction(trans, nextList, stateGroupList);//���Ӹ�tran��Ӧ��action��Ǩ��
					   nextListT9 = setTranForActionT9(trans, nextListT9, stateGroupList);
//				   }
			   }
		   //��state,transition��trigger��condition�л�ȡ��������������ӵ�inList��
		   if(trans!=null && trans.size()>0) {
			   for(Transition tran:trans) {
				   State source = tran.getSource();
				   State target = tran.getTarget();
//				   System.out.println("Trans�ĳ�״̬"+source.getState()+"ĩ��"+target.getState());
				   int indexS = getStateIndex(source.getState(), stateGroupList);
				   tranText = "state" + indexS +" = ";
				   tranText = tranText + source.getState() + " & ";
				   tranTextT9 = tranText;
				   tranTextT9Threat = "";
				   List<Trigger> triggers = tran.getTriggers();
				   for(Trigger trigger:triggers) {
					   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
					   String device = deviceAttrValue.getDevice();
					   String attr = deviceAttrValue.getAttribute();
					   if(inList.contains(device+"_"+attr)==false)
						   inList.add(device+"_"+attr);//�������
					   String value = deviceAttrValue.getValue();//ֵ
					   if(values.contains(value)==false){
						   values.add(value);
					   }
					   if(existInDAVs(device,attr,DAVS)==false) {
						   DAVS.add(deviceAttrValue);
					   }
					   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
					   if(trueOrFalse.equals("==")) {
						   if(deviceInAction.contains(device)) {
							   tranText = tranText + device + "_" + attr + " = " + value + " & ";
							   tranTextT9 = tranTextT9 + device + "_" + attr + " = " + value + " & ";
							   tranTextT9Threat = tranTextT9Threat + device + "_" + attr + " = " + value + " & ";						   
						   }
						   else {
							   tranText = tranText + device + "_" + attr + " != " + value + " & next(" + device + "_" + attr + ") = " + value + " & ";
							   tranTextT9 = tranTextT9 + device + "_" + attr + " = " + value + " & ";
							   tranTextT9Threat = tranTextT9Threat + device + "_" + attr + " != " + value + " & next(" + device + "_" + attr + ") = " + value + " & ";						   
						   }
					   }
					   else {
						   if(deviceInAction.contains(device)) {
							   tranText = tranText + device + "_" + attr + " != " + value + " & ";
							   tranTextT9 = tranTextT9 + device + "_" + attr + " != " + value + " & ";   
							   tranTextT9Threat = tranTextT9Threat + device + "_" + attr + " != " + value + " & ";
						   }
						   else {
							   tranText = tranText + device + "_" + attr + " = " + value + " & next(" + device + "_" + attr + ") != " + value  + " & ";
							   tranTextT9 = tranTextT9 + device + "_" + attr + " != " + value + " & ";   
							   tranTextT9Threat = tranTextT9Threat + device + "_" + attr + " = " + value + " & next(" + device + "_" + attr + ") != " + value + " & ";
						   }
					   }
				   }
				   List<Condition> conditions = tran.getConditions();
				   List<String> conditionTexts = new ArrayList<String>();
				   for(Condition condition:conditions) {
					   String conditionText = condition.getCondition();
//					   System.out.println("con:"+ conditionText);
					   conditionTexts.add(conditionText);
					   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();   
					   if(deviceAttrValue!=null) {
						   String device = deviceAttrValue.getDevice();
						   String attr = deviceAttrValue.getAttribute();
						   if(inList.contains(device+"_"+attr)==false)
							   inList.add(device+"_"+attr);//�������
						   String value = deviceAttrValue.getValue();//ֵ
						   if(values.contains(value)==false){
							   values.add(value);
						   }
						   if(existInDAVs(device,attr,DAVS)==false) {
							   DAVS.add(deviceAttrValue);
						   }
						   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
						   if(trueOrFalse.equals("==")) {
							   tranText = tranText + device + "_" + attr + " = " + value + " & ";
							   tranTextT9 = tranTextT9 + device + "_" + attr + " = " + value + " & ";
							   if(!tranTextT9Threat.equals(""))
								   tranTextT9Threat = tranTextT9Threat + device + "_" + attr + " = " + value + " & ";
	
						   }
						   else {
							   tranText = tranText + device + "_" + attr + " != " + value + " & ";
							   tranTextT9 = tranTextT9 + device + "_" + attr + " != " + value + " & ";	
							   if(!tranTextT9Threat.equals(""))
								   tranTextT9Threat = tranTextT9Threat + device + "_" + attr + " != " + value + " & ";						   
	
						   }
					   }
				   }
				   if(conditionTexts!=null && conditionTexts.size()>0) {
					   if(conditionTexts.contains("now() > getSunriseAndSunset().sunrise.time") && conditionTexts.contains("now() < getSunriseAndSunset().sunset.time")) {
						   tranText = tranText + "now = betweenSunsetAndSunrise" + " & ";	
						   tranTextT9 = tranTextT9 + "now = betweenSunsetAndSunrise" + " & ";	
						   flagSun = true;
					   }
					   if(conditionTexts.contains("now() > getSunriseAndSunset().sunset.time") ||conditionTexts.contains("now() < getSunriseAndSunset().sunrise.time") ) {
						   tranText = tranText + "now = notBetweenSunsetAndSunrise" + " & ";	
						   tranTextT9 = tranTextT9 + "now = notBetweenSunsetAndSunrise" + " & ";	
						   flagSun = true;

				   }
			   }
				   tranText = tranText.substring(0,tranText.length() - 3);//ɾ������ġ� & ��
				   tranTextT9 = tranTextT9.substring(0,tranTextT9.length() - 3);//ɾ������ġ� & ��
				   if(!tranTextT9Threat.equals(""))
					   tranTextT9Threat = tranTextT9Threat.substring(0,tranTextT9Threat.length() - 3);//ɾ������ġ� & ��

//				   tranText = tranText + " :\r\n";
//				   tranText = tranText + "\t\t\t\tnext(state) = " + target.getState() + " & \r\n";
//				   nextText = "\t\t\t\tnext(state) = " + target.getState() + " & \r\n";
//				   boolean stateAlreadyIn = false;
//				   if(nextList!=null && nextList.size()>0) {
//					   int size = nextList.size();
//					   for(int i=0;i<size;i++) {
//						   if(nextList.get(i).equals("next(state):=case")){
//							   nextList.add(i+1,"\t(" + tranText + "):" + target.getState() + ";");
//							   size++;
//							   stateAlreadyIn = true;
//						   }
//					   }
//				   }
//				   if(stateAlreadyIn == false) {
//					   nextList.add("next(state):=case");
//					   nextList.add("\t(" + tranText + "):" + target.getState() + ";");
//					   nextList.add("\tTRUE:state;\r\nesac;");
//				   }	
				   List<DeviceAttrValue> changeDAVs = new ArrayList<DeviceAttrValue>();
				   List<String> changes = changeByAction(tran, capabilityFile);
				   List<String> afterChanges = new ArrayList<String>();
				   if(changes!=null && changes.size()>0) {
					   for(String change:changes) {
						   String afterChange = change.split(" ### ")[1];
						   afterChanges.add(afterChange);
						   System.out.println("change:"+change);
					   }
					   changeDAVs = initDAVsByStrings(afterChanges);
				   }
				   //����T1����Ҫ��������ԣ������ڣ���ָ��״̬�£�actionӰ����豸���ԣ�changeByAvtion�������ڸ�״̬�µ��豸���ԣ������¸�״̬��Ҳ�����ڡ�
				   String targetState = target.getState();
				   String propertyUnderT1AndT5 = "";
				   String propertyUnderT2 = "";
				   String propertyUnderT9 = "";
				   String propertyUnderT8 = "";
				   List<Action> actions = tran.getActions();
				   List<String> actionsInTran = new ArrayList<String>();
				   if(actions!=null && actions.size()>0) {
					   String actionIntran = "";
					   for(Action action:actions) {
						   if(!action.getCommandDevice().equals("phone")) {
							   String actionDevice = action.getCommandDevice();
							   String actionCommand = action.getCommand();
							   String actionArgs = "";
							   List<String> args = action.getCommandArgs();
							   if(args!=null && args.size()>0) {
								   actionArgs = "";
								   for(String arg:args) {
									   arg = arg.replace("\"", "");
									   actionArgs = actionArgs + "_" + arg;
								   }
							   }
							   actionIntran = actionDevice + "_" + actionCommand + actionArgs;
						   }
					   }
					   actionsInTran.add(actionIntran);
				   }
//				   for(DeviceAttrValue DAV:target.getDeviceAttrValues()) {
				   for(DeviceAttrValue DAV:changeDAVs) {
					   String valueSetByCommand = "";
					   String device = DAV.getDevice();
					   String attr = DAV.getAttribute();
					   String value = DAV.getValue();
					   int index = getStateIndex(targetState, stateGroupList);
					   propertyUnderT1AndT5 = "CTLSPEC !EF(("+ behaviourName +".state"+ index + "= " + targetState +" & ";
					   propertyUnderT1AndT5 = propertyUnderT1AndT5 + device + "." + attr + " != " + value + ") & EX("+ behaviourName +".state"+ index +"= "+ targetState +" & " + device + "." + attr + " != " + value +"));"+"--/*For threat 1*/\r\n";//T1����Ҫ��������ԣ��������豸���Բ�����action���õ�ֵ
//					 System.out.println("��������ԣ�"+ propertyUnderT1);
					   if(!propertiesUnderThreat1And5.contains(propertyUnderT1AndT5))
						   propertiesUnderThreat1And5.add(propertyUnderT1AndT5);
					   //Threat 2
					   if(actionsInTran!=null && actionsInTran!=null) {
						   for(String actionInTran:actionsInTran) {
							   String commandDevice = actionInTran.split("_")[0];
							   if(commandDevice.equals(device)) {
								   //���������õ�ֵ��Ϊ����ֵ
								   String command = actionInTran.split("_")[1];
								   String aInTran[] =actionInTran.split("_"); 
//								   System.out.println("_______CommandHasArg:" +command +"  " + aInTran.length);
								   if(aInTran.length>2) {
									   valueSetByCommand = actionInTran.split("_")[2];
								   }
								   else
									   valueSetByCommand = getValueOfCommand.getValue(capabilityFile, commandDevice, command);
								   String actionText = behaviourName + "." + "action_" + device;
								   propertyUnderT2 = "CTLSPEC !EF(" + device + "." + attr + " = "  + value + " & EX(" + actionText + " = " + "action_" + actionInTran + "));" + "--/*For threat 2*/\r\n";
								   if(!propertiesUnderThreat2.contains(propertyUnderT2))
									   propertiesUnderThreat2.add(propertyUnderT2);						
								   propertyUnderT9 = "CTLSPEC !EF(" + device + "." + attr + " = "  + value + " & EX(" + actionText + " = " + "action_" + actionInTran + "));" + "--/*For threat 9*/\r\n";
								   if(!propertiesUnderThreat9.contains(propertyUnderT9))
									   propertiesUnderThreat9.add(propertyUnderT9);		   
							   }
						   }
					   }
					   //Threat 8
					   propertyUnderT8 = "CTLSPEC EF("+   device + "." + attr + " = " + value  +");"+"--/*For threat 8*/\r\n";//T8����Ҫ��������ԣ������豸���Ե���action���õ�ֵ
					   if(!propertiesUnderThreat8.contains(propertyUnderT8))
						   propertiesUnderThreat8.add(propertyUnderT8);			
	
					   String next = "";
					   String nextT9 = "";
					   String nextT9Threat = "";
					   if(valueSetByCommand != "") {
						   next = "\t(" + tranText + ")" + ":" + valueSetByCommand + ";";
						   nextT9 = "\t(" + tranTextT9 + ")" + ":" + valueSetByCommand + ";";
						   if(!tranTextT9Threat.equals(""))
							   nextT9Threat = "\t(" + tranTextT9Threat + ")" + ":" + valueSetByCommand + ";--/*Threat 9*/";

						   
					   }
					   else {
						   next = "\t(" + tranText + ")" + ":" + value + ";";				
						   nextT9 = "\t(" + tranTextT9 + ")" + ":" + value + ";";	
						   if(!tranTextT9Threat.equals(""))
							   nextT9Threat = "\t(" + tranTextT9Threat + ")" + ":" + value + ";--/*Threat 9*/";						   
					   }
					   boolean alreadyIn = false;					    
					   if(nextList!=null && nextList.size()>0) {
						   int size = nextList.size();
						   for(int i=0;i<size;i++) {
							   if(nextList.get(i).equals("next("+ device + "_" + attr +"):=case")) {
								   nextList.add(i+1,next);
								   size++;
								   alreadyIn = true;
							   } 
						   }
					   }
					   if(alreadyIn == false) {
						   nextList.add("next("+ device + "_" + attr +"):=case");
						   nextList.add(next);
						   nextList.add("\tTRUE:"+ device + "_" + attr +";\r\nesac;");
					   }					
					   boolean alreadyInT9 = false;					    
					   if(nextListT9!=null && nextListT9.size()>0) {
						   int size = nextListT9.size();
						   for(int i=0;i<size;i++) {
							   if(nextListT9.get(i).equals("next("+ device + "_" + attr +"):=case")) {
								   nextListT9.add(i+1,nextT9);
								   if(!nextT9Threat.equals("")) {
									   nextListT9.add(i+2, nextT9Threat);
									   size++;									   
								   }
								   size++;
								   alreadyInT9 = true;
							   } 
						   }
					   }
					   if(alreadyInT9 == false) {
						   nextListT9.add("next("+ device + "_" + attr +"):=case");
						   nextListT9.add(nextT9);
						   if(!nextT9Threat.equals("")) 
							   nextListT9.add(nextT9Threat);
						   nextListT9.add("\tTRUE:"+ device + "_" + attr +";\r\nesac;");
					   }	
				   }
//				   tranText = tranText.substring(0,tranText.length() - 5);//ɾ������ġ� & \r\n��
//				   tranText = tranText + ";\r\n";
//				   transText = transText + tranText;

			   }

//			   transText = "TRANS\r\ncase\r\n" + transText + "\tTRUE : next(state) = state;\r\nesac;\r\n";
		   }
			

		   if(states!=null && states.size()>0) {
			   for(State s:states) {
//				   stateListText = stateListText + s.getState() + ", ";
				   List<DeviceAttrValue> DAVs = s.getDeviceAttrValues();
				   if(DAVs!=null && DAVs.size()>0) {
					   for(DeviceAttrValue DAV:DAVs) {
						   String value = DAV.getValue();//ֵ
						   if(values.contains(value)==false){
							   values.add(value);
						   }
						   String d = DAV.getDevice();
						   String a = DAV.getAttribute();
						   if(inList.contains(d+"_"+a)==false)
							   inList.add(d+"_"+a);//�������
						   if(existInDAVs(d,a,DAVS)==false) {
							   DAVS.add(DAV);
						   }
					   }
				   }
			   }
//			   stateListText = stateListText.substring(0,stateListText.length() - 2);//ɾ������ġ��� ��
		   }
		   String inListText = "";
		   if(inList!=null && inList.size()>0) {
			   for(String s:inList) {
				   inListText = inListText + s +", "; 
			   }			   
			   inListText = inListText.substring(0,inListText.length() - 2);//ɾ������ġ��� ��
		   }
		   behaviourMoudle = behaviourMoudle + "(" + inListText + ")\r\n";
		   behaviourMoudle = behaviourMoudle + "VAR\r\n";//���ɱ����б�
//		   stateListText =  "\t"+"state : {" + stateListText + "};\r\n";


		    behaviourMoudle = behaviourMoudle + stateListText + actionListText;
		    if(flagSun == true) {
		    	 behaviourMoudle = behaviourMoudle + "now: {betweenSunsetAndSunrise, notBetweenSunsetAndSunrise};\r\n";
		    }
			behaviourMoudle = behaviourMoudle + init;
//			behaviourMoudle = behaviourMoudle + transText;
			String mainMoudle = "MODULE main\r\n" + "VAR\r\n";
			String mainMoudle3 = "";
			String mainMoudle4 = "";
			String mainMoudle6 = "";
			String mainMoudle7 = "";
			String mainMoudle8 = "";
			String mainMoudle9 = "";
			
			String deviceMoudles = "";//�����豸ģ��
			String deviceVarsInMain = "";//�����豸��main�е�var����
			List<Device> devices = new ArrayList <Device>();//��ģ���е��豸�����Լ��뵽devices��
			for(DeviceAttrValue DAV:DAVS) {
//				System.out.println("A DAV ----");
				//����ģ���е��豸������
				String DAV_device = DAV.getDevice();
				String DAV_attr = DAV.getAttribute();
				boolean existInDevices = false;
				for(Device device:devices) {
					//���DAV�е��豸�Ѿ����뵽�б��ˣ��Ͳ���Ҫ�����豸��ֻ�������Լ��뵽devices�и��豸������
					String dName = device.getDevice().replace(" ", "");					
					if(DAV_device.equalsIgnoreCase(dName)) {
//						System.out.println("�豸�Ѵ��� "+ DAV_device + "������" + DAV_attr);
						List<Attribute> attrs =device.getAttrs();
						//���������������Ƿ��Ѿ����ڣ������ھͼ��뵽���豸�������б���
						boolean existInAttrs = false;
						if(attrs!=null && attrs.size()>0) {
//							System.out.println("�����У� ");							
							for(Attribute a:attrs) {
								String aName = a.getAttr().replace(" ","");
//								System.out.println("		 " + aName);															
								if(aName.equalsIgnoreCase(DAV_attr)) {
//									System.out.println("���Դ��� ");																
									existInAttrs = true;
								}
							}
							//���Բ����ھͼ��뵽���豸�������б���
							if(existInAttrs == false) {
//								System.out.println("�����豸����");
								Attribute a = new Attribute();
								a.setAttr(DAV_attr);
								attrs.add(a);
								device.setAttrs(attrs);
							}
						}
						existInDevices = true;
					}
				}
				//���DAV�е��豸δ���뵽�б�,���DAV�е��豸���Լ���
				if(existInDevices == false) {
					Device d = new Device();
					d.setDevice(DAV_device);
					Attribute a = new Attribute();
					a.setAttr(DAV_attr);
					List<Attribute> attrs = new ArrayList<Attribute>();
					attrs.add(a);
					d.setAttrs(attrs);
					devices.add(d);
//					System.out.println("�������豸 "+ DAV_device );

				}
			}
			devices = addPossibleValues(deviceAttrValues,devices);//Ϊ�����豸���������ÿ��ܵ�ȡֵ
			if(devices!=null && devices.size()>0) {
				System.out.println("------�豸���Ա��� " );
				for(Device device:devices) {
					System.out.println("------�豸�� " + device.getDevice() );
					List<Attribute> attrs = device.getAttrs();
					if(attrs!=null && attrs.size()>0) {
						for(Attribute attr:attrs) {
							System.out.println("			���ԣ� " + attr.getAttr() );
							List<String> vs = attr.getValues();
							if(vs!=null &&vs.size()>0) {
								for(String v:vs) {
									System.out.println("				���ܵ�ֵ�� " + v);									
								}
							}			
						}
					}
					deviceMoudles = deviceMoudles + genDeviceMoudle(device);//�豸ģ��
					deviceVarsInMain = deviceVarsInMain + "\t" + device.getDevice() + " : " + device.getDevice() + "();\r\n";//�豸ģ����main�����е�����

				}
			}
			mainMoudle = mainMoudle +  deviceVarsInMain;
			mainMoudle4 = mainMoudle;
			mainMoudle6 = mainMoudle;
			mainMoudle7 = mainMoudle;

			mainMoudle = mainMoudle + "\t" +genBehInMainMoudle(behaviourName,inList);
//			System.out.println("��������������������mainMoudle��������������������\r\n" + mainMoudle);
			//������в��ģģ��
			String threatMoudles = "";

//			String threat1 = GenThreat1.main(umlModel, inListText);
//			if(!threat1.equals("")) {
//				threatMoudles = threatMoudles + threat1;
//				mainMoudle = mainMoudle + "\tthreat1 : threat1(" + inListText.replace("_", ".") + ");\r\n";
//			}
			List<String> nextList1And5 = new ArrayList<String>(nextList);
			nextList1And5 = GenThreat1And5.main(stateGroupList, behaviourName, umlModel, inListText, nextList1And5, deviceAttrValues, capabilityFile);
//			String threat2 = GenThreat2.main(umlModel, inListText);
//			if(!threat2.equals("")) {
//				threatMoudles = threatMoudles + threat2;
//				mainMoudle = mainMoudle + "\tthreat2 : threat2(" + inListText.replace("_", ".") + ");\r\n";
//			}
			
			List<String> nextList2 = new ArrayList<String>(nextList);
			nextList2 = GenThreat2.main(umlModel, inListText, nextList2, deviceAttrValues);
			
			List<String> propertyForT3 = new ArrayList<String>();
			String threat3 = GenThreat3.main(umlModel, devices,propertyForT3, deviceAttrValues);
			if(!threat3.equals("")) {
				String inMain = threat3.split("\r\n")[0];
				inMain = inMain.replace("MODULE ", "\tthreat3 : ");
				inMain = inMain.replace("_", ".");
				mainMoudle3 = mainMoudle + inMain + ";\r\n";
			}
			List<String> propertyForT4 = new ArrayList<String>();
			String threat4 = GenThreat4.main(umlModel, deviceAttrValues, behaviourName, propertyForT4);
			if(!threat4.equals("")) {
				threatMoudles = threatMoudles + threat4;
				mainMoudle4 = mainMoudle4 + "\tthreat4 : threat4();\r\n";
				List<DeviceAttrValue> inVars = GenThreat4.genThreat(trans);
				mainMoudle4 = mainMoudle4 + "\t" + genBehUnderThreatInMainMoudle("4",behaviourName,inList,inVars);//����T4�µ���Ϊģ��
			}
			List<String> propertyForT6 = new ArrayList<String>();
			String threat6 = GenThreat6.main(umlModel, deviceAttrValues, behaviourName, propertyForT6);
			if(!threat6.equals("")) {
				mainMoudle6 = mainMoudle6 + "\tthreat6 : threat6();\r\n";
				List<DeviceAttrValue> inVars = GenThreat6.genThreat(trans);
				mainMoudle6 = mainMoudle6 + "\t" + genBehUnderThreatInMainMoudle("6",behaviourName,inList,inVars);//����T6�µ���Ϊģ��
			}
			List<String> propertyForT7 = new ArrayList<String>();
			String threat7 = GenThreat7.main(umlModel, deviceAttrValues, behaviourName, propertyForT7);
			if(!threat7.equals("")) {
				mainMoudle7 = mainMoudle7 + "\tthreat7 : threat7();\r\n";
				List<DeviceAttrValue> inVars = GenThreat7.genThreat(trans);
				mainMoudle7 = mainMoudle7 + "\t" + genBehUnderThreatInMainMoudle("7",behaviourName,inList,inVars);//����T7�µ���Ϊģ��
			}			
			List<String> nextList8 = new ArrayList<String>(nextList);
			nextList8 = GenThreat8.main(stateGroupList, behaviourName, umlModel, inListText, nextList8, deviceAttrValues, capabilityFile);
//			String threat8 = GenThreat8.main(umlModel, inListText);
//			if(!threat8.equals("")) {
//				mainMoudle8 = mainMoudle + "\tthreat8 : threat8(" + inListText.replace("_", ".") + ");\r\n";
//			}
		   if(nextListT9!=null && nextListT9.size()>0) {
			   for(String s: nextListT9) {
				   transTextT9 = transTextT9 + s + "\r\n";
			   }
		   }
//			String threat9 = GenThreat9.main(umlModel, actionListText, inListText);
//			if(!threat9.equals("")) {
//				mainMoudle9 = mainMoudle + "\tthreat9 : threat9(" + inListText.replace("_", ".") + ");\r\n";
//			}
		   if(nextList!=null && nextList.size()>0) {
			   for(String s: nextList) {
				   transText = transText + s + "\r\n";
			   }
		   }

//		   String transText1And5 = "";
//		   if(nextList1And5!=null && nextList1And5.size()>0) {
//			   for(String s: nextList1And5) {
//				   transText1And5 = transText1And5 + s + "\r\n";
//			   }
//		   }
		   String propertiesTitle = "-----------------------Safety & Security Properties----------------------------\r\n";
		   List<String> allModelsT1AndT5 = new ArrayList<String>();
		   String transText1And5 = "";
		   if(nextList1And5!=null && nextList1And5.size()>0) {
			   for(String s: nextList1And5) {
				   transText1And5 = transText1And5 + s + "\r\n";
			   }
			   String TransT1AndT5[] = transText1And5.split("Next File");
			   for(String tranT1AndT5:TransT1AndT5) {
//				   System.out.println("NextFile----��" + tranT1AndT5);
				   String properties = propertiesTitle + tranT1AndT5.split("Safety & Security Properties")[1];
				   tranT1AndT5 = tranT1AndT5.split("Safety & Security Properties")[0];
				   allModelsT1AndT5.add(behaviourMoudle + tranT1AndT5 + deviceMoudles + mainMoudle + properties);
			   }
		   }
		   String transText2 = "";
		   if(nextList2!=null && nextList2.size()>0) {
			   for(String s: nextList2) {
				   transText2 = transText2 + s + "\r\n";
			   }
		   }
//			behaviourMoudle1And5 = behaviourMoudle + transText1And5 + deviceMoudles + mainMoudle;
			behaviourMoudle2 = behaviourMoudle + transText2 + deviceMoudles  + mainMoudle;
			if(!threat3.equals(""))
				behaviourMoudle3 = behaviourMoudle + transText + deviceMoudles  + threat3 +  mainMoudle3;
			behaviourMoudle4 = behaviourMoudle + transText + deviceMoudles  + threat4 +  mainMoudle4;
			behaviourMoudle6 = behaviourMoudle + transText + deviceMoudles  + threat6 +  mainMoudle6;
			behaviourMoudle7 = behaviourMoudle + transText + deviceMoudles  + threat7 +  mainMoudle7;
//			behaviourMoudle8 = behaviourMoudle + transText + deviceMoudles  + threat8 +  mainMoudle8;
			   List<String> allModelsT8 = new ArrayList<String>();
			   String transText8 = "";
			   if(nextList8!=null && nextList8.size()>0) {
				   for(String s: nextList8) {
					   transText8 = transText8 + s + "\r\n";
				   }
				   String TransT8[] = transText8.split("Next File");
				   for(String tranT8:TransT8) {
//					   System.out.println("NextFile----��" + tranT1AndT5);
					   String properties = propertiesTitle + tranT8.split("Safety & Security Properties")[1];
					   tranT8 = tranT8.split("Safety & Security Properties")[0];
					   allModelsT8.add(behaviourMoudle + tranT8 + deviceMoudles + mainMoudle + properties);
				   }
			   }
			behaviourMoudle9 = behaviourMoudle + transTextT9 + deviceMoudles + mainMoudle;


			//������Ҫ�����Security&Safety����
			String properties = "-----------------------Safety & Security Properties----------------------------\r\n";
//			String propertiesForT1AndT5 = properties;
			String propertiesForT2 = properties;
			String propertiesForT3 = properties;
			String propertiesForT4 = properties;
			String propertiesForT6 = properties;
			String propertiesForT7 = properties;
			String propertiesForT8 = properties;
			String propertiesForT9 = properties;
//			if(propertiesUnderThreat1And5!=null && propertiesUnderThreat1And5.size()>0) {
//				for(String p: propertiesUnderThreat1And5) {
//					propertiesForT1AndT5 = propertiesForT1AndT5 + p;
//				}
//			}
			if(propertiesUnderThreat2!=null && propertiesUnderThreat2.size()>0) {
				for(String p: propertiesUnderThreat2) {
					propertiesForT2 = propertiesForT2 + p;
				}
			}
			if(propertyForT3!=null && propertyForT3.size()>0) {
				for(String p:propertyForT3) {
					propertiesForT3 = propertiesForT3 +p; 
				}
			}
			if(propertyForT4!=null && propertyForT4.size()>0) {
				for(String p:propertyForT4) {
					propertiesForT4 = propertiesForT4 +p; 
				}
			}
			if(propertyForT6!=null && propertyForT6.size()>0) {
				for(String p:propertyForT6) {
					propertiesForT6 = propertiesForT6 +p; 
				}
			}
			if(propertyForT7!=null && propertyForT7.size()>0) {
				for(String p:propertyForT7) {
					propertiesForT7 = propertiesForT7 +p; 
				}
			}
			if(propertiesUnderThreat8!=null && propertiesUnderThreat8.size()>0) {
				for(String p: propertiesUnderThreat8) {
					propertiesForT8 = propertiesForT8 + p;
				}
			}
			if(propertiesUnderThreat9!=null && propertiesUnderThreat9.size()>0) {
				for(String p: propertiesUnderThreat9) {
					propertiesForT9 = propertiesForT9 + p;
				}
			}
//			behaviourMoudle1And5 = behaviourMoudle1And5 + propertiesForT1AndT5;
			if(!behaviourMoudle2.equals("")) {
				behaviourMoudle2 = behaviourMoudle2 + propertiesForT2;
				writeFile(behaviourMoudle2, smvFile2);

			}
			if(!behaviourMoudle3.equals("")) {
				behaviourMoudle3 = behaviourMoudle3 + propertiesForT3;
				writeFile(behaviourMoudle3, smvFile3);

			}
			if(!behaviourMoudle4.equals("")) {
				behaviourMoudle4 = behaviourMoudle4 + propertiesForT4;
				writeFile(behaviourMoudle4, smvFile4);

			}
			if(!behaviourMoudle6.equals("")) {
				behaviourMoudle6 = behaviourMoudle6 + propertiesForT6;
				writeFile(behaviourMoudle6, smvFile6);

			}
			if(!behaviourMoudle7.equals("")) {
				behaviourMoudle7 = behaviourMoudle7 + propertiesForT7;
				writeFile(behaviourMoudle7, smvFile7);

			}
//			if(!behaviourMoudle8.equals("")) {
//				behaviourMoudle8 = behaviourMoudle8 + propertiesForT8;
//				writeFile(behaviourMoudle8, smvFile8);
//
//			}
			if(allModelsT8!=null && allModelsT8.size()>0) {
				int size = allModelsT8.size();
				for(int i=0;i<size;i++) {
					String fileName = smvFile8.replace(".smv", "_" + i + ".smv");
					writeFile(allModelsT8.get(i), fileName);
				}
			}
			if(!behaviourMoudle9.equals("")) {
				behaviourMoudle9 = behaviourMoudle9 + propertiesForT9;
				writeFile(behaviourMoudle9, smvFile9);	
			}

			if(allModelsT1AndT5!=null && allModelsT1AndT5.size()>0) {
				int size = allModelsT1AndT5.size();
				for(int i=0;i<size;i++) {
					String fileName = smvFile1And5.replace(".smv", "_" + i + ".smv");
					writeFile(allModelsT1AndT5.get(i), fileName);
				}
			}
//			writeFile(behaviourMoudle1And5, smvFile1And5);
			
			String resultT1AndT5 = "";
			String resultT2 = "";
			String resultT3 = "";
			String resultT4 = "";
			String resultT6 = "";
			String resultT7 = "";
			String resultT8 = "";
			String resultT9 = "";
			List<String> results = new ArrayList<String>();
//			if(!behaviourMoudle1And5.equals("")) {
//				String cmd = "cmd.exe /c NuSMV " + smvFile1And5;
//				System.out.println("ִ��cmd" +cmd);
//		        resultT1AndT5 = javaCmd(cmd , dir);
//			}
			if(allModelsT1AndT5!=null && allModelsT1AndT5.size()>0) {
				int size = allModelsT1AndT5.size();
				for(int i=0;i<size;i++) {
					String fileName = smvFile1And5.replace(".smv", "_" + i + ".smv");
					String cmd = "cmd.exe /c NuSMV " + fileName;
					System.out.println("ִ��cmd" +cmd);
			        resultT1AndT5 = resultT1AndT5 + javaCmd(cmd , dir);					
				}
			}
	        results.add(resultT1AndT5);
			if(!behaviourMoudle2.equals("")) {
				String cmd = "cmd.exe /c NuSMV " + smvFile2;
				System.out.println("ִ��cmd" +cmd);
		        resultT2 = javaCmd(cmd , dir);
			}
	        results.add(resultT2);
			if(!behaviourMoudle3.equals("")) {
				String cmd = "cmd.exe /c NuSMV " + smvFile3;
				System.out.println("ִ��cmd" +cmd);
		        resultT3 = javaCmd(cmd , dir);
		        }
		        results.add(resultT3);
			if(!behaviourMoudle4.equals("")) {
				String cmd = "cmd.exe /c NuSMV " + smvFile4;
				System.out.println("ִ��cmd" +cmd);
		        resultT4 = javaCmd(cmd , dir);
			}
			results.add(resultT4);
			if(!behaviourMoudle6.equals("")) {
				String cmd = "cmd.exe /c NuSMV " + smvFile6;
				System.out.println("ִ��cmd" +cmd);
		        resultT6 = javaCmd(cmd , dir);
		        }
		        results.add(resultT6);
			if(!behaviourMoudle7.equals("")) {
				String cmd = "cmd.exe /c NuSMV " + smvFile7;
				System.out.println("ִ��cmd" +cmd);
		        resultT7 = javaCmd(cmd , dir);
		        }
		        results.add(resultT7);
//			if(!behaviourMoudle8.equals("")) {
//				String cmd = "cmd.exe /c NuSMV " + smvFile8;
//				System.out.println("ִ��cmd" +cmd);
//		        resultT8 = javaCmd(cmd ,dir);
//		        }
//		        results.add(resultT8);
				if(allModelsT8!=null && allModelsT8.size()>0) {
					int size = allModelsT8.size();
					for(int i=0;i<size;i++) {
						String fileName = smvFile8.replace(".smv", "_" + i + ".smv");
						String cmd = "cmd.exe /c NuSMV " + fileName;
						System.out.println("ִ��cmd" +cmd);
				        resultT8 = resultT8 + javaCmd(cmd , dir);					
					}
				}
		        results.add(resultT8);
			if(!behaviourMoudle9.equals("")) {
				String cmd = "cmd.exe /c NuSMV " + smvFile9;
				System.out.println("ִ��cmd" +cmd);
		        resultT9 = javaCmd(cmd , dir);
		        }
		        results.add(resultT9);
			if(results !=null && results.size()>0) {
				for(String r: results) {
//					System.out.println("result: " + r);
				}
			}
			List<String> resList = new ArrayList<String>();
	    	if(results!=null && results.size()>0) {
	    		int i = 0;
	    		for(String s:results) {
	    			i++;
	    			if(i==5) i++;
	    			if(!s.equals("")) {
	    				String res = "";
	    				if(i==1) {
	    					res = "\n\n---------------Verification results under threat T1 and T5-----------------------\n";
		    				if(s.contains("false")) {
		    					res = res + "Warning: Not secure and safe under threat T1 and T5!\nThe following security and safety properties are violated.\n";
		    				}   
	    				}
	    				else {
		    				res = "\n\n---------------Verification results under threat T"+ i + "-----------------------\n";        				    					
		    				if(s.contains("false")) {
		    					res = res + "Warning: Not secure and safe under threat T" + i +"!\nThe following security and safety properties are violated.\n";
		    				}        				    					
	    				}
	    				res = res + s;
		    			resList.add(res);
	    			}
//            		result.append("######").append("\n");//"######"��ÿһ��Threat�ֿ�
	    		}
//				System.out.println("resultList---" + result.toString() );
	    	}
//			return results;
			return resList;

		}

//  д���ļ�
private static void writeFile(String content,String FileName)  {
//	System.out.println("���ɵ�smv�ļ���\r\n" + content);
      try {
          BufferedWriter out = new BufferedWriter(new FileWriter(FileName));
          out.write(content);
          out.close();
//          System.out.println("�ļ������ɹ���");
      } catch (IOException e) {
      }
  }
private static String genBehInMainMoudle(String bahaviourName, List<String> inList){
		String line = "";
		if(inList!=null &&inList.size()>0) {
			line = bahaviourName + " : " + bahaviourName + "(" ;
			for(String in:inList) {
				in = in.replace("_", ".");
				line = line + in + ", ";				
			}			
			line = line.substring(0,line.length() - 2);//ɾ������ġ��� ��
			line = line + ");\r\n";
		}
		return line;
	}

private static String genBehUnderThreatInMainMoudle(String threat, String bahaviourName, List<String> inList, List<DeviceAttrValue> inVars){
	List<String> device_attrs = null;
	if(inVars!=null && inVars.size()>0) {
		device_attrs = new ArrayList<String>();
		for(DeviceAttrValue DAV: inVars) {
			String device_attr = DAV.getDevice() + "_" + DAV.getAttribute();
			device_attrs.add(device_attr);
		}
	}
	String line = "";
	if(inList!=null &&inList.size()>0) {
		line = bahaviourName + " : " + bahaviourName + "(" ;
		for(String in:inList) {
			if(device_attrs!=null && device_attrs.size()>0 && device_attrs.contains(in)) {
				in = "threat" +threat +"." + in;
			}
			else
				in = in.replace("_", ".");
			line = line + in + ", ";				
		}			
		line = line.substring(0,line.length() - 2);//ɾ������ġ��� ��
		line = line + ");\r\n";
	}
	return line;
}
private static String genDeviceMoudle(Device device) {
	String deviceMoudle = "MODULE " + device.getDevice() + "\r\n";
	deviceMoudle = deviceMoudle + "VAR\r\n";
	List<Attribute> attrs =device.getAttrs();
	if(attrs != null && attrs.size()>0) {
		for(Attribute attr:attrs) {
			deviceMoudle = deviceMoudle + "\t" + attr.getAttr() + " :{";
			List<String> values = attr.getValues();
			if(values!=null && values.size()>0) {
				for(String value:values) {
					if(value.contains("minimum")) {
						deviceMoudle = deviceMoudle.substring(0,deviceMoudle.length() - 1);//ɾ������ġ�{ ��
						String numMin = value.split(":")[1];
						deviceMoudle = deviceMoudle + numMin;
					}
					else if(value.contains("maximum")) {
						deviceMoudle = deviceMoudle + ".." + value.split(":")[1];
					}
					else
						deviceMoudle = deviceMoudle + value + ", ";
				}
				if(deviceMoudle.contains("..")) {
					deviceMoudle = deviceMoudle + ";\r\n";						
				}
				else {
					deviceMoudle = deviceMoudle.substring(0,deviceMoudle.length() - 2);//ɾ������ġ��� ��
					deviceMoudle = deviceMoudle + "};\r\n";	
				}
			}
		}
	}
	return deviceMoudle;
}

private static List<Device> addPossibleValues(List<Device> deviceAttrValues,List<Device> devices){
	//Ϊ���е��豸���������ÿ��ܵ�ȡֵ
//	System.out.println("������������������������addPossibleValues��������������������" );	

	if(devices!=null && devices.size()>0) {
		for(Device device:devices) {
			List<Attribute> attrs = device.getAttrs();
			if(attrs!=null && attrs.size()>0) {
				for(Attribute attr:attrs) {
					List<String> values = getPossibleValues(deviceAttrValues,device.getDevice(),attr.getAttr());//��ȡ�豸���Կ��ܵ�ֵ
					attr.setValues(values);
				}
			}
			device.setAttrs(attrs);
		}
	}
	return devices;
}
public static List<String> getPossibleValues(List<Device> deviceAttrValues, String device,String attr){
//	System.out.println("������������������������getPossibleValues��������������������" );	
//	System.out.println("-----device----" + device + "   attr:"+ attr );

	List<String> values = new ArrayList<String>();
	for(Device d:deviceAttrValues) {
		String dName = d.getDevice().replace(" ", "");
		List<Attribute> attrs = d.getAttrs();
		if(device.equalsIgnoreCase(dName)) {
//			System.out.println("-----Find device----" + device + "   attr:"+ attr );
			if(attrs!=null && attrs.size()>0) {
				for(Attribute a:attrs) {
//					System.out.println("����:" + a.getAttr());
					String aName = a.getAttr().replace(" ", "");
					if(aName.equals(attr)) {
//						System.out.println("�ҵ������豸�����ӿ��ܵ�ֵ��" + dName +" " + attr);
						List<String> vs = a.getValues();
						if(vs!=null && vs.size()>0) {
							for(String s:vs) {
								String s1 = s.replace(" ", "");
								s1 = s1.replace("-","");
								s1 = s1.replace("'","");
								values.add(s1);			
//								System.out.println("			���ܵ�ֵ��" + s1);

							}
						}
					}
				}
			}
		}
	}
	return values;
	
}
private static boolean existInDAVs(String device,String attr,List<DeviceAttrValue>DAVs) {
	if(DAVs!=null && DAVs.size()>0) {
		for(DeviceAttrValue DAV:DAVs) {
			if(DAV.getDevice().equals(device)&&DAV.getAttribute().equals(attr))
				return true;
		}
	}
	return false;
}
public static List<String> changeByAction(Transition tran, String capabilityFile) throws IOException {
	//���ظ�tran�У�action�����״̬�仯
	List<String> triAndCons = new ArrayList<String>();
	List<Trigger> triggers = tran.getTriggers();
	List<Condition> cons = tran.getConditions();
	List<Action> actions = tran.getActions();
	List<String> actionSetValues = new ArrayList<String>();
	if(actions!=null && actions.size()>0) {
		for(Action action:actions) {
			if(!action.getCommandDevice().equals("phone")) {
				String commandDevice = action.getCommandDevice();
				String command = action.getCommand();
				List<String> args = action.getCommandArgs();
				String valueSetByCommand = "";
				   if(args!=null && args.size()>0) {
					   String s = args.get(0);
					   s = s.replace("\"", "");
					   valueSetByCommand = s;
				   }
				   else
				 valueSetByCommand = getValueOfCommand.getValue(capabilityFile, commandDevice, command);
				if(!valueSetByCommand.equals("")) {
					actionSetValues.add(commandDevice + " ### " + valueSetByCommand);
//					System.out.println("�������õģ�"+ commandDevice + " ### " + valueSetByCommand);
				}
			}
		}
	}

	if(triggers!=null && triggers.size()>0) {
		for(Trigger t:triggers) {
//			String s = t.getTrigger();
//			s = s.replace("\"", "");//ɾ������
//			s = s.replace(".", "_");
//			s = s.replace(" ", "");
			DeviceAttrValue DAV = t.getDeviceAttrValue();
			String device = DAV.getDevice();
			String attr = DAV.getAttribute();
			String trueOrFalse = DAV.getTrueOrFalse();
			String value = DAV.getValue();
			String s = device + "_" + attr + " "+ trueOrFalse + " " + value;
			triAndCons.add(s);
//			System.out.println("-----triggerOrCon  "+s);
		}
	}
	if(cons!=null && cons.size()>0) {
		for(Condition c:cons) {
//			String s = c.getCondition();
//			s = s.replace("\"", "");//ɾ������
//			s = s.replace(".", "_");
//			s = s.replace(" ", "");
//			triAndCons.add(s);
			DeviceAttrValue DAV = c.getDeviceAttrValue();
			if(DAV!=null) {
				String device = DAV.getDevice();
				String attr = DAV.getAttribute();
				String trueOrFalse = DAV.getTrueOrFalse();
				String value = DAV.getValue();
				String s = device + "_" + attr + " "+ trueOrFalse + " " + value;
				triAndCons.add(s);
//			System.out.println("-----triggerOrCon  "+s);
			}
		}
	}
	List<String> changes = new ArrayList<String>();
	State source = tran.getSource();
	State target = tran.getTarget();
//	System.out.println("state�ı�source:"+ source.getState() +" "+ " ### " +target.getState());

	List<DeviceAttrValue> DAVsInSource = source.getDeviceAttrValues();
	List<DeviceAttrValue> DAVsInTarget = target.getDeviceAttrValues();
	if(DAVsInSource!=null && DAVsInSource.size()>0 && DAVsInTarget!=null && DAVsInTarget.size()>0) {
		//����ÿһ��Ǩ�ƣ��ж�ǰ���Ƿ����豸��״̬�����仯
		for(DeviceAttrValue tDAV :DAVsInTarget) {
			for(DeviceAttrValue sDAV :DAVsInSource) {
				if(tDAV.getDevice().equals(sDAV.getDevice())) {//�Ƚ�ͬһ�豸ͬһ���Ե�ֵ
					if(tDAV.getAttribute().equals(sDAV.getAttribute())) {
						String tValue = tDAV.getValue();
						String tTrueOrFalse = tDAV.getTrueOrFalse();
						String before = "";
						String after = "";
						boolean actionChangeValue = false;
						if(actionSetValues!=null && actionSetValues.size()>0) {
							for(String s: actionSetValues) {
								String dInAction = s.split(" ### ")[0];
								if(dInAction.equals(tDAV.getDevice())) {
									tValue = s.split(" ### ")[1];
									tTrueOrFalse = "==";
//									System.out.println("�ҵ��������õ��豸��ֵ" + dInAction + " " + tValue );
									before = dInAction + "_" + sDAV.getAttribute() + " != "+ tValue;
									after = dInAction + "_" + sDAV.getAttribute() + " == " + tValue;
									actionChangeValue = true;
								}
							}
						}

//						System.out.println("�ж�tValue:"+tValue+" sDAV.getValue():"+sDAV.getValue()+" tTrueOrFalse: "+tTrueOrFalse+" sDAV.getTrueOrFalse():" +sDAV.getTrueOrFalse());
						if((tValue.equals(sDAV.getValue() ) && (tTrueOrFalse.equals(sDAV.getTrueOrFalse())==false)) || ((tValue.equals(sDAV.getValue()) ==false)&& tTrueOrFalse.equals(sDAV.getTrueOrFalse()))) {
							//ǰ����ͬ���豸���Ե�ֵ�����仯
							String device = tDAV.getDevice();
							String attr = tDAV.getAttribute();
							String trueOrFalse_t = tTrueOrFalse;
							String trueOrFalse_s = sDAV.getTrueOrFalse();
							String value_t = tValue;
							String value_s = sDAV.getValue();
							before = device + "_" + attr + " " + trueOrFalse_s + " "+ value_s;
							after = device + "_" + attr + " "+ trueOrFalse_t + " " + value_t;
//							System.out.println("�豸ֵ�ĸı�source:"+ source.getState() +" "+ before + " ### target" +target.getState() +" "+ after);
							changes.add(before + " ### " + after); 
						}
						if((tValue.equals(sDAV.getValue())) && tTrueOrFalse.equals(sDAV.getTrueOrFalse()) && actionChangeValue == true) {
							changes.add(before + " ### " + after); 
	
						}
					}
				}
			}
		}
		//�ж��Ƿ���action����ı仯
		if(changes!=null && changes.size()>0) {
			int size =changes.size();
			for(int i=0;i<size;i++) {
				String change = changes.get(i);
				String after = change.split(" ### ")[1];
//				System.out.println("�ı��"+after);
				if(triAndCons.contains(after)) {
//					System.out.println("ɾȥ"+after);
					changes.remove(i);
					size--;
				}
			}
		}
	}
	return changes;
}
public static List<DeviceAttrValue> initDAVsByStrings(List<String> deviceStates) {
	List<DeviceAttrValue> deviceAttrValues =new ArrayList <DeviceAttrValue>();
	if(deviceStates!=null && deviceStates.size()>0) {
		for(String deviceState:deviceStates) {
//			System.out.println("Class State: initState----------" + deviceState);
			deviceState = deviceState.replace(" ", "");//ɾ���ո�
			deviceState = deviceState.replace("&quot;", "");//ɾ������
			deviceState = deviceState.replace("\"", "");//ɾ������

			DeviceAttrValue deviceAttrValue = new DeviceAttrValue();
			String trueOrFalse = "";
			String[] s = deviceState.split("_");
			if(s!=null && s.length>0) {
				deviceAttrValue.setDevice(s[0]);
				if(s[1].contains("=="))
					trueOrFalse = "==";
				if(s[1].contains("!="))
					trueOrFalse = "!=";
				deviceAttrValue.setTrueOrFalse(trueOrFalse); 
				if(s[1].contains(trueOrFalse)) {
					s = s[1].split(trueOrFalse);
					if(s[0]!=null && s[0].length()>0) {
						deviceAttrValue.setAttribute(s[0]);
					}
					if(s[1]!=null && s[1].length()>0) {
						deviceAttrValue.setValue(s[1]);					
					}
				}	
			}
//			System.out.println("Class State: initState----------" + deviceAttrValue.getDevice()+deviceAttrValue.getAttribute());
			deviceAttrValues.add(deviceAttrValue);
		}
	}
	return deviceAttrValues;
}
private static List<String> getStateGroup(String state, List<String> statesInTrans, List<String> stateGroup) {
	//����stateGroup�е�ÿһ��Ԫ�أ��ҵ�����statesInTrans�еĶ�Ӧ��target�����뵽stateGroup
	int size = 1;
	stateGroup.add(state);
	for(int i = 0; i<size ; i++) {
		String newAddedState = stateGroup.get(i);//�¼���stateGroup��״̬���ҵ�����target����
		if(statesInTrans!=null && statesInTrans.size()>0) {
			for(String s:statesInTrans) {
				String sourceText = s.split(" ### ")[0];
				String targetText = s.split(" ### ")[1];
				if(sourceText.equals(newAddedState)) {
					if(stateGroup!=null && stateGroup.size()>0) {
						if(!stateGroup.contains(targetText)) {
							stateGroup.add(targetText);
							size++;
						}
					}
				}
			}
		}
	}
	return stateGroup;
}
public static String list2String(List<String> list) {
	String listText = "";
	if(list!=null && list.size()>0) {
		for(String s:list) {
			listText = listText + s + ", "; 
		}
		listText = listText.substring(0,listText.length() - 2);//ɾ������ġ��� ��
	}
	return listText;
}
public static List<String> string2List(String s) {
	List<String> list = null;
	if(!s.equals("")) {
		list = new ArrayList<String>();
		String ss[] = s.split(", ");
		for(String s1:ss) {
			list.add(s1);
		}
	}
	return list;
}
public static List<String> stateGroupNext(String stateGroup, int index, List<Transition> trans, List<String> nextList) {
//����ÿһ��stateGroup��Ǩ��
//index��ʾ�ǵڼ����state
	List<String> stateGroupList = string2List(stateGroup);
	if(stateGroupList!=null && stateGroupList.size()>0) {
		for(String state:stateGroupList) {
			if(trans!=null && trans.size()>0) {
				for(Transition tran:trans) {
					String source = tran.getSource().getState();
					if(state.equals(source)) {
						nextList = setTranForState(tran, index, nextList);
					}
				}
			}
		}
	}
	return nextList;
}
public static List<String> stateGroupNextT9(String stateGroup, int index, List<Transition> trans, List<String> nextListT9) {
	//����ÿһ��stateGroup��Ǩ��
	//index��ʾ�ǵڼ����state
		List<String> stateGroupList = string2List(stateGroup);
		if(stateGroupList!=null && stateGroupList.size()>0) {
			for(String state:stateGroupList) {
				if(trans!=null && trans.size()>0) {
					for(Transition tran:trans) {
						String source = tran.getSource().getState();
						if(state.equals(source)) {
							nextListT9 = setTranForStateT9(tran, index, nextListT9);
						}
					}
				}
			}
		}
		return nextListT9;
	}
public static List<String> setTranForState(Transition tran, int index, List<String> nextList) {
	//index��ʾ�ǵڼ����state
	String source = tran.getSource().getState();
	String target = tran.getTarget().getState();
	String tranText = "";
	tranText = "state" + index +" = ";
	tranText = tranText + source + " & ";
	   List<Trigger> triggers = tran.getTriggers();
	   List<Action> actions= tran.getActions();
	   List<String> devicesInAction = new ArrayList<String>();
	   if(actions != null && actions.size() > 0) {
		   for(Action action: actions) {
			   devicesInAction.add(action.getCommandDevice());
		   }
	   }
	   for(Trigger trigger:triggers) {
		   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
		   String device = deviceAttrValue.getDevice();
		   String attr = deviceAttrValue.getAttribute();
		   String value = deviceAttrValue.getValue();//ֵ
		   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
		   if(trueOrFalse.equals("==")) {
			   if(devicesInAction.contains(device)) {
				   tranText = tranText + device + "_" + attr + " = " + value  + " & ";				   
			   }
			   else
				   tranText = tranText + device + "_" + attr + " != " + value + " & next(" + device + "_" + attr + ") = " + value + " & ";
		   }
		   else {
			   if(devicesInAction.contains(device)) {
				   tranText = tranText + device + "_" + attr + " != " + value + " & ";				   
			   }
			   else
				   tranText = tranText + device + "_" + attr + " = " + value + " & next(" + device + "_" + attr + ") != " + value  + " & ";
		   }
	   }
	   List<Condition> conditions = tran.getConditions();
	   List<String> conditionTexts = new ArrayList<String>();
	   for(Condition condition:conditions) {
		   conditionTexts.add(condition.getCondition());
		   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();
		   if(deviceAttrValue!=null) {
			   String device = deviceAttrValue.getDevice();
			   String attr = deviceAttrValue.getAttribute();
			   String value = deviceAttrValue.getValue();//ֵ
			   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
			   if(trueOrFalse.equals("=="))
				   tranText = tranText + device + "_" + attr + " = " + value + " & ";
			   else
				   tranText = tranText + device + "_" + attr + " != " + value + " & ";
		   }
	   }
	   if(conditionTexts!=null && conditionTexts.size()>0) {
			   if(conditionTexts.contains("now() > getSunriseAndSunset().sunrise.time") && conditionTexts.contains("now() < getSunriseAndSunset().sunset.time")) {
				   tranText = tranText + "now = betweenSunsetAndSunrise" + " & ";	
			   }
			   if(conditionTexts.contains("now() > getSunriseAndSunset().sunset.time") ||conditionTexts.contains("now() < getSunriseAndSunset().sunrise.time") ) {
				   tranText = tranText + "now = notBetweenSunsetAndSunrise" + " & ";	
		   }
	   }
	   tranText = tranText.substring(0,tranText.length() - 3);//ɾ������ġ� & ��
	   boolean stateAlreadyIn = false;
	   if(nextList!=null && nextList.size()>0) {
		   int size = nextList.size();
		   for(int i=0;i<size;i++) {
			   if(nextList.get(i).equals("next(state"+ index + "):=case")){
				   nextList.add(i+1,"\t(" + tranText + "):" + target + ";");
				   size++;
				   stateAlreadyIn = true;
			   }
		   }
	   }
	   if(stateAlreadyIn == false) {
		   nextList.add("next(state" + index +  "):=case");
		   nextList.add("\t(" + tranText + "):" + target + ";");
		   nextList.add("\tTRUE:state" + index + ";\r\nesac;");
	   }	
	   return nextList;
}
public static List<String> setTranForStateT9(Transition tran, int index, List<String> nextList) {
	//index��ʾ�ǵڼ����state
	String source = tran.getSource().getState();
	String target = tran.getTarget().getState();
	String tranText = "";
	tranText = "state" + index +" = ";
	tranText = tranText + source + " & ";
	
	   List<Trigger> triggers = tran.getTriggers();
	   for(Trigger trigger:triggers) {
		   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
		   String device = deviceAttrValue.getDevice();
		   String attr = deviceAttrValue.getAttribute();
		   String value = deviceAttrValue.getValue();//ֵ
		   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
		   if(trueOrFalse.equals("=="))
			   tranText = tranText + device + "_" + attr + " = " + value + " & ";
		   else
			   tranText = tranText + device + "_" + attr + " != " + value + " & ";
	   }
	   List<Condition> conditions = tran.getConditions();
	   List<String> conditionTexts = new ArrayList<String>();
	   for(Condition condition:conditions) {
		   conditionTexts.add(condition.getCondition());		   
		   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();
		   if(deviceAttrValue!=null) {
		   String device = deviceAttrValue.getDevice();
		   String attr = deviceAttrValue.getAttribute();
		   String value = deviceAttrValue.getValue();//ֵ
		   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
		   if(trueOrFalse.equals("=="))
			   tranText = tranText + device + "_" + attr + " = " + value + " & ";
		   else
			   tranText = tranText + device + "_" + attr + " != " + value + " & ";
		   }
	   }
	   if(conditionTexts!=null && conditionTexts.size()>0) {
		   if(conditionTexts.contains("now() > getSunriseAndSunset().sunrise.time") && conditionTexts.contains("now() < getSunriseAndSunset().sunset.time")) {
			   tranText = tranText + "now = betweenSunsetAndSunrise" + " & ";	
		   }
		   if(conditionTexts.contains("now() > getSunriseAndSunset().sunset.time") ||conditionTexts.contains("now() < getSunriseAndSunset().sunrise.time") ) {
			   tranText = tranText + "now = notBetweenSunsetAndSunrise" + " & ";	
	   }
   }
	   tranText = tranText.substring(0,tranText.length() - 3);//ɾ������ġ� & ��
	   boolean stateAlreadyIn = false;
	   if(nextList!=null && nextList.size()>0) {
		   int size = nextList.size();
		   for(int i=0;i<size;i++) {
			   if(nextList.get(i).equals("next(state"+ index + "):=case")){
				   nextList.add(i+1,"\t(" + tranText + "):" + target + ";");
				   size++;
				   stateAlreadyIn = true;
			   }
		   }
	   }
	   if(stateAlreadyIn == false) {
		   nextList.add("next(state" + index +  "):=case");
		   nextList.add("\t(" + tranText + "):" + target + ";");
		   nextList.add("\tTRUE:state" + index + ";\r\nesac;");
	   }
	   return nextList;
}

public static List<String> setTranForAction(List<Transition> trans, List<String> nextList, List<String> stateGroupList) {

	for(Transition tran:trans) {
		String tranText = "";
		State source = tran.getSource();
		int index = getStateIndex(source.getState(), stateGroupList);
		   List<Action> actionList= tran.getActions();
		   List<String> devicesInAction = new ArrayList<String>();
		   if(actionList != null && actionList.size() > 0) {
			   for(Action action: actionList) {
				   devicesInAction.add(action.getCommandDevice());
			   }
		   }
		 List<Trigger> triggers = tran.getTriggers();
		   for(Trigger trigger:triggers) {
			   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
			   String device = deviceAttrValue.getDevice();
			   String attr = deviceAttrValue.getAttribute();
			   String value = deviceAttrValue.getValue();//ֵ
			   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
			   if(trueOrFalse.equals("==")) {
				   if(devicesInAction.contains(device)) {
					   tranText = tranText + device + "_" + attr + " = " + value  + " & ";				   
				   }
				   else
					   tranText = tranText + device + "_" + attr + " != " + value + " & next(" + device + "_" + attr + ") = " + value + " & ";
			   }
			   else {
				   if(devicesInAction.contains(device)) {
					   tranText = tranText + device + "_" + attr + " != " + value + " & ";				   
				   }
				   else
					   tranText = tranText + device + "_" + attr + " = " + value + " & next(" + device + "_" + attr + ") != " + value  + " & ";
			   }
		   }
		   List<Condition> conditions = tran.getConditions();
		   List<String> conditionTexts = new ArrayList<String>();
		   for(Condition condition:conditions) {
			   conditionTexts.add(condition.getCondition());			  
			   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();
			   if(deviceAttrValue!=null) {
			   String device = deviceAttrValue.getDevice();
			   String attr = deviceAttrValue.getAttribute();
			   String value = deviceAttrValue.getValue();//ֵ
			   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
			   if(trueOrFalse.equals("=="))
				   tranText = tranText + device + "_" + attr + " = " + value + " & ";
			   else
				   tranText = tranText + device + "_" + attr + " != " + value + " & ";
			   }
		   }
		   if(conditionTexts!=null && conditionTexts.size()>0) {
			   if(conditionTexts.contains("now() > getSunriseAndSunset().sunrise.time") && conditionTexts.contains("now() < getSunriseAndSunset().sunset.time")) {
				   tranText = tranText + "now = betweenSunsetAndSunrise" + " & ";	
			   }
			   if(conditionTexts.contains("now() > getSunriseAndSunset().sunset.time") ||conditionTexts.contains("now() < getSunriseAndSunset().sunrise.time") ) {
				   tranText = tranText + "now = notBetweenSunsetAndSunrise" + " & ";	
		   }
	   }
		   if(!tranText.equals(""))
		   tranText = tranText.substring(0,tranText.length() - 3);//ɾ������ġ� & ��
			List<Action> actions = tran.getActions();
			if(actions!=null && actions.size()>0) {
				for(Action action:actions) {
				   if(!action.getCommandDevice().equals("phone")) {
					   String actionName = action.getAction();
					   String command = action.getCommand();
					   String deviceName = action.getCommandDevice();
					   List<String> args = action.getCommandArgs();
					   //����ÿһ��action�������뵽��Ӧ�豸��action����
					   String actionText = "";
					   if(args!=null && args.size()>0) {
						   for(String arg:args) {
							   arg = arg.replace("\"", "");
							   actionText = actionText + "_" + arg;
						   }
					   }
					   actionText = "action_" + deviceName + "_" + command + actionText;
					   boolean actionAlreadyIn = false;
					   if(nextList.contains("next(action_"+ deviceName + "):=case")) {
						   actionAlreadyIn = true;
					   }
					   if(tranText.equals("")) {
							tranText = "state" + index +" = " + source.getState();
					   }
					   if(nextList!=null && nextList.size()>0) {
						   int size = nextList.size();
						   for(int i=0;i<size;i++) {
							   if(nextList.get(i).equals("next(action_"+ deviceName + "):=case")){
								   if(!nextList.contains("\t(" + tranText + "):" + actionText + ";")) {
									   nextList.add(i+1,"\t(" + tranText + "):" + actionText + ";");
									   size++;
									   actionAlreadyIn = true;								   
								   }
							   }
						   }
					   }
					   if(actionAlreadyIn == false) {
						   nextList.add("next(" + "action_" +  deviceName + "):=case");
						   nextList.add("\t(" + tranText + "):" + actionText + ";");
						   nextList.add("\tTRUE:" + "None" +  ";\r\nesac;");
					   }	
				}
				}
			}
		  
	}
	  
	   return nextList;
}
public static List<String> setTranForActionT9(List<Transition> trans, List<String> nextList, List<String> stateGroupList) {

	for(Transition tran:trans) {
		String tranText = "";
		State source = tran.getSource();
		int index = getStateIndex(source.getState(), stateGroupList);
		 List<Trigger> triggers = tran.getTriggers();
		   for(Trigger trigger:triggers) {
			   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
			   String device = deviceAttrValue.getDevice();
			   String attr = deviceAttrValue.getAttribute();
			   String value = deviceAttrValue.getValue();//ֵ
			   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
			   if(trueOrFalse.equals("=="))
				   tranText = tranText + device + "_" + attr + " = " + value + " & ";
			   else
				   tranText = tranText + device + "_" + attr + " != " + value + " & ";
		   }
		   List<Condition> conditions = tran.getConditions();
		   List<String> conditionTexts = new ArrayList<String>();
		   for(Condition condition:conditions) {
			   conditionTexts.add(condition.getCondition());			  			  
			   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();
			   if(deviceAttrValue!=null) {

			   String device = deviceAttrValue.getDevice();
			   String attr = deviceAttrValue.getAttribute();
			   String value = deviceAttrValue.getValue();//ֵ
			   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
			   if(trueOrFalse.equals("=="))
				   tranText = tranText + device + "_" + attr + " = " + value + " & ";
			   else
				   tranText = tranText + device + "_" + attr + " != " + value + " & ";
			   }
		   }
		   if(conditionTexts!=null && conditionTexts.size()>0) {
			   if(conditionTexts.contains("now() > getSunriseAndSunset().sunrise.time") && conditionTexts.contains("now() < getSunriseAndSunset().sunset.time")) {
				   tranText = tranText + "now = betweenSunsetAndSunrise" + " & ";	
			   }
			   if(conditionTexts.contains("now() > getSunriseAndSunset().sunset.time") ||conditionTexts.contains("now() < getSunriseAndSunset().sunrise.time") ) {
				   tranText = tranText + "now = notBetweenSunsetAndSunrise" + " & ";	
		   }
	   }
		   if(!tranText.equals(""))
		   tranText = tranText.substring(0,tranText.length() - 3);//ɾ������ġ� & ��
			List<Action> actions = tran.getActions();
			if(actions!=null && actions.size()>0) {
				for(Action action:actions) {
				   if(!action.getCommandDevice().equals("phone")) {
					   String actionName = action.getAction();
					   String command = action.getCommand();
					   String deviceName = action.getCommandDevice();
					   List<String> args = action.getCommandArgs();
					   //����ÿһ��action�������뵽��Ӧ�豸��action����
					   String actionText = "";
					   if(args!=null && args.size()>0) {
						   for(String arg:args) {
							   arg = arg.replace("\"", "");
							   actionText = actionText + "_" + arg;
						   }
					   }
					   actionText = "action_" + deviceName + "_" + command + actionText;
					   boolean actionAlreadyIn = false;
					   if(nextList.contains("next(action_"+ deviceName + "):=case")) {
						   actionAlreadyIn = true;
					   }
					   if(tranText.equals("")) {
							tranText = "state" + index +" = " + source.getState();
					   }
					   if(nextList!=null && nextList.size()>0) {
						   int size = nextList.size();
						   for(int i=0;i<size;i++) {
							   if(nextList.get(i).equals("next(action_"+ deviceName + "):=case")){
								   nextList.add(i+1,"\t(" + tranText + "):" + actionText + ";");
								   size++;
								   actionAlreadyIn = true;
							   }
						   }
					   }
					   if(actionAlreadyIn == false) {
						   nextList.add("next(" + "action_" +  deviceName + "):=case");
						   nextList.add("\t(" + tranText + "):" + actionText + ";");
						   nextList.add("\tTRUE:" + "None" +  ";\r\nesac;");
					   }	
			    	}
		    	}
			}
		  
	}
	  
	   return nextList;
}

public static int getStateIndex(String state, List<String> stateGroupList) {
	int stateIndex = 0;
	 if(stateGroupList!=null && stateGroupList.size()>0) {
		   int index = 0;
		   for(String stateGroupText:stateGroupList) {
//			   System.out.println("stateGroupText------:"+stateGroupText);
			   index++;
			   List<String> states = string2List(stateGroupText);
			   if(states!=null & states.size()>0) {
				   if(states.contains(state))
					   stateIndex = index;
			   }			   
		   }
	   }
	 return stateIndex;
}
public static String javaCmd(String command, String dir) {
    StringBuilder result = new StringBuilder();
    Process p = null;
	Runtime rt = Runtime.getRuntime();  
	try {  
	 p = rt.exec(command ,null,new File(dir));  
	 //��ȡ���̵ı�׼������  
	 final InputStream is1 = p.getInputStream();   
	 //��ȡ���ǵĴ�����  
	 final InputStream is2 = p.getErrorStream();  
	 //���������̣߳�һ���̸߳������׼���������һ���������׼������  
	 new Thread() {  
	    public void run() {  
	       BufferedReader br1 = new BufferedReader(new InputStreamReader(is1));  
	        try {  
	            String line1 = null;  
	            while ((line1 = br1.readLine()) != null) {  
	                  if (line1 != null){
	                	if(!line1.contains("***") && !line1.replaceAll("\\s*", "").equals("")) {
	                		result.append(line1).append('\n');
	                	}
	                  }  
	              }  
	        } catch (IOException e) {  
	             e.printStackTrace();  
	        }  
	        finally{  
	             try {  
	               is1.close();  
	             } catch (IOException e) {  
	                e.printStackTrace();  
	            }  
	          }  
	        }  
	     }.start();  
	                                
	   new Thread() {   
	      public void  run() {   
	       BufferedReader br2 = new  BufferedReader(new  InputStreamReader(is2));   
	          try {   
	             String line2 = null ;   
	             while ((line2 = br2.readLine()) !=  null ) {   
	                  if (line2 != null){
	                	  if(!line2.contains("***") && !line2.replaceAll("\\s*", "").equals("")) {
	                		  result.append(line2).append('\n');
	                	  }
	                  }  
	             }   
	           } catch (IOException e) {   
	                 e.printStackTrace();  
	           }   
	          finally{  
	             try {  
	                 is2.close();  
	             } catch (IOException e) {  
	                 e.printStackTrace();  
	             }  
	           }  
	        }   
	      }.start();    
	                                
	      p.waitFor();  
	      p.destroy();   
	    } catch (Exception e) {  
	            try{  
	                p.getErrorStream().close();  
	                p.getInputStream().close();  
	                p.getOutputStream().close();  
	                }  
	             catch(Exception ee){}  
	          }  
    return result.toString();
}  

}
