package MDSSED.handlers;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.dom4j.DocumentException;

import MDSSED.utils.Action;
import MDSSED.utils.Attribute;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;
import MDSSED.utils.genValuesOfAttrs;

public class UML2Groovy {
	public static String main(String fileName) throws DocumentException, IOException{

		   File directory = new File("");
		   String dir = directory.getCanonicalPath() + "\\NuSMV-2.6.0-win64\\bin" ;
		   //Read the UML model. 
		   BehaviourStateMachine umlModel = GetUMLModel.main(fileName);
		   String capabilityFile = dir + "\\capabilities.txt"; //Capabilities of SmartThings devices.
		   List<Device> deviceAttrValues = genValuesOfAttrs.gen(capabilityFile);
		   List<State> states = umlModel.getStates();
		   List<Transition> trans = umlModel.getTrans();
		   List<String> setStates  = new ArrayList<String>();
		   List<String> funcList = new ArrayList<String>();
		   List<DeviceAttrValue> DAVS = new ArrayList<DeviceAttrValue>(); // List of all the devices, attributes and values in the model.
		   String behaviourName = umlModel.getName();
		   String groovyFile = dir + "\\" + behaviourName + ".groovy";
		   int timei = 0;
		   List<String> inList = new ArrayList<String>(); // Input Parameters
		   List<String> values = new ArrayList<String>(); // Values of all variables
		   List<Device> devices = new ArrayList <Device>();
		   if(trans!=null && trans.size()>0) {
			   for(Transition tran:trans) {
				   //Get all input parameters from the transition's triggers and conditions, add them to the inList.
				   List<Trigger> triggers = tran.getTriggers();
				   for(Trigger trigger:triggers) {
					   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
					   String device = deviceAttrValue.getDevice();
					   String attr = deviceAttrValue.getAttribute();
					   if(inList.contains(device+"_"+attr)==false)
						   inList.add(device+"_"+attr);//�������
					   String value = deviceAttrValue.getValue();//ֵ
					   if(values.contains(value)==false){
						   values.add(value);
					   }
					   if(existInDAVs(device,attr,DAVS)==false) {
						   DAVS.add(deviceAttrValue);
					   }
				   }
				   List<Condition> conditions = tran.getConditions();
				   for(Condition condition:conditions) {
					   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();   
					   if(deviceAttrValue!=null) {
						   String device = deviceAttrValue.getDevice();
						   String attr = deviceAttrValue.getAttribute();
						   String value = deviceAttrValue.getValue();
						   if(values.contains(value)==false){
							   values.add(value);
						   }
						   if(existInDAVs(device,attr,DAVS)==false) {
							   DAVS.add(deviceAttrValue);
						   }
					   }
				   }
				   List<Action> actions = tran.getActions();
				   for(Action action:actions) {
					   if(action.getCommandDevice().equals("phone")) {
							Device d = new Device();
							d.setDevice("phone");
							devices.add(d);
					   }
				   }
			   }
		   }
		   if(states!=null && states.size()>0) {
			   for(State s:states) {
				   List<DeviceAttrValue> DAVs = s.getDeviceAttrValues();
				   if(DAVs!=null && DAVs.size()>0) {
					   for(DeviceAttrValue DAV:DAVs) {
						   String value = DAV.getValue();//ֵ
						   if(values.contains(value)==false){
							   values.add(value);
						   }
						   String d = DAV.getDevice();
						   String a = DAV.getAttribute();
						   if(existInDAVs(d,a,DAVS)==false) {
							   DAVS.add(DAV);
						   }
					   }
				   }
			   }
		   }

			for(DeviceAttrValue DAV:DAVS) {
//				System.out.println("DAV ----");
				// Traversing devices and attributes in the model.
				String DAV_device = DAV.getDevice();
				String DAV_attr = DAV.getAttribute();
				boolean existInDevices = false;
				for(Device device:devices) {
					/* If the device in the DAV is already added to the list,
					there is no need to add the device, 
					just add the attribute to the attribute of the device in the devices*/
					String dName = device.getDevice().replace(" ", "");					
					if(DAV_device.equalsIgnoreCase(dName)) {
						List<Attribute> attrs =device.getAttrs();
						boolean existInAttrs = false;
						if(attrs!=null && attrs.size()>0) {
							for(Attribute a:attrs) {
								String aName = a.getAttr().replace(" ","");
								System.out.println("		 " + aName);															
								if(aName.equalsIgnoreCase(DAV_attr)) {
									existInAttrs = true;
								}
							}
							// Attributes are added to the list of attributes of the device if they do not exist.
							if(existInAttrs == false) {
								Attribute a = new Attribute();
								a.setAttr(DAV_attr);
								attrs.add(a);
								device.setAttrs(attrs);
							}
						}
						existInDevices = true;
					}
				}
				//If the device in the DAV is not in the list, then add the device attribute.
				if(existInDevices == false) {
					Device d = new Device();
					d.setDevice(DAV_device);
					Attribute a = new Attribute();
					a.setAttr(DAV_attr);
					List<Attribute> attrs = new ArrayList<Attribute>();
					attrs.add(a);
					d.setAttrs(attrs);
					devices.add(d);
				}
			}
			devices = addPossibleValues(deviceAttrValues,devices);// Set possible values for all devices and attributes.
			if(devices!=null && devices.size()>0) {
				System.out.println("------Devices and attributes�� " );
				for(Device device:devices) {
					System.out.println("------Device�� " + device.getDevice() );
					List<Attribute> attrs = device.getAttrs();
					if(attrs!=null && attrs.size()>0) {
						for(Attribute attr:attrs) {
							System.out.println("			Attribute�� " + attr.getAttr() );
							List<String> vs = attr.getValues();
							if(vs!=null &&vs.size()>0) {
								for(String v:vs) {
									System.out.println("				Values�� " + v);									
								}
							}			
						}
					}
				}
			}
//	Generate the Groovy app.
		String groovyApp = "";
		String preferences = "";
		String inits = "";
		String funcs = "";
		String notes = "/* Automatically generated from UML model.*/\r\n";
		String definition = "definition(\r\n" + 
			   		"	name: \""+ behaviourName +"\",\r\n" + 
			   		"	namespace: \"MDSSED\",\r\n" + 
			   		"	author: \"MDSSED\",\r\n" + 
			   		"	description: \"Safety and Security\",\r\n" + 
			   		"	category: \"Safety & Security\",\r\n" + 
			   		"	iconUrl: \"https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png\",\r\n" + 
			   		"	iconX2Url: \"https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png\",\r\n" + 
			   		"	iconX3Url: \"https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png\"\r\n" + 
			   		")\r\n";
		   preferences = "preferences {\r\n" + genPreferences(devices) + "}\r\n";
		  //For each migration, generate the trigger and the condition.
		   if(trans!=null && trans.size()>0) {
			   String init = "";
			   String defFunc = "";
			   int i = 0;
			   for(Transition tran:trans) {
				   String func = "p" + i;
				   List<String> TC = new ArrayList<String>();
				   i++;
				   List<DeviceAttrValue> trigsAndCons = new ArrayList<DeviceAttrValue>();
				   List<Trigger> triggers = tran.getTriggers();
				   for(Trigger trigger:triggers) {
					   if(triggers!=null && triggers.size()>0) {
						   TC.add(trigger.getTrigger());
						   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
						   String device = deviceAttrValue.getDevice();
						   String attr = deviceAttrValue.getAttribute();
						   String value = deviceAttrValue.getValue();
	
						   value = value.replace("-", "");	
						   value = value.trim();
						   device = device.replace(" ","");
						   device = toLowerCaseFirstOne(device);
						   attr = attr.replace(" ", "");
						   DeviceAttrValue trigOrCon = new DeviceAttrValue();
						   trigOrCon.setDevice(device);
						   trigOrCon.setAttribute(attr);
						   trigOrCon.setValue(value);
						   trigOrCon.setTrueOrFalse(deviceAttrValue.getTrueOrFalse());
						   trigsAndCons.add(trigOrCon);

						   String deviceUpper = device.substring(0, 1).toUpperCase() + device.substring(1);
						   init = "\tsubscribe(" + deviceUpper+ ", " + "\""+ attr + "\", "  + func + ")\r\n";
						   inits = inits + init;	
					   }
				   }
				   List<String> conTexts = null;
				   List<Condition> conditions = tran.getConditions();
				   if(conditions!=null && conditions.size()>0) {
					   conTexts = new ArrayList<String>();
					   for(Condition condition:conditions) {
						   TC.add(condition.getCondition());
						   String cText = condition.getCondition();
						   cText = cText.substring(0, 1).toUpperCase() + cText.substring(1);
						   conTexts.add(cText);
						   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();   
						   if(deviceAttrValue!=null) {
							   String device = deviceAttrValue.getDevice();
							   String attr = deviceAttrValue.getAttribute();
							   String value = deviceAttrValue.getValue();//ֵ
							   value = value.replace("-", "");		
							   value = value.trim();
							   device = device.replace(" ","");
							   device = toLowerCaseFirstOne(device);
							   attr = attr.replace(" ", "");
							   DeviceAttrValue trigOrCon = new DeviceAttrValue();
							   trigOrCon.setDevice(device);
							   trigOrCon.setAttribute(attr);
							   trigOrCon.setValue(value);
							   trigOrCon.setTrueOrFalse(deviceAttrValue.getTrueOrFalse());
							   trigsAndCons.add(trigOrCon);
					   		}
					   }					   
				   }
				   String actionText = "";
				   String actionTexts = "";				   
				   String actionRunIn = "";
				   List<Action> actions = tran.getActions();
				   if(actions!=null && actions.size()>0) {
					   for(Action action:actions) {
						   String time = "";
						  actionText = action.getAction();
						  if(actionText.contains("runIn")) {
							  //Get action text.
							  String s[] = actionText.split(", ");
							  time = s[0].replace("runIn(", "");
							  String a = s[1];
							  a = a.substring(0,a.length() - 1);
							  String defAction = a.replace("(", "").replace(")", "").replace(".", "").replace("\"", "") + "After" + time;
							  a = a.substring(0, 1).toUpperCase() + a.substring(1);
							  if(conTexts!=null && conTexts.size()>0) {
								  String condition = String.join(" && ", conTexts);
								  actionRunIn = actionRunIn + "def " + defAction  + "(){\r\n" + "\tif(" + condition + "){\r\n\t\t" + a + "\r\n\t}\r\n}\r\n";
								  
							  }
							  else {
								  actionRunIn = actionRunIn + "def " + defAction  + "(){\r\n" + "\t\t" + a + "\r\n}\r\n";
							  }
//							  System.out.println("tran.getTriggers():" + tran.getTriggers());
//							  System.out.println("tran.getConditions():" + tran.getConditions());
							  if(!(triggers!=null && triggers.size()>0)) {
								  inits = inits + "\tschedule(" + time + ", " + "\"" + defAction + "\")\r\n";
							  }
						  }
						   if(actionText.contains("runIn")) {
							   String s[] = actionText.split(", ");
							   String a = s[1];
							   a = a.substring(0,a.length() - 1);
							   a = a.replace("(", "").replace(")", "").replace(".", "").replace("\"", "");
							   actionText = s[0] + ", " + a + "After" + time + ")";
						   }
						   else if(actionText.contains("sendSms")) {
							   actionText = actionText.replace("phone", "Phone"); 
						   }
						   else
							   actionText = actionText.substring(0, 1).toUpperCase() + actionText.substring(1);
						   if(!actionTexts.contains(actionText))
							   actionTexts = actionTexts +"\t\t" + actionText + "\r\n"; 
					   }
				   }
				   //Generate definitions.
				   defFunc = "def " + func + "(evt){\r\n";
				   String ifContent = "\tif(" ;
				   if(TC!=null && TC.size()>0) {
					   for(String trigOrCon:TC) {
						   if(trigOrCon.contains("now()") && trigOrCon.contains("time_")){
							   timei++;
							   String s[] = trigOrCon.split(" ");
							   String actionTime = s[2];
							   String s1[] = actionTime.split("_");
							   String a = s1[1];
							   a = a.replace("(", "").replace(")", "").replace(".", "");
//							   setStates.add ("\t\tstate" + a + " = now()\r\n");
							   setStates.add (a);
							   String defTime = "\tdef time" + timei + " = " + "state." + a + "\r\n";
							   ifContent = defTime + ifContent; 
							   trigOrCon = "now() " + s[1] + " time" + timei + " " + s[3] + " " + s[4];
						   }
						   else {
							   if(!trigOrCon.contains("now()"))
								   trigOrCon = trigOrCon.substring(0, 1).toUpperCase() + trigOrCon.substring(1); 
						   }
						   ifContent = ifContent + trigOrCon + " && ";
					   }
					   ifContent = ifContent.substring(0,ifContent.length() - 4);//ɾ������ġ� && ��
					   ifContent = ifContent + "){\r\n";
					   
					   if(!funcs.contains(ifContent  +actionTexts + "\t}\r\n" + "}\r\n")) {
						   if((!(triggers!=null && triggers.size()>0)) && conditions != null && conditions.size()>0 && !actionTexts.contains("runIn") ) {
							   String device = conditions.get(0).getDeviceAttrValue().getDevice();
							   String attr = conditions.get(0).getDeviceAttrValue().getAttribute();
							   String deviceUpper = device.substring(0, 1).toUpperCase() + device.substring(1);

							   String s = actionTexts.replace("(", "").replace(")", "").replace(".", "").replace("\t", "").replace("\r\n", "");
							   s = s.substring(0, 1).toLowerCase() + s.substring(1);


							   if(!(funcs.contains(ifContent)&&funcs.contains(actionTexts))) {
								   init = "\tsubscribe(" + deviceUpper+ ", " + "\""+ attr + "\", "  + func + ")\r\n";
								   inits = inits + init;	
								   defFunc = defFunc + ifContent  + actionTexts + "\t}\r\n" + "}\r\n";
								   funcs = funcs + defFunc + actionRunIn;										   
							   }
						   }
						   else if(!((!(triggers!=null && triggers.size()>0)) && actionTexts.contains("runIn"))) {
							   String s = actionTexts.replace("(", "").replace(")", "").replace(".", "").replace("\t", "").replace("\r\n", "");
							   s = s.substring(0, 1).toLowerCase() + s.substring(1);
							   
							   if(!(funcs.contains(ifContent)&&funcs.contains(s))) {
								   defFunc = defFunc + ifContent  + actionTexts + "\t}\r\n" + "}\r\n";
								   funcs = funcs + defFunc + actionRunIn;										   
							   }							   
						   }
						   else {
							   // If the triggers are empty and the event is "runin", there is no need to generate the def function
							   funcs = funcs  + actionRunIn;				
						   }
					   }
				   }
				   else {
					   if(!(funcs.contains(actionRunIn))) {
						   funcs = funcs + actionRunIn;										   
					   }
				   }
			   }
		   }
		   funcs = "def installed() {\r\n" + 
		   		"\tinitialize()\r\n" + 
		   		"}\r\n" + 
		   		"def updated() {\r\n" + 
		   		"\tunsubscribe()\r\n" + 
		   		"\tinitialize()\r\n" + 
		   		"}\r\n"+ funcs;
		   String funcArray[] = funcs.split("\r\n");
		   if(funcArray!=null) {
			   for(String funcLine: funcArray) {
				   funcList.add(funcLine);
			   }
		   }
		   if(setStates!=null && setStates.size()>0) {
			   for(String s:setStates) {
				   if(funcList!=null && funcList.size()>0) {
					   int size  = funcList.size();
					   for(int i=0; i<size; i++) {
						   String funcLine = funcList.get(i);
						   if(funcLine.contains("def " + s)) {
							   String element = "\t\tstate." + s + " = now()";
							   funcList.add(i+1, element);
							   
						   }
					   }
				   }
			   }
		   }
		   funcs = String.join("\r\n", funcList);
		   inits = "def initialize() {\r\n" + inits + "}\r\n";
		   groovyApp = notes + definition + preferences + inits + funcs;
		   writeFile(groovyApp,groovyFile);
		   System.out.println("---UML2Groovy--groovyApp= \r\n"+ groovyApp);	 
		   return groovyApp;
	}


private static List<Device> addPossibleValues(List<Device> deviceAttrValues,List<Device> devices){
	// Set possible values for all devices and attributes

	if(devices!=null && devices.size()>0) {
		for(Device device:devices) {
			List<Attribute> attrs = device.getAttrs();
			if(attrs!=null && attrs.size()>0) {
				for(Attribute attr:attrs) {
					List<String> values = getPossibleValues(deviceAttrValues,device.getDevice(),attr.getAttr());// Get the possible values of device attributes
					attr.setValues(values);
				}
			}
			device.setAttrs(attrs);
		}
	}
	return devices;
}
private static List<String> getPossibleValues(List<Device> deviceAttrValues, String device,String attr){
//	System.out.println("������������������������getPossibleValues��������������������" );	
//	System.out.println("-----device----" + device + "   attr:"+ attr );

	List<String> values = new ArrayList<String>();
	for(Device d:deviceAttrValues) {
		String dName = d.getDevice().replace(" ", "");
		List<Attribute> attrs = d.getAttrs();
		if(device.equalsIgnoreCase(dName)) {
//			System.out.println("----- device----" + device + "   attr:"+ attr );
			if(attrs!=null && attrs.size()>0) {
				for(Attribute a:attrs) {
//					System.out.println("Attr:" + a.getAttr());
					String aName = a.getAttr().replace(" ", "");
					if(aName.equals(attr)) {
						List<String> vs = a.getValues();
						if(vs!=null && vs.size()>0) {
							for(String s:vs) {
								String s1 = s.replace(" ", "");
								s1 = s1.replace("-","");
								s1 = s1.replace("'","");
								values.add(s1);			
							}
						}
					}
				}
			}
		}
	}
	return values;
	
}
private static boolean existInDAVs(String device,String attr,List<DeviceAttrValue>DAVs) {
	if(DAVs!=null && DAVs.size()>0) {
		for(DeviceAttrValue DAV:DAVs) {
			if(DAV.getDevice().equals(device) && DAV.getAttribute().equals(attr))
				return true;
		}
	}
	return false;
}

public static void writeFile(String content,String FileName)  {
  try {
      BufferedWriter out = new BufferedWriter(new FileWriter(FileName));
      out.write(content);
      out.close();
  } catch (IOException e) {
  }
}
public static String genPreferences(List<Device> devices) {
	String preferences = "";
	if(devices!=null && devices.size()>0) {
		for(Device d:devices) {
			   String dName = d.getDevice().replace(" ", "");
			   dName = dName.substring(0, 1).toUpperCase() + dName.substring(1);
			   System.out.println("Device:"+dName);
			   String dID = toLowerCaseFirstOne(dName);
			   if(dName.equals("Location")) {
				   preferences = preferences + "	section(\"Home mode..\") {\r\n" + 
				   		"		input \"Location\", \"mode\", title: \"Mode?\"\r\n" + 
				   		"	}\r\n";
			   }
			   else if (dName.equals("Phone") ) {
				   if(!preferences.contains("phone")) {
					   preferences = preferences + "	section(\"Send Notifications\") {\r\n" + 
					   		"		input \"Phone\", \"phone\", title: \"Send a text message to:\"\r\n" + 
					   		"	}\r\n";
				   }
			   }
			   else {
				   preferences = preferences +  "    section(\"Controlling the "+ d.getDevice() +"..\") {\r\n" + 
					   		"		input \""+ dName + "\", \"capability."+dID+"\", title: \"Which "+ d.getDevice() + "?\"\r\n" + 
					   		"	}\r\n";						   
			   }
		}
	}
	return preferences;
}

public static String toLowerCaseFirstOne(String s)
{
  if(Character.isLowerCase(s.charAt(0)))
      return s;
  else
      return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0))).append(s.substring(1)).toString();
}

}
