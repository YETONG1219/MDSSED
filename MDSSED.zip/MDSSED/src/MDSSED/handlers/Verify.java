package MDSSED.handlers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.DocumentException;

import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;
import threat.FindThreat10;
import threat.FindThreat11;
import threat.FindThreat8;
import threat.FindThreat9;

public class Verify {

	public static List<String> main(String fileName) throws DocumentException, IOException{
		List<String> verifyResults = new ArrayList<String>();
		   BehaviourStateMachine umlModel = GetUMLModel.main(fileName);
		   String resultT8 = FindThreat8.main(umlModel);
		   String resultT9 = FindThreat9.main(umlModel);
		   String resultT10 = FindThreat10.main(umlModel);
		   String resultT11 = FindThreat11.main(umlModel);

		   if(!resultT8.contains("Warning") && !resultT9.contains("Warning") && !resultT10.contains("Warning") && !resultT11.contains("Warning")) {
			   verifyResults.addAll(UML2NuSMV.main(umlModel));
			   verifyResults.add(resultT8);
			   verifyResults.add(resultT9);
			   verifyResults.add(resultT10);
			   verifyResults.add(resultT11);
		   }
		   else {
			   verifyResults.add(resultT8);
			   verifyResults.add(resultT9);
			   verifyResults.add(resultT10);
			   verifyResults.add(resultT11);			   
		   }
			   

		   
		return verifyResults;

	}

}
