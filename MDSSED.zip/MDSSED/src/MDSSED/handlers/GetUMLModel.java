package MDSSED.handlers;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.GetElementByBaseState;
import MDSSED.utils.GetElementByBaseTranIdInXMLFile;
import MDSSED.utils.GetElementByIdInXMLFile;
import MDSSED.utils.GetInitStateElement;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class GetUMLModel {
	public static BehaviourStateMachine main(String fileName) throws DocumentException{
// 	   System.out.println("====GetReqStrModelElements:main----����ṹģ�͵�ģ��Ԫ�أ�");         
//		����XML�ļ��е�����StrModel��ģ��Ԫ��
//		public static void main(String[] Arg) throws DocumentException{
//			   String fileName = "E:\\papyrus\\MDSSED\\bundle4.uml"; 
	    	   File xmlFile = new File(fileName);// ����ָ����·������file����
	    	   SAXReader sax = new SAXReader();// ����һ��SAXReader����
	    	   Document document = sax.read(xmlFile);// ��ȡdocument����,����ĵ��޽ڵ㣬����׳�Exception��ǰ����
	    	   Element root = document.getRootElement();// ��ȡ���ڵ�
			   BehaviourStateMachine behaviour = new BehaviourStateMachine();
//			   physicalVars = getEnv(physicalVars,root,fileName);
//			   umlModel.setEnv(physicalVars);
			   behaviour = getBehaviour(behaviour, root, fileName);
    		   //��ȡUMLģ��
    		   if(behaviour!=null) {
    			   List<State> initStates = behaviour.getInitStates();
        		   if(initStates!=null) {
               		   for(State state:initStates) {
//      	        		   System.out.println("	Behaviour InitState--"+ state.getState()) ;	    
               			   List<DeviceAttrValue> DAVs = state.getDeviceAttrValues(); 
               			   if(DAVs!=null && DAVs.size()>0) {
               				   for(DeviceAttrValue DAV:DAVs) {
//	        	        		 System.out.println("	       InitState--"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() + "value:" +DAV.getValue()) ;	    
               				   }
            			   }
            		   }
        		   }
    			   List<State> states = behaviour.getStates();
        		   if(states!=null) {
               		   for(State state:states) {
//      	        		   System.out.println("	Behaviour StateName--"+ state.getState()) ;	    
               			   List<DeviceAttrValue> DAVs = state.getDeviceAttrValues(); 
               			   if(DAVs!=null && DAVs.size()>0) {
               				   for(DeviceAttrValue DAV:DAVs) {
//	        	        		 System.out.println("	 --"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() + "value:" +DAV.getValue()) ;	    
               				   }
            			   }
            		   }
        		   }
        		   List<Transition> trans = behaviour.getTrans();
        		   if(trans!=null) {
               		   for(Transition tran:trans) {
               			   List<Trigger> triggers = tran.getTriggers();
               			   List<Condition> conditions = tran.getConditions();
               			   List<Action> actions = tran.getActions();
            			   if(tran.getSource()!=null) {
        	        		   System.out.println("	  Transition--"+ "--source:"+tran.getSource().getState());	   
            			   }
            			   if(tran.getTarget()!=null) {
        	        		   System.out.println("	  Transition--"+ "--target:"+tran.getTarget().getState());	   
            			   }
            			   if(triggers!=null && triggers.size()>0) {
            				   for(Trigger trigger:triggers) {
                       			 DeviceAttrValue DAV = trigger.getDeviceAttrValue(); 
//	        	        		 System.out.println("	Behaviour trigger--"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() + DAV.getTrueOrFalse() +"��value:" +DAV.getValue() );	    
            				   }
            			   }
            			   if(conditions!=null && conditions.size()>0) {
            				   for(Condition c:conditions) {
            					   DeviceAttrValue DAV = c.getDeviceAttrValue(); 
//            					   System.out.println("	Behaviour condition--"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() +  DAV.getTrueOrFalse() +"value:" +DAV.getValue());	    
            				   }
            			   }
            			   if(actions!=null && actions.size()>0) {
            				   for(Action a:actions) {
//        					   System.out.println("	Behaviour action--"+ "device:" + a.getCommandDevice() + "command:" + a.getCommand() + "args:" +a.getCommandArgs());	    
            				   }
            			   }
            		   }
        		   }
    		   }
	   	return behaviour;
		}

//�ݹ��ȡ�ļ��е���������ģ��Ԫ��
	private static BehaviourStateMachine getBehaviour(BehaviourStateMachine behaviour,Element node,String fileName) throws DocumentException {
		
//		System.out.println("--------------------");
//	     ��ǰ�ڵ��ID��Name��Description
//	    System.out.println("====readXML: getNodes-  ��ǰ�ڵ����ƣ�" + node.attributeValue("name"));// ��ǰ�ڵ�����
//	    System.out.println("					       ��ǰ�ڵ��ID��" + node.attributeValue("id"));// ��ǰ�ڵ�����
//		System.out.println("						����type��" + node.attributeValue("type") );	
//		String nodeName = node.getName();
//		System.out.println("						nodeName��" + nodeName);	
	    	List<State> initStates = new ArrayList<State>();
	    	List<State> states= new ArrayList<State>();
	    	List<Transition> trans= new ArrayList<Transition>();
	    	String behaviourName = "";
	    	String type = node.attributeValue("type"); 
		    if(type!=null && type.equals("uml:StateMachine")) {
		    	behaviourName = node.attributeValue("name");
	    			Element region = node.element("region");
	    			if(region!=null) {
		    	    	List<Element> regionSublist = region.elements();// ����һ���ӽڵ��list
		    	    	if(regionSublist!=null) {
			    			for(Element e1 : regionSublist) {
			    				//�ҳ�ʼ״̬�ڵ�
			    				if(e1.attributeValue("type")!=null & e1.attributeValue("type").equals("uml:Pseudostate")) {
			    					String e1ID = e1.attributeValue("id"); 
			    					Element initStateElement = GetInitStateElement.getElement(e1ID,fileName);
			    					State initState = setStateByUML(initStateElement,fileName);//��ȡUML�е�state
			    					initStates.add(initState);
			    				}
			    				
			    				//�������״̬�ڵ�
			    				if(e1.attributeValue("type")!=null & e1.attributeValue("type").equals("uml:State")) {
			    					State state = setStateByUML(e1,fileName);//��ȡUML�е�state
			    					states.add(state);
			    				}
			    				//�������Ǩ�ƽڵ�
			    				if(e1.attributeValue("type")!=null & e1.attributeValue("type").equals("uml:Transition")) {
			    					Transition tran = setTranByUML(e1,fileName);
			    					if(tran!=null)
			    						trans.add(tran);
			    				}
			    			}
		    	    	}
	    			}
					//��ϵͳ��Ϊ��״̬��Ǩ�����ӵ�ϵͳ��Ϊ״̬��behaviour
	    			behaviour.setInitStates(initStates);//��ʼ״̬
	    			behaviour.setStates(states);
	    			behaviour.setTrans(trans);
	    			behaviour.setName(behaviourName);
	    		}
		// �ݹ������ǰ�ڵ����е��ӽڵ�
	    List<Element> listElement = node.elements();// ����һ���ӽڵ��list
	    for (Element e : listElement) {// ��������һ���ӽڵ�
	    	behaviour = getBehaviour(behaviour,e,fileName);// �ݹ�
	    }
		return behaviour;   
	}
	private static State setStateByUML(Element initStateElement, String fileName) throws DocumentException {
		// ��ȡUMLͼ�е�һ��״̬�����Ķ���豸����ֵ
		String stateName = initStateElement.attributeValue("name");
		State state = new State();
		state.setState(stateName);
		String baseStateID = initStateElement.attributeValue("id");
		Element State = GetElementByBaseState.getElement(baseStateID, fileName);
		List<String> stateTexts = new ArrayList <String>();
		// �ݹ������ǰ�ڵ����е��ӽڵ�
	    List<Element> listElement = State.elements();// ����һ���ӽڵ��list
	    if(listElement!=null && listElement.size()>0) {
		    for (Element e : listElement) {
		    	if(e.getName().equals("state")) {
		    		String text = e.getText();
		    		stateTexts.add(text);
		    	}
		    }
		    state.init(stateTexts);
	    }
		return state;
	}
	private static Transition setTranByUML(Element tranElement, String fileName) throws DocumentException {
		// ��ȡUML�е�transition\
		Transition tran = null;
		List<Trigger> triggers = new ArrayList<Trigger> ();
		List<Condition> conditions = new ArrayList<Condition>();
		List<Action> actions = new ArrayList<Action>();
		List<Element> TCAs;//trigger,condition and actions on the transition
		String tranID = tranElement.attributeValue("id");
		String sourceStateID = tranElement.attributeValue("source");
		String targetStateID = tranElement.attributeValue("target");
		State source;
		State target;
		TCAs = GetElementByBaseTranIdInXMLFile.getElement(tranID, fileName);
		//���transition���й����ͣ�˵����������Ҫ��ע��Ǩ�ƣ�����������ʼ�ͽ��������ӵ�Ǩ��
		if(TCAs!=null && TCAs.size()>0) {
			tran = new Transition();
			Element sourceState = GetElementByIdInXMLFile.getElement(sourceStateID, fileName);
			Element targetState = GetElementByIdInXMLFile.getElement(targetStateID, fileName);
			source = setStateByUML(sourceState,fileName);
			target = setStateByUML(targetState,fileName);
			for(Element tca:TCAs) {
				String tcaType = tca.getName();
				List<Element> listElements = tca.elements();// ����һ���ӽڵ��list
				  if(listElements!=null && listElements.size()>0) {
					  for (Element e : listElements) {
						  String Text = e.getText();
						  if(tcaType.equals("triggers")) {
							  Trigger trigger = new Trigger();
							  trigger.setTrigger(Text);
//							  System.out.println("------ " + trigger.getTrigger());

							  trigger.init(Text);  
//							  System.out.println("+++" + trigger.getDeviceAttrValue().getDevice());

							  triggers.add(trigger);
						  }
						  if(tcaType.equals("conditions")) {
							  Condition condition = new Condition();
							  condition.setCondition(Text);
							  condition.init(Text);
							  conditions.add(condition);
							  System.out.println("����condtion"+Text);
						  }
						  if(tcaType.equals("actions")) {
							  Action action = new Action();
							  action.setAction(Text);
							  action.init(Text);
							  actions.add(action);
						  }
					    }
				    }
			}
			tran.setSource(source);
			tran.setTarget(target);
			tran.setTrigger(triggers);
			tran.setCondition(conditions);
			tran.setActions(actions);
		}
		return tran;
	}
}
