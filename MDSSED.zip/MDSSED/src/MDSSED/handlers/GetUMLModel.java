package MDSSED.handlers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import MDSSED.utils.Action;
import MDSSED.utils.Attribute;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.GetElementByBaseState;
import MDSSED.utils.GetElementByBaseTranIdInXMLFile;
import MDSSED.utils.GetElementByIdInXMLFile;
import MDSSED.utils.GetInitStateElement;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;
import MDSSED.utils.genValuesOfAttrs;

public class GetUMLModel {
	public static BehaviourStateMachine main(String fileName) throws DocumentException, IOException{
	    	   File xmlFile = new File(fileName);
	    	   SAXReader sax = new SAXReader();
	    	   Document document = sax.read(xmlFile);
	    	   Element root = document.getRootElement();
			   BehaviourStateMachine behaviour = new BehaviourStateMachine();
			   File directory = new File("");

			   String capabilityFile = directory.getCanonicalPath() + "\\NuSMV-2.6.0-win64\\bin\\capabilities.txt"; 

			   List<Device> deviceAttrValues = genValuesOfAttrs.gen(capabilityFile);
			   behaviour = getBehaviour(behaviour, root, fileName);
    		   //Read UML models.
    		   if(behaviour!=null) {
    			   List<State> initStates = behaviour.getInitStates();
        		   if(initStates!=null) {
               		   for(State state:initStates) {
//      	        		   System.out.println("	Behaviour InitState--"+ state.getState()) ;	    
               			   List<DeviceAttrValue> DAVs = state.getDeviceAttrValues(); 
               			   if(DAVs!=null && DAVs.size()>0) {
               				   for(DeviceAttrValue DAV:DAVs) {
              					   if(DAV.getDevice()!=null && DAV.getAttribute()!=null && DAV.getValue()!=null) {

	               					   String device = DAV.getDevice();
	               					   String attribute = DAV.getAttribute();
	               					   String value = DAV.getValue();
	               					   if(device!=null) {
	               						  deviceInDoc(deviceAttrValues, device);
	               					   }
	               					   if(attribute!=null) {
	               						   attrInDoc(deviceAttrValues, device, attribute);
	               					   }
	               					   if(value!=null) {
	               						   valueInDoc(deviceAttrValues, device, attribute, value);
	               					   }
              					   }
//	        	        		 System.out.println("	       InitState--"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() + "value:" +DAV.getValue()) ;	    
               				   }
            			   }
            		   }
        		   }
    			   List<State> states = behaviour.getStates();
        		   if(states!=null) {
               		   for(State state:states) {
               			   List<DeviceAttrValue> DAVs = state.getDeviceAttrValues(); 
               			   if(DAVs!=null && DAVs.size()>0) {
               				   for(DeviceAttrValue DAV:DAVs) {
              					   if(DAV!=null && DAV.getDevice()!=null && DAV.getAttribute()!=null && DAV.getValue()!=null) {
	               					   String device = DAV.getDevice();
	               					   String attribute = DAV.getAttribute();
	               					   String value = DAV.getValue();
	               					   deviceInDoc(deviceAttrValues, device);
	               					   attrInDoc(deviceAttrValues, device, attribute);
	               					   valueInDoc(deviceAttrValues, device, attribute, value);
//	        	        		 System.out.println("	 --"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() + "value:" +DAV.getValue()) ;	    
              					   }
              					 }
            			   }
            		   }
        		   }
        		   List<Transition> trans = behaviour.getTrans();
        		   if(trans!=null) {
               		   for(Transition tran:trans) {
               			   List<Trigger> triggers = tran.getTriggers();
               			   List<Condition> conditions = tran.getConditions();
               			   List<Action> actions = tran.getActions();
//            			   if(tran.getSource()!=null) {
//        	        		   System.out.println("	  Transition--"+ "--source:"+tran.getSource().getState());	   
//            			   }
//            			   if(tran.getTarget()!=null) {
//        	        		   System.out.println("	  Transition--"+ "--target:"+tran.getTarget().getState());	   
//            			   }
            			   if(triggers!=null && triggers.size()>0) {
            				   for(Trigger trigger:triggers) {
                       			 DeviceAttrValue DAV = trigger.getDeviceAttrValue(); 
          					   if(DAV !=null && DAV.getDevice()!=null && DAV.getAttribute()!=null && DAV.getValue()!=null) {
             					   String device = DAV.getDevice();
             					   String attribute = DAV.getAttribute();
             					   String value = DAV.getValue();
             					   deviceInDoc(deviceAttrValues, device);
             					   attrInDoc(deviceAttrValues, device, attribute);
             					   valueInDoc(deviceAttrValues, device, attribute, value);
//	        	        		 System.out.println("	Behaviour trigger--"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() + DAV.getTrueOrFalse() +"��value:" +DAV.getValue() );	    
          					   	}
            				   }
            			   }
            			   if(conditions!=null && conditions.size()>0) {
            				   for(Condition c:conditions) {
            					   DeviceAttrValue DAV = c.getDeviceAttrValue(); 
            					   if(DAV!=null && DAV.getDevice()!=null && DAV.getAttribute()!=null && DAV.getValue()!=null) {
	               					   String device = DAV.getDevice();
	               					   String attribute = DAV.getAttribute();
	               					   String value = DAV.getValue();
	               					   deviceInDoc(deviceAttrValues, device);
	               					   attrInDoc(deviceAttrValues, device, attribute);
	               					   valueInDoc(deviceAttrValues, device, attribute, value);
	//            					   System.out.println("	Behaviour condition--"+ "device:"+DAV.getDevice() + "attr:" + DAV.getAttribute() +  DAV.getTrueOrFalse() +"value:" +DAV.getValue());	    
            					   }
            				   }
            			   }
            			   if(actions!=null && actions.size()>0) {
            				   for(Action a:actions) {
            					   if(a!=null && a.getCommandDevice()!=null) {
	               					   String device = a.getCommandDevice();
	               						  deviceInDoc(deviceAttrValues, device);
            					   }
//        					   System.out.println("	Behaviour action--"+ "device:" + a.getCommandDevice() + "command:" + a.getCommand() + "args:" +a.getCommandArgs());	    
            				   }
            			   }
            		   }
        		   }
    		   }
	   	return behaviour;
		}

	private static BehaviourStateMachine getBehaviour(BehaviourStateMachine behaviour,Element node,String fileName) throws DocumentException {
		//Recursively read all the model elements in the UML file
	    	List<State> initStates = new ArrayList<State>();
	    	List<State> states= new ArrayList<State>();
	    	List<Transition> trans= new ArrayList<Transition>();
	    	String behaviourName = "";
	    	String type = node.attributeValue("type"); 
		    if(type!=null && type.equals("uml:StateMachine")) {
		    	behaviourName = node.attributeValue("name");
	    			Element region = node.element("region");
	    			if(region!=null) {
		    	    	List<Element> regionSublist = region.elements();// List of child nodes.
		    	    	if(regionSublist!=null) {
			    			for(Element e1 : regionSublist) {
			    				//�ҳ�ʼ״̬�ڵ�
			    				if(e1.attributeValue("type")!=null & e1.attributeValue("type").equals("uml:Pseudostate")) {
			    					String e1ID = e1.attributeValue("id"); 
			    					Element initStateElement = GetInitStateElement.getElement(e1ID,fileName);
			    					State initState = setStateByUML(initStateElement,fileName);//Get UML states.
			    					initStates.add(initState);
			    				}
			    				
			    				//If the type of the node is "uml:State".
			    				if(e1.attributeValue("type")!=null & e1.attributeValue("type").equals("uml:State")) {
			    					State state = setStateByUML(e1,fileName);
			    					states.add(state);
			    				}
			    				//If the type of the node is "uml:Transition".
			    				if(e1.attributeValue("type")!=null & e1.attributeValue("type").equals("uml:Transition")) {
			    					Transition tran = setTranByUML(e1,fileName);
			    					if(tran!=null)
			    						trans.add(tran);
			    				}
			    			}
		    	    	}
	    			}
	    			// Add the states and transitions of the system  to the system behavior state machine.
	    			behaviour.setInitStates(initStates);
	    			behaviour.setStates(states);
	    			behaviour.setTrans(trans);
	    			behaviour.setName(behaviourName);
	    		}

		// Recursively iterate through all the child nodes of the current node.
	    List<Element> listElement = node.elements();
	    for (Element e : listElement) {
	    	behaviour = getBehaviour(behaviour,e,fileName);
	    }
		return behaviour;   
	}
	private static State setStateByUML(Element initStateElement, String fileName) throws DocumentException {
		// Read multiple device attribute values contained in a state in the UML diagram.
		String stateName = initStateElement.attributeValue("name");
		State state = new State();
		state.setState(stateName);
		String baseStateID = initStateElement.attributeValue("id");
		Element State = GetElementByBaseState.getElement(baseStateID, fileName);
		List<String> stateTexts = new ArrayList <String>();
		
		// Recursively iterate through all the child nodes of the current node.
	    List<Element> listElement = State.elements();
	    if(listElement!=null && listElement.size()>0) {
		    for (Element e : listElement) {
		    	if(e.getName().equals("state")) {
		    		String text = e.getText();
		    		stateTexts.add(text);
		    	}
		    }
		    state.init(stateTexts);
	    }
		return state;
	}
	private static Transition setTranByUML(Element tranElement, String fileName) throws DocumentException {
		// Get transitions in a UML model.
		Transition tran = null;
		List<Trigger> triggers = new ArrayList<Trigger> ();
		List<Condition> conditions = new ArrayList<Condition>();
		List<Action> actions = new ArrayList<Action>();
		List<Element> TCAs;//Trigger,condition and actions of the transition.
		String tranID = tranElement.attributeValue("id");
		String sourceStateID = tranElement.attributeValue("source");
		String targetStateID = tranElement.attributeValue("target");
		State source;
		State target;
		TCAs = GetElementByBaseTranIdInXMLFile.getElement(tranID, fileName);
		if(TCAs!=null && TCAs.size()>0) {
			tran = new Transition();
			Element sourceState = GetElementByIdInXMLFile.getElement(sourceStateID, fileName);
			Element targetState = GetElementByIdInXMLFile.getElement(targetStateID, fileName);
			source = setStateByUML(sourceState,fileName);
			target = setStateByUML(targetState,fileName);
			for(Element tca:TCAs) {
				String tcaType = tca.getName();
				List<Element> listElements = tca.elements();//The list of all the child nodes.
				  if(listElements!=null && listElements.size()>0) {
					  for (Element e : listElements) {
						  String Text = e.getText();
						  if(tcaType.equals("triggers")) {
							  Trigger trigger = new Trigger();
							  trigger.setTrigger(Text);
//							  System.out.println("------ " + trigger.getTrigger());
							  trigger.init(Text);  
//							  System.out.println("+++" + trigger.getDeviceAttrValue().getDevice());
							  triggers.add(trigger);
						  }
						  if(tcaType.equals("conditions")) {
							  Condition condition = new Condition();
							  condition.setCondition(Text);
							  condition.init(Text);
							  conditions.add(condition);
//							  System.out.println("The condition is:"+Text);
						  }
						  if(tcaType.equals("actions")) {
							  Action action = new Action();
							  action.setAction(Text);
							  action.init(Text);
							  actions.add(action);
						  }
					    }
				    }
			}
			tran.setSource(source);
			tran.setTarget(target);
			tran.setTrigger(triggers);
			tran.setCondition(conditions);
			tran.setActions(actions);
		}
		return tran;
	}
	public static String deviceInDoc(List<Device> deviceAttrValues, String device){
//		System.out.println("������������������������getPossibleValues��������������������" );	
//		System.out.println("-----device----" + device + "   attr:"+ attr );
		boolean deviceInDoc = false;
		String dn = "";
		for(Device d:deviceAttrValues) {
			String dName = d.getDevice().replace(" ", "");
//			System.out.println("device:" + device);
//
//			System.out.println("dName:" + dName);
			if(device.equalsIgnoreCase(dName)) {

				deviceInDoc = true;
				dn = dName;
			}
		}
		if(!deviceInDoc) {
			if(!device.equals("phone")) {
				JOptionPane.showMessageDialog(null, "Unknown device:"+ device,"Error" ,JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
		}
		return dn;
	}

	public static String attrInDoc(List<Device> deviceAttrValues, String device,String attr){
//		System.out.println("������������������������getPossibleValues��������������������" );	
//		System.out.println("-----device----" + device + "   attr:"+ attr );
		boolean deviceInDoc = false;
		boolean attrInDoc = false;
		String at = "";
		
		List<String> values = new ArrayList<String>();
		for(Device d:deviceAttrValues) {
			String dName = d.getDevice().replace(" ", "");
			List<Attribute> attrs = d.getAttrs();
			if(device.equalsIgnoreCase(dName)) {
				deviceInDoc = true;
				if(attrs!=null && attrs.size()>0) {
					for(Attribute a:attrs) {
						String aName = a.getAttr().replace(" ", "");
//						System.out.println("aName: "+ aName);
//						System.out.println("attr: "+ attr + "\r\n");

						if(aName.equalsIgnoreCase(attr)) {
							if(!attr.equals(aName)) {
								JOptionPane.showMessageDialog(null, "Case error (attribute): "+ attr +" should be written as "+ aName,"Error" ,JOptionPane.ERROR_MESSAGE);
								System.exit(0);
							}
							at = aName;
							attrInDoc = true;
							List<String> vs = a.getValues();
							if(vs!=null && vs.size()>0) {
								for(String s:vs) {
									String s1 = s;
									s1 = s1.replace("-","");
									s1 = s1.replace("'","");
									values.add(s1);			
								}
							}
						}
					}
				}
			}
		}
		if(!deviceInDoc) {
			JOptionPane.showMessageDialog(null, "Unknown device:"+ device,"Error" ,JOptionPane.ERROR_MESSAGE);
		}
		if(!attrInDoc) {
			JOptionPane.showMessageDialog(null, "Unknown attribute:"+ attr ,"Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		return at;
	}
	public static String valueInDoc(List<Device> deviceAttrValues, String device,String attr,String s){
		List<String> values =UML2NuSMV.getPossibleValues(deviceAttrValues,device,attr);
		boolean valueInDoc = false;
	if(values!=null && values.size()>0) {
		for(String v: values) {
			v = v.replace(" ", "");
//		System.out.println("v:" + v);
		if(v.contains("minimum:")) {
			int value = Integer.parseInt (s);
			int min = Integer.parseInt(v.split(":")[1]);
			if(value < min) {
				JOptionPane.showMessageDialog(null, "Value out of range"+"("+ v +")"+":"+ s,"Error" ,JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
			else {
				valueInDoc = true;
			}
		}
		if(v.contains("maximum:")) {
			int value = Integer.parseInt (s);
			int max = Integer.parseInt(v.split(":")[1]);
			if(value > max) {
				JOptionPane.showMessageDialog(null, "Value out of range"+"("+ v +")"+":"+ s,"Error" ,JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
			else {
				valueInDoc = true;
			}
		}
		if(s.equalsIgnoreCase(v)) {
			if(!s.equals(v)) {
				JOptionPane.showMessageDialog(null, "Case error (value): "+ s +" should be written as "+ v,"Error" ,JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
				valueInDoc = true;
				s = v;
			}
		}
	}
	else {
		valueInDoc = true;
	}
	if(!valueInDoc) {
		JOptionPane.showMessageDialog(null, "Unknown value:"+ s,"Error" ,JOptionPane.ERROR_MESSAGE);
		System.exit(0);
	}
	return s;
	}
}
