package threat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import MDSSED.handlers.UML2NuSMV;
import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class GenThreat1And5 {
	//T1,T5
	public static List<String> main(List<String> stateGroupList, String behaviourName, BehaviourStateMachine umlModel, String inList, List<String> nextList, List<Device> deviceAttrValues, String capabilityFile) throws IOException{
		   List<Transition> trans = umlModel.getTrans();
		   List<String> properties = new ArrayList<String>();
		   List<String> nextListNew = null;
		   List<String> nextListReturn = new ArrayList<String>();
		   if(trans!=null && trans.size()>0) {
			   for(Transition tran : trans) {
				   	   properties = new ArrayList<String>();
					   nextListNew = genThreat(stateGroupList, behaviourName, tran, nextList, deviceAttrValues, properties, capabilityFile);
					   if(properties!=null && properties.size()>0) {
						   nextListNew.add("Safety & Security Properties");
						   boolean allPropertiesExist = true;
						   if(properties!=null && properties.size()>0) {
							   for(String p:properties) {
								   if(!nextListReturn.contains(p))
									   allPropertiesExist = false;
							   }
						   }
						   if(allPropertiesExist == false) {
							   nextListNew.addAll(properties);	
							   nextListReturn.addAll(nextListNew);
							   nextListReturn.add("Next File");							   
						   }

					   }	   
			   }
//				System.out.println("-------threatForChange------\r\n" + threatForChange);
		   }
//			System.out.println("-------threat-------\r\n" + threat);
		   if(nextListReturn.size()>1 && nextListReturn.get(nextListReturn.size()-1).equals("Next File")) {
			   nextListReturn.remove(nextListReturn.size()-1);
		   }
		   if(nextListReturn!=null && nextListReturn.size()>0) {
//			   System.out.println("nextListReturnFinal:");
			   for(String s: nextListReturn) {
//				   System.out.println("			"+s);
			   }
		   }
		return nextListReturn;
	}
	
	public static List<String> genThreat(List<String> stateGroupList, String behaviourName, Transition tran,  List<String> nextList, List<Device> deviceAttrValues, List<String> properties, String capabilityFile) throws IOException {
		List<String> nextListNew = new ArrayList<String> (nextList);

		List<DeviceAttrValue> beforeDAVs = null;
		List<DeviceAttrValue> afterDAVs = null;
		   System.out.println("ִ��T1");

		State source = tran.getSource();
		State target = tran.getTarget();
		List<Action> actions = tran.getActions();
		List<String> actionDeviceList = new ArrayList<String>();
		if(actions!=null && actions.size()>0) {
			for(Action action:actions) {
				if(!action.getCommandDevice().equals("phone")) 
					actionDeviceList.add(action.getCommandDevice());
			}
		}
		   List<String> changes = UML2NuSMV.changeByAction(tran,capabilityFile);
		   List<String> afterChanges = new ArrayList<String>();
		   List<String> beforeChanges = new ArrayList<String>();
		   List<String> actionChangeDevices = new ArrayList<String>();

		   if(changes!=null && changes.size()>0) {
			   //Meet the occurrence condition of T1 - there is an operation to change the attribute value.
			   for(String change:changes) {
				   System.out.println("change:"+change);
				   String afterChange = change.split(" ### ")[1];
				   String beforeChange = change.split(" ### ")[0];
				   afterChanges.add(afterChange);
				   beforeChanges.add(beforeChange);
				   String s[] = beforeChange.split("_");
				   if(beforeChange.length()>0) {
					   actionChangeDevices.add(s[0]);
				   }
			   }
			   beforeDAVs = UML2NuSMV.initDAVsByStrings(beforeChanges);
			   afterDAVs = UML2NuSMV.initDAVsByStrings(afterChanges);
		   }	
		   if(beforeDAVs!=null && beforeDAVs.size()>0) {
			   if(afterDAVs!=null && afterDAVs.size()>0) {

				   String caseText = "";
				   int size = beforeDAVs.size();
				   for(int i = 0;i < size;i++) {
					   DeviceAttrValue davB = beforeDAVs.get(i) ;
					   DeviceAttrValue davA = afterDAVs.get(i) ;
					   
						if(davA.getTrueOrFalse().equals("==")) {
							 caseText = davA.getDevice() + "_" + davA.getAttribute() + " = " + davA.getValue() ;						
						}
						else {
							 caseText = davA.getDevice() + "_" + davA.getAttribute() + " != " + davA.getValue() ;						
						}
					   String device = davB.getDevice();
					   String attr = davB.getAttribute();
					   String value = davB.getValue();
					   String next = "";
					   String trueOrFalse = davB.getTrueOrFalse();
					   String valueA = davA.getValue();
					   String trueOrFalseA = davA.getTrueOrFalse();
					   if(existInTrigConAct(tran, device) && !device.contains("Sensor") && !device.contains("Detector")) {
						   if(trueOrFalse.equals("==")) {
								next = "(" + caseText + "):" +value;
							}
							else {
								List<String> otherValues = UML2NuSMV.getPossibleValues(deviceAttrValues,device, attr);
								if(otherValues!=null && otherValues.size()>0) {
									for(String otherValue:otherValues) {
										if(!otherValue.equals(value))
											next = next + otherValue + ", "; 
									}
									next = next.substring(0,next.length() - 2);
									next =  "(" + caseText + "):" + "{" + next + "}";	
								}
							}   
					   }
					   boolean alreadyIn = false;
					   String propertyUnderT1AndT5 = "";
					   String targetState = target.getState();
					   int index = UML2NuSMV.getStateIndex(targetState, stateGroupList);
					   List<DeviceAttrValue> DAVsTarget = target.getDeviceAttrValues();
					   String DAVsTargetList ="";
					   if(DAVsTarget != null && DAVsTarget.size()>0) {
						   for(DeviceAttrValue DAV: DAVsTarget) {
							   String d = DAV.getDevice();
							   String a = DAV.getAttribute();
							   String v = DAV.getValue();
							   String tOrF = DAV.getTrueOrFalse();
							   System.out.println("tOrF:"+tOrF);
							   if(existInTrigConAct(tran, d)) {
								   if((d.equals(device)&&a.equals(attr)&&tOrF.equals(trueOrFalseA)&&v.equals(valueA))==false) {
									   if(tOrF.equals("==")) {
										   if(d.equals(device) && a.equals(attr))
											   DAVsTargetList = DAVsTargetList + d + "." + a + " != " + v + " & ";//�����м��δʵ�������ĸ�ֵ������ȡ��
										   else {
											   if(!actionChangeDevices.contains(d))
												   DAVsTargetList = DAVsTargetList + d + "." + a + " = " + v + " & ";
										   }
									   }
									   else {
										   if(d.equals(device) && a.equals(attr))
											   DAVsTargetList = DAVsTargetList + d + "." + a + " = " + v + " & ";
										   else {
											   if(!actionChangeDevices.contains(d)) 
												   DAVsTargetList = DAVsTargetList + d + "." + a + " != " + v + " & ";
										   }
									   }
								   }								   
							   }

						   }

					   }
					   List<String> targetStates = target.getDeviceStates();
					   if(targetStates!=null && targetStates.size()>0) {
						   if(targetStates.contains("now() > getSunriseAndSunset().sunrise.time") && targetStates.contains("now() < getSunriseAndSunset().sunset.time"))
							   DAVsTargetList = DAVsTargetList + behaviourName + ".now = betweenSunsetAndSunrise & ";
						   if(targetStates.contains("now() > getSunriseAndSunset().sunset.time"))
							   DAVsTargetList = DAVsTargetList + behaviourName + ".now = notBetweenSunsetAndSunrise & ";
					   }
						   
					   if(nextListNew!=null && nextListNew.size()>0) {
						   int size1 = nextListNew.size();
						   for(int i1=0;i1<size1;i1++) {
							   if(!next.equals("")) {
								   if(nextListNew.get(i1).equals("next("+ device + "_" + attr +"):=case")) {
									   nextListNew.add(i1+1,"\t" + next +";--/*Threat 1*/");
									   size1++;
									   propertyUnderT1AndT5 = "CTLSPEC !EF(("+ behaviourName +".state"+ index + " = " + targetState +" & "+ DAVsTargetList;
									   if(trueOrFalseA.equals("==")) {
										   if(!propertyUnderT1AndT5.contains(device + "." + attr))
											   propertyUnderT1AndT5 = propertyUnderT1AndT5 + device + "." + attr + " != " + valueA + ") & EX("+ behaviourName +".state"+ index +" = "+ targetState +" & " + DAVsTargetList +  device + "." + attr + " != " + valueA +"));"+"--/*For threat 1*/\r\n";
										   else
											   propertyUnderT1AndT5 = propertyUnderT1AndT5.substring(0,propertyUnderT1AndT5.length() - 3)+ ") & EX("+ behaviourName +".state"+ index +"= "+ targetState  +" & " + DAVsTargetList.substring(0,DAVsTargetList.length() - 3) + "));"+"--/*For threat 1*/\r\n";

										   if(!properties.contains(propertyUnderT1AndT5))
											   properties.add(propertyUnderT1AndT5);
									   }
									   else {
										   if(!propertyUnderT1AndT5.contains(device + "." + attr))
											   propertyUnderT1AndT5 = propertyUnderT1AndT5 + device + "." + attr + " = " + valueA + ") & EX("+ behaviourName +".state"+ index +"= "+ targetState +" & " + DAVsTargetList + device + "." + attr + " = " + valueA +"));"+"--/*For threat 1*/\r\n";
										   else
											   propertyUnderT1AndT5 = propertyUnderT1AndT5.substring(0,propertyUnderT1AndT5.length() - 3) + ") & EX("+ behaviourName +".state"+ index +"= "+ targetState +" & " + DAVsTargetList.substring(0,DAVsTargetList.length() - 3) +"));"+"--/*For threat 1*/\r\n";
										   if(!properties.contains(propertyUnderT1AndT5))
											   properties.add(propertyUnderT1AndT5);
									   }
//									   System.out.println("P:"+ propertyUnderT1AndT5);

									   alreadyIn = true;
								   } 
							   }
						   }
					   }
					   if(alreadyIn == false) {
						   if(!next.equals("")) {
							   nextListNew.add("next("+ device + "_" + attr +"):=case");
							   nextListNew.add("\t" + next +";--/*Threat 1*/");
							   nextListNew.add("\tTRUE:"+ device + "_" + attr +";\r\nesac;");
//							   System.out.println("nextListNew:"+ "\t" + next +";--/*Threat 1*/");
							   propertyUnderT1AndT5 = "CTLSPEC !EF(("+ behaviourName +".state"+ index + " = " + targetState +" & "+ DAVsTargetList;
							   if(trueOrFalseA.equals("==")) {
								   if(!propertyUnderT1AndT5.contains(device + "." + attr))
									   propertyUnderT1AndT5 = propertyUnderT1AndT5 + device + "." + attr + " != " + valueA + ") & EX("+ behaviourName +".state"+ index +" = "+ targetState +" & " + DAVsTargetList +  device + "." + attr + " != " + valueA +"));"+"--/*For threat 1*/\r\n";
								   else
									   propertyUnderT1AndT5 = propertyUnderT1AndT5.substring(0,propertyUnderT1AndT5.length() - 3) + ") & EX("+ behaviourName +".state"+ index +"= "+ targetState +" & " +DAVsTargetList.substring(0,DAVsTargetList.length() - 3) +"));"+"--/*For threat 1*/\r\n";
								    if(!properties.contains(propertyUnderT1AndT5))
								    	properties.add(propertyUnderT1AndT5);
							   }
							   else {
								   if(!propertyUnderT1AndT5.contains(device + "." + attr))
									   propertyUnderT1AndT5 = propertyUnderT1AndT5 + device + "." + attr + " = " + valueA + ") & EX("+ behaviourName +".state"+ index +"= "+ targetState +" & " + DAVsTargetList + device + "." + attr + " = " + valueA +"));"+"--/*For threat 1*/\r\n";
								   else
									   propertyUnderT1AndT5 = propertyUnderT1AndT5.substring(0,propertyUnderT1AndT5.length() - 3) + ") & EX("+ behaviourName +".state"+ index +"= "+ targetState +" & " + DAVsTargetList.substring(0,DAVsTargetList.length() - 3)  +"));"+"--/*For threat 1*/\r\n";
								    if(!properties.contains(propertyUnderT1AndT5))
								    	properties.add(propertyUnderT1AndT5);
							   }							   
						   }
					   }
				   }
			   }
		   }

			 return nextListNew;
	}
	private static boolean existInTrigConAct(Transition tran, String d) {
		boolean exist = false;
		List<Trigger> triggers = tran.getTriggers();
		List<Condition> conditions = tran.getConditions();
		List<Action> actions = tran.getActions();
		if(triggers != null && triggers.size()>0) {
			for(Trigger trigger:triggers) {
				if(trigger.getTrigger().contains(d))
					exist = true;
			}
		}
		if(conditions != null && conditions.size()>0) {
			for(Condition condition:conditions) {
				if(condition.getCondition().contains(d))
					exist = true;
			}
		}
		if(actions != null && actions.size()>0) {
			for(Action action:actions) {
				if(!action.getCommandDevice().equals("phone")) {
					if(action.getAction().contains(d))
						exist = true;
				}
			}
		}
		System.out.println("deviceexist:"+exist + "d:"+d);
		return exist;
	}
}
