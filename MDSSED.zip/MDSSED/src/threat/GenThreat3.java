package threat;


import java.util.ArrayList;
import java.util.List;

import MDSSED.handlers.UML2NuSMV;
import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;
import MDSSED.utils.Attribute;

public class GenThreat3 {
	//T3
	public static String main( BehaviourStateMachine umlModel, List<Device> devices, List<String> properties, List<Device> deviceAttrValues)  {
		   String threat = "";
		   List<Transition> trans = umlModel.getTrans();
		   threat = threat + genThreat(trans, devices, properties, deviceAttrValues);
//		   System.out.println("-------threat3-------\r\n" + threat);
		return threat;
	}
	public static String genThreat(List<Transition> trans,  List<Device> devices, List<String> properties, List<Device> deviceAttrValues) {
		//Generate the threat model.
		String threat = "";
		String inListText = "";
		List<String> nextList = new ArrayList<String>();
		String VAR = "";
		List<String> Vars = new ArrayList<String> ();
		List<String> inList = new ArrayList<String>();
		if(trans!=null && trans.size()>0) {
			for(Transition tran :trans) {
					List<Trigger> triggers = tran.getTriggers();
					List<DeviceAttrValue> DAVsInTrigger = null;
					List<String> attrsInTriggers = null; 
					//Iterate through all the triggers of the transition and retrieve the values of the device attributes that may be inferred.
					if(triggers!=null && triggers.size()>0) {
						DAVsInTrigger = new ArrayList<DeviceAttrValue>();
						attrsInTriggers = new ArrayList<String>();//Attributes in the triggers.
						for(Trigger trigger: triggers) {
							DeviceAttrValue DAVInTrigger = trigger.getDeviceAttrValue();
							DAVsInTrigger.add(DAVInTrigger);//DAV in triggers

							String device = trigger.getDeviceAttrValue().getDevice();
							String attr = trigger.getDeviceAttrValue().getAttribute();
							if(!attrsInTriggers.contains(device + "_" + attr))
								attrsInTriggers.add(device + "_" + attr);
						}
					}
					String caseText = "";
					String caseTexts = "";
				    List<DeviceAttrValue> DAVchange = satThreatOccurCondition(tran);
					if(DAVchange!=null && DAVchange.size()>0) {
						if(DAVsInTrigger!=null && DAVsInTrigger.size()>0) {
							for(DeviceAttrValue DAVch:DAVchange) {
								String device = DAVch.getDevice();
								String attr = DAVch.getAttribute();
								if(inList.contains(device + "_" + attr)==false)
									inList.add(device + "_" + attr);
								if(DAVch.getTrueOrFalse().equals("==")) {
									caseText = device + "_" + attr + " = " + DAVch.getValue() + " & ";						
								}
								else {
									caseText = device + "_" + attr + " != " + DAVch.getValue() + " & ";						
								}							
								caseTexts = caseTexts + caseText;
							}
							caseTexts = caseTexts.substring(0,caseTexts.length() - 3);
							for(DeviceAttrValue DAVInTrgger:DAVsInTrigger) {
							   String device = DAVInTrgger.getDevice();
							   String attr = DAVInTrgger.getAttribute();
							   String value = DAVInTrgger.getValue();
							   String next = "";
							   String trueOrFalse = DAVInTrgger.getTrueOrFalse();
							   String property = "";
							   boolean alreadyIn = false;
							   List<String> otherValues = UML2NuSMV.getPossibleValues(deviceAttrValues,device, attr);
							   if(trueOrFalse.equals("==")) {
								   property = "CTLSPEC !EF(" + caseTexts.replace("_", ".") + " & EX(" + "threat3.infer_" + device + "_" + attr + " = " + value + "))--/*For threat 3*/\r\n";
								   next = "(" + caseTexts + "):" +value;
								    if(!properties.contains(property))
								    	properties.add(property);

							   }
							   else {
									if(otherValues!=null && otherValues.size()>0) {
										for(String otherValue:otherValues) {
											if(!otherValue.equals(value)) {
												property = property + otherValue + ", ";
												next = next + otherValue + ", "; 
											}
										}
										property = property.substring(0,property.length() - 2);
										property = "CTLSPEC !EF(" + caseTexts.replace("_", ".") + " & EX(" + "threat3.infer_" + device + "_" + attr + " = {"+ property + "}))--/*For threat 3*/\r\n";
									    if(!properties.contains(property))
									    		properties.add(property);
										next = next.substring(0,next.length() - 2);
										next =  "(" + caseText + "):" + "{" + next + "}";	
									}
							   }
							   if(nextList!=null && nextList.size()>0) {
								   int size = nextList.size();
								   for(int i=0;i<size;i++) {
									   if(nextList.get(i).equals("next(" + "infer_" + device + "_" + attr +"):=case")) {
										   nextList.add(i+1,"\t" + next + ";");
										   size++;
										   alreadyIn = true;
									   } 
								   }
							   }
							   if(alreadyIn == false) {
								   nextList.add("next(" + "infer_"+ device + "_" + attr +"):=case");
								   nextList.add("\t" + next +";");
								   nextList.add("\tTRUE:"+ "infer_" + device + "_" + attr +";\r\nesac;");
								   
							   }
					
							}
						}
					}
					List<String> DAInAction = new ArrayList<String>();
					if(DAVchange!=null && DAVchange.size()>0) {
						for(DeviceAttrValue davInAction:DAVchange) {
							DAInAction.add(davInAction.getDevice()+"_"+davInAction.getAttribute());
						}						
					}
					if(attrsInTriggers!=null && attrsInTriggers.size()>0) {
						for(String de_attr : attrsInTriggers) {
							if(!DAInAction.contains(de_attr)) {
								Vars.add(de_attr);
							}
						}						
					}
			}
			 //Generate inListText---input parameters.
			 if(inList!=null && inList.size()>0) {
				for(String s:inList) {
					inListText = inListText + s +", "; 
				   }			   
				inListText = inListText.substring(0,inListText.length() - 2);
			   }
			//Generate VAR---Inferred attribute values in triggers.
			if(devices!=null && devices.size()>0) {
				for(Device device:devices) {
					String dName = device.getDevice().replace(" ","");
					dName = toLowerCaseFirstOne(dName);
					List<Attribute> attrs =device.getAttrs();
					if(attrs != null && attrs.size()>0) {
						for(Attribute attr:attrs) {
							String aName = attr.getAttr().replace(" ", "");						
							if(Vars!=null && Vars.contains(dName + "_" + aName)) {
								VAR = VAR + "\tinfer_" + dName + "_" + aName + " :{null, ";
								List<String> values = attr.getValues();
								if(values!=null && values.size()>0) {
									for(String value:values) {
										VAR = VAR + value + ", ";
									}
									VAR = VAR.substring(0,VAR.length() - 2);
									VAR = VAR + "};\r\n";											
								} 
							}
						}
					}
				}
			}
			if(!VAR.equals("")) {
				VAR = "VAR\r\n" + VAR;
			}

			String init = "";
			if(Vars!=null && Vars.size()>0) {
				for(String var:Vars) {
					init = init + "infer_" + var + " = null & "; 
				}
			}
			if(!init.equals("")) {
				init = init.substring(0,init.length() - 3);
				init = "INIT\r\n" + "\t" + init + ";\r\n";
				threat = "MODULE threat3(" + inListText + ")\r\n";
				threat = threat + VAR;
				threat = threat + init;
				String transText = "";
			    if(nextList!=null && nextList.size()>0) {
				    for(String s: nextList) {
				 	   transText = transText + s + "\r\n";
				    }
			    }
				threat = threat + "ASSIGN\r\n" + transText;	
			}

		}
		return threat;
	}
	
	public static List<DeviceAttrValue> satThreatOccurCondition(Transition tran) {
		/*Satisfies the conditions for T3 to occur - subscribes to the properties of a certain device and uses this as 
		a trigger event to perform changes to the properties of another device.*/
		List<DeviceAttrValue> DAVchange = null;
		State source = tran.getSource();
		State target = tran.getTarget();
		List<Trigger> triggers = tran.getTriggers();
		List<String> attrsInTriggers = null; 
		if(triggers!=null && triggers.size()>0) {
			attrsInTriggers = new ArrayList<String>();
			for(Trigger trigger:triggers) {
				String device = trigger.getDeviceAttrValue().getDevice();
				String attr = trigger.getDeviceAttrValue().getAttribute();
				if(!attrsInTriggers.contains(attr+device))
					attrsInTriggers.add(attr+device);
			}
		}
		List<Action> actions = tran.getActions();
		List<String> actionDeviceList = new ArrayList<String>();
		if(actions!=null && actions.size()>0) {
			for(Action action:actions) {
				if(!action.getCommandDevice().equals("phone")) 
					actionDeviceList.add(action.getCommandDevice());
			}
		}
		List<DeviceAttrValue> DAVsInSource = source.getDeviceAttrValues();
		List<DeviceAttrValue> DAVsInTarget = target.getDeviceAttrValues();
		if(DAVsInSource!=null && DAVsInSource.size()>0 && DAVsInTarget!=null && DAVsInTarget.size()>0) {
			for(DeviceAttrValue tDAV :DAVsInTarget) {
				for(DeviceAttrValue sDAV :DAVsInSource) {
					if(tDAV.getDevice().equals(sDAV.getDevice())) {
						if(tDAV.getAttribute().equals(sDAV.getAttribute())) {
							if((tDAV.getValue().equals(sDAV.getValue()) && (tDAV.getTrueOrFalse().equals(sDAV.getTrueOrFalse())==false)) || (tDAV.getValue().equals(sDAV.getValue()) ==false)) {
								if(actionDeviceList.contains(tDAV.getDevice()) ) {
									if(attrsInTriggers!=null && attrsInTriggers.size()>0 && attrsInTriggers.contains(tDAV.getDevice()+tDAV.getAttribute()))
										attrsInTriggers.remove(tDAV.getDevice()+tDAV.getAttribute());
									if(attrsInTriggers != null && attrsInTriggers.size()>0) {
										DAVchange = new ArrayList<DeviceAttrValue>();
										DAVchange.add(tDAV);
									}
 								}
							}
						}
					}
				}
			}
		}
		return DAVchange;
	}

	public static String toLowerCaseFirstOne(String s)
	{
	  if(Character.isLowerCase(s.charAt(0)))
	      return s;
	  else
	      return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0))).append(s.substring(1)).toString();
	}
}
