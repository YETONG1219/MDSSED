package threat;

import java.util.ArrayList;
import java.util.List;

import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class GenThreat9 {
	//T9
	public static String main( BehaviourStateMachine umlModel, String actionListText,String inListText) {

		   List<Transition> trans = umlModel.getTrans();
		   List<String> actionTranList = new ArrayList<String>();
		   if(trans!=null && trans.size()>0) {
			   for(Transition tran:trans) {
				   actionTranList = setTranForAction(tran,actionTranList);
			   }
		   }
		   String threat = "MODULE threat9";
		   threat = threat + "(" + inListText + ")\r\n";

		   threat = threat + "VAR\r\n" + actionListText;
		   if(actionTranList!=null && actionTranList.size()>0) {
			   for(String actionTran:actionTranList) {
				   threat = threat + actionTran;
			   }
		   }
//		   System.out.println("-------threat9-------\r\n" + threat);
		return threat;
	}
	public static List<String> setTranForAction(Transition tran, List<String> actionTranList) {
		String tranText = "";
		   List<Trigger> triggers = tran.getTriggers();
		   for(Trigger trigger:triggers) {
			   DeviceAttrValue deviceAttrValue = trigger.getDeviceAttrValue();
			   String device = deviceAttrValue.getDevice();
			   String attr = deviceAttrValue.getAttribute();
			   String value = deviceAttrValue.getValue();
			   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
			   if(trueOrFalse.equals("=="))
				   tranText = tranText + device + "_" + attr + " != " + value + " & next(" + device + "_" + attr + ") = " + value + " & ";
			   else
				   tranText = tranText + device + "_" + attr + " = " + value + " & next(" + device + "_" + attr + ") != " + value  + " & ";
		   }
		   List<Condition> conditions = tran.getConditions();
		   for(Condition condition:conditions) {
			   DeviceAttrValue deviceAttrValue = condition.getDeviceAttrValue();
			   String device = deviceAttrValue.getDevice();
			   String attr = deviceAttrValue.getAttribute();
			   String value = deviceAttrValue.getValue();
			   String trueOrFalse = deviceAttrValue.getTrueOrFalse();
			   if(trueOrFalse.equals("=="))
				   tranText = tranText + device + "_" + attr + " = " + value + " & ";
			   else
				   tranText = tranText + device + "_" + attr + " != " + value + " & ";
		   }
		   tranText = tranText.substring(0,tranText.length() - 3);
			List<Action> actions = tran.getActions();
			if(actions!=null && actions.size()>0) {
				for(Action action:actions) {
				   String command = action.getCommand();
				   String deviceName = action.getCommandDevice();
				   List<String> args = action.getCommandArgs();

				   String actionText = "";
				   if(args!=null && args.size()>0) {
					   for(String arg:args) {
						   arg = arg.replace("\"", "");
						   actionText = actionText + "_" + arg;
					   }
				   }
				   actionText = "action_" +  deviceName + "_" + command + actionText;
				   boolean stateAlreadyIn = false;
				   if(actionTranList!=null && actionTranList.size()>0) {
					   int size = actionTranList.size();
					   for(int i=0;i<size;i++) {
						   if(actionTranList.get(i).contains("next(action_"+ deviceName +")") && !actionTranList.contains("\t(" + tranText + "): " + "next(action_"+ deviceName +")" + " = " + actionText + ";\r\n")){
							   actionTranList.add(i+1,"\t(" + tranText + "): " + "next(action_"+ deviceName +")"  + " = " + actionText + ";\r\n");
							   size++;
							   stateAlreadyIn = true;
						   }
					   }
				   }
				   if(stateAlreadyIn == false) {

					   actionTranList.add("TRANS\r\ncase\r\n");
					   actionTranList.add("\t(" + tranText + "): " + "next(action_"+ deviceName +")"  + " = " + actionText + ";\r\n");
					   actionTranList.add("\tTRUE:" + "next(action_"+ deviceName +") = " + "action_"+ deviceName +  ";\r\nesac;\r\n");
				   }	
				}
			}
		  
		   return actionTranList;
	}

}
