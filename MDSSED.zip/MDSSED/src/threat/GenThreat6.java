package threat;

import java.util.ArrayList;
import java.util.List;

import MDSSED.handlers.UML2NuSMV;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class GenThreat6 {
	//T6:����������㽻��
	public static String main( BehaviourStateMachine umlModel, List<Device> deviceAttrValues, String behaviourName, List<String> properties) {
		   //umlModel��ȡUMLģ��,devices��ȡ�豸���Կ��ܵ�ֵ
		   //����transΪ����������trans������вģ��
		   String threat = "";
		   List<Transition> trans = umlModel.getTrans();
		   threat = threat + genVars(trans,deviceAttrValues) + genTrans(trans);
		   if(!threat.equals(""))
			   threat = "MODULE threat6\r\n" + threat;			   
//		   System.out.println("-------threat4-------\r\n" + threat);
		   properties = genProperties(trans, behaviourName, properties);
//		   System.out.println("-------threat6-------\r\n" + properties);

		return threat;
	}
	public static List<String> genProperties(List<Transition> trans, String behaviourName, List<String> properties) {
		String property = "";
		List<DeviceAttrValue> vars = genThreat(trans);
	    for(DeviceAttrValue var:vars) {
		    String d = var.getDevice();
		    String a = var.getAttribute();
		    property = "CTLSPEC !EF("+ behaviourName +"."+ d + "_" + a +" != " + d + "." + a + ")--/*For threat 6*/\r\n";
		    if(!properties.contains(property))
		    	properties.add(property);

	    }
		return properties;    
	}
	public static String genVars(List<Transition> trans, List<Device> deviceAttrValues) {
		String varsText = "";
		List<DeviceAttrValue> vars = genThreat(trans);
		if(vars !=null && vars.size()>0) {
		    for(DeviceAttrValue var:vars) {
			    String d = var.getDevice();
			    String a = var.getAttribute();
			    String varValue = "";
				List<String> otherValues = UML2NuSMV.getPossibleValues(deviceAttrValues, d, a);
				if(otherValues!=null && otherValues.size()>0) {
					for(String otherValue:otherValues) {
						if(otherValue.contains("minimum")) {
							String numMin = otherValue.split(":")[1];
							varValue = varValue + numMin;
						}
						else if(otherValue.contains("maximum")) {
							varValue = varValue + ".." + otherValue.split(":")[1];
						}
						else
							varValue = varValue + otherValue + ", ";
					}
					if(varValue.contains("..")) {
						varValue = d + "_" + a + ":" + varValue + ";\r\n";						

					}
					else {
						varValue = varValue.substring(0,varValue.length() - 2);//ɾ������ġ��� ��
						varValue = d + "_" + a + ":{" + varValue + "};\r\n";						
					}

					if(!varsText.contains(varValue))
						varsText = varsText + varValue;
				}
		    }
			varsText = "VAR\r\n" + varsText; 			
		}
		return varsText;
	}
	public static String genTrans(List<Transition> trans) {
		   String transText = "";
		   List<DeviceAttrValue> vars = genThreat(trans);
		   if(vars!=null && vars.size()>0) {
			   transText = "";
			   for(DeviceAttrValue var:vars) {
				   String d = var.getDevice();
				   String a = var.getAttribute();
				   String v = var.getValue();
				   String trueOrFalse = var.getTrueOrFalse();
				   if(trueOrFalse.equals("==")) {
					   String addString = "TRANS\r\ncase\r\n" + 
						   		"\t("+ d +"_"+ a +" != "+ v +"): next("+ d +"_"+ a +") = " + v + ";\r\n" + 
						   		"\tTRUE : "+ d +"_"+ a +" = "+ v +";\r\n" + 
						   		"esac;\r\n";
					   if(!transText.contains(addString))
						   transText = transText + addString;
				   }
				   else {
					   String addString = "TRANS\r\ncase\r\n" + 
						   		"\t("+ d +"_"+ a +" = "+ v +"): next("+ d +"_"+ a +") != " + v + ";\r\n" + 
						   		"\tTRUE : "+ d +"_"+ a +" != "+ v +";\r\n" + 
						   		"esac;\r\n";
					   if(!transText.contains(addString))
						   transText = transText + addString;
				   }
			   }
		   }
		return transText;
	}

	public static List<DeviceAttrValue> genThreat(List<Transition> trans) {
		List<DeviceAttrValue> vars = new ArrayList<DeviceAttrValue>();
		if(trans!=null && trans.size()>0) {
			for(Transition tran:trans) {
				if(satThreatOccurCondition(tran)) {
					List<Condition> cons = tran.getConditions();
					if(cons!=null && cons.size()>0) {
						for(Condition con:cons) {
							DeviceAttrValue DAV = con.getDeviceAttrValue();
							if(DAV!=null)
								vars.add(DAV);
						}
					}					
				}
			}
		}
		return vars;
	}
	
	public static boolean satThreatOccurCondition(Transition tran) {
		//����T4�ķ�����������������ĳ���豸�����ԣ����Դ�Ϊ�����¼���ִ��action��
		if(tran.getConditions()!=null && tran.getActions()!=null)
			return true;
		return false;
	}
}
