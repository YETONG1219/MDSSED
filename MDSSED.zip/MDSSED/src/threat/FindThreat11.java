package threat;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class FindThreat11 {
	//Design error: T11
	public static String main(BehaviourStateMachine umlModel) {
		String T11Result = "";
		List<String> threatList = findT11(umlModel);
		if(threatList!=null && threatList.size()>0) {
			for(String threat:threatList) {
				String trigger1 = threat.split(" ### ")[0];
				String trigger2 = threat.split(" ### ")[1];
				String action = threat.split(" ### ")[2];
				T11Result = T11Result + "\n\n---------------Design error: exclusive event coordination (T11)-----------------------\n";
				T11Result = T11Result + "Warning�� the model is under exclusive event coordination threat (T11) where the same action is triggered by mutually exclusive events.\n";
				if(action.contains("*")) {
					action.replace("*", ",");
					T11Result = T11Result + "There exist actions "+ "\"" + action  + "\"" + " triggerd by mutually exclusive events " +  "\"" + trigger1 +  "\"" + " and " +  "\"" + trigger2 + "\"" + ".\n";
				}
				else {
					action.replace("*", ",");
					T11Result = T11Result + "There exists action "+ "\"" + action  + "\"" + " triggerd by mutually exclusive events " +  "\"" + trigger1 +  "\"" + " and " +  "\"" + trigger2 + "\"" + ".\n";
				}
			}
		}
		else {
			T11Result = T11Result + "------There is no exclusive event coordination error (T11) in the model.------\n";

		}
//		System.out.println(T11Result);
		return T11Result;

	}
	public static List<String> findT11(BehaviourStateMachine umlModel){
//		The MDSSED tool detects the threat of such interactions by checking whether all transitions with the same action migration are mutually exclusive
		List<String> mutuallyExclusiveTriggerOfSameAction = new ArrayList<String>();
		List<Transition> trans = umlModel.getTrans();
		if(trans!=null && trans.size()>0) {
			for(Transition tran : trans) {
				List<Trigger> triggers = tran.getTriggers();
				List<DeviceAttrValue> DAVsInTrigger = new ArrayList<DeviceAttrValue>();
				if(triggers!=null && triggers.size()>0) {
					for(Trigger trigger : triggers) {
						DAVsInTrigger.add(trigger.getDeviceAttrValue());
					}
				}
				List<Action> actions = tran.getActions();
				String devicesInActions = "";
				if(actions!=null && actions.size()>0) {
					for(Action action : actions){
						if(!action.getCommandDevice().equals("phone")) {
							String actionText = action.getAction();
							if(actionText.contains("runIn")) {
								String s1[] = actionText.split(", ");
								actionText = s1[1];
								actionText = actionText.substring(0,actionText.length() - 1);
								devicesInActions = devicesInActions + actionText + ", ";
	
							}
							else {
								devicesInActions = devicesInActions + actionText + ", ";
	
							}
						}
					}
					devicesInActions = devicesInActions.substring(0,devicesInActions.length() - 2);

				}

				if(triggers != null && triggers.size()>0) {
					int size = triggers.size();
					for(int i=0; i<size; i++) {
						for(int j=i+1; j<size; j++) {
							DeviceAttrValue DAV1 = DAVsInTrigger.get(i);
							DeviceAttrValue DAV2 = DAVsInTrigger.get(j);
							String device1 = DAV1.getDevice();
							String attr1 = DAV1.getAttribute();
							String trueOrFalse1 = DAV1.getTrueOrFalse();
							String value1 = DAV1.getValue();						
							String device2 = DAV2.getDevice();
							String attr2 = DAV2.getAttribute();
							String trueOrFalse2 = DAV2.getTrueOrFalse();
							String value2 = DAV2.getValue();							
							if((device1.equals(device2) && attr1.equals(attr2) && !trueOrFalse1.equals(trueOrFalse2) && value1.equals(value2))||(device1.equals(device2) && attr1.equals(attr2) && trueOrFalse1.equals("==") && trueOrFalse2.equals("==") && !value1.equals(value2))) {
								mutuallyExclusiveTriggerOfSameAction.add(triggers.get(i).getTrigger() + " ### " + triggers.get(j).getTrigger() + " ### " +  devicesInActions);
							}
						}
					}

				}
			}

			int size = trans.size();
			for(int i=0; i<size; i++) {
				for(int j=i+1; j<size; j++) {
					mutuallyExclusiveTriggerOfSameAction = mutuallyExclusiveTriggerOfSameAction(trans.get(i), trans.get(j), mutuallyExclusiveTriggerOfSameAction);
				}
			}
		}
		return mutuallyExclusiveTriggerOfSameAction;
	}
	private static List<String> mutuallyExclusiveTriggerOfSameAction(Transition tran1, Transition tran2, List<String> mutuallyExclusiveTriggerOfSameAction){
		List<String> sameActions = tranHaveSameAction(tran1,tran2);
		String sameAction = StringUtils.join(sameActions, "* ");
		
		if(sameActions!=null && sameActions.size()>0) {
			List<Trigger> triggers1 = tran1.getTriggers();
			List<Condition> cons1 = tran1.getConditions();
			List<DeviceAttrValue> DAVsInTrigger1 = new ArrayList<DeviceAttrValue>();
			List<Trigger> triggers2 = tran2.getTriggers();
			List<Condition> cons2 = tran2.getConditions();			
			List<DeviceAttrValue> DAVsInTrigger2 = new ArrayList<DeviceAttrValue>();
			List<String> triggers1TextList = new ArrayList<String>();
			List<String> triggers2TextList = new ArrayList<String>();
			List<String> cons1TextList = new ArrayList<String>();
			List<String> cons2TextList = new ArrayList<String>();
			for(Trigger trigger1 : triggers1) {
				DAVsInTrigger1.add(trigger1.getDeviceAttrValue());
				triggers1TextList.add(trigger1.getTrigger());
			}
			for(Trigger trigger2 : triggers2) {
				DAVsInTrigger2.add(trigger2.getDeviceAttrValue());
				triggers2TextList.add(trigger2.getTrigger());
			}
			for(Condition con1 : cons1) {
				cons1TextList.add(con1.getCondition());
			}
			for(Condition con2 : cons2) {
				cons2TextList.add(con2.getCondition());
			}
			if(DAVsInTrigger1!=null && DAVsInTrigger1.size()>0 && DAVsInTrigger2!=null && DAVsInTrigger2.size()>0) {
				int size1 = triggers1.size();
				int size2 = triggers2.size();
				for(int i=0; i<size1; i++) {
					for(int j=0; j<size2;j++) {
						DeviceAttrValue DAV1 = DAVsInTrigger1.get(i);
						DeviceAttrValue DAV2 = DAVsInTrigger2.get(j);
						String device1 = DAV1.getDevice();
						String attr1 = DAV1.getAttribute();
						String trueOrFalse1 = DAV1.getTrueOrFalse();
						String value1 = DAV1.getValue();						
						String device2 = DAV2.getDevice();
						String attr2 = DAV2.getAttribute();
						String trueOrFalse2 = DAV2.getTrueOrFalse();
						String value2 = DAV2.getValue();							
						if((device1.equals(device2) && attr1.equals(attr2) && !trueOrFalse1.equals(trueOrFalse2) && value1.equals(value2))||(device1.equals(device2) && attr1.equals(attr2) && trueOrFalse1.equals("==") && trueOrFalse2.equals("==") && !value1.equals(value2))) {
							String s = triggers1.get(i).getTrigger() + " ### " + triggers2.get(j).getTrigger() + " ### " +  sameAction;
							if(!mutuallyExclusiveTriggerOfSameAction.contains(s))
								mutuallyExclusiveTriggerOfSameAction.add(s);
						}
					}
				}
			}
			String triggers1Text = StringUtils.join(triggers1TextList, ", ");
			String triggers2Text = StringUtils.join(triggers2TextList, ", ");
			String cons1Text = StringUtils.join(cons1TextList, ", ");
			String cons2Text = StringUtils.join(cons2TextList, ", ");			
			List<String> timingTriggers1 = addTriggerForTimingAction(tran1);
			List<String> timingTriggers2 = addTriggerForTimingAction(tran2);
			if(timingTriggers1!=null && timingTriggers1.size()>0) {
				for(String t1: timingTriggers1) {
					String ts[] = t1.split(":");
					String a = ts[1];
					String t = ts[0];
					boolean flag = true;
					if(triggers2TextList.size()>0) {
						for(String s: triggers2TextList) {
							if(!triggers1Text.contains(s) && !cons1Text.contains(s)) {
								flag = false;
							}
						}
					}
					if(cons2TextList.size()>0) {
						for(String s: cons2TextList) {
							if(!triggers1Text.contains(s) && !cons1Text.contains(s)) {
								flag = false;
							}
						}
					}
					if(sameAction.contains(a) && flag == false && !triggers2Text.equals("")) {
						String s = t + " ### " + triggers2Text + " ### " +  a;
						if(!mutuallyExclusiveTriggerOfSameAction.contains(s))
							mutuallyExclusiveTriggerOfSameAction.add(s);
					}
				}
			}
			if(timingTriggers2!=null && timingTriggers2.size()>0) {
				for(String t2: timingTriggers2) {
					String ts[] = t2.split(":");
					String a = ts[1];
					String t = ts[0];
					boolean flag = true;
					if(triggers1TextList.size()>0) {
						for(String s: triggers1TextList) {
							if(!triggers2Text.contains(s) && !cons2Text.contains(s)) {
								flag = false;
							}
						}
					}
					if(cons1TextList.size()>0) {
						for(String s: cons1TextList) {
							if(!triggers2Text.contains(s) && !cons2Text.contains(s)) {
								flag = false;
							}
						}
					}
					if(sameAction.contains(a) && flag == false) {
						String s = triggers1Text + " ### " + t + " ### " +  a;
						if(!mutuallyExclusiveTriggerOfSameAction.contains(s))
							mutuallyExclusiveTriggerOfSameAction.add(s);
					}
				}
			}
		}
		return mutuallyExclusiveTriggerOfSameAction;
	}
	private static List<String> tranHaveSameAction(Transition tran1, Transition tran2) {
		List<String> sameActions = new ArrayList<String>();
		List<Action> a1List = tran1.getActions();
		List<String> a1s = new ArrayList<String>();
		List<Action> a2List = tran2.getActions();
		List<String> a2s = new ArrayList<String>();
		if(a1List!=null && a1List.size()>0 && a2List!=null && a2List.size()>0) {
			for(Action a1:a1List) {
				String actionText = a1.getAction();
				if(actionText.contains("runIn")) {
					String s1[] = actionText.split(", ");
					actionText = s1[1];
					actionText = actionText.substring(0,actionText.length() - 1);
					a1s.add(actionText);

				}
				else {
					a1s.add(actionText);
				}
			}
			for(Action a2:a2List) {
				String actionText = a2.getAction();
				if(actionText.contains("runIn")) {
					String s1[] = actionText.split(", ");
					actionText = s1[1];
					actionText = actionText.substring(0,actionText.length() - 1);
					a2s.add(actionText);

				}
				else {
					a2s.add(actionText);
				}			}
		}
		if(a1s!=null && a1s.size()>0 && a2s!=null && a2s.size()>0) {
			for(String a1:a1s) {
				for(String a2:a2s) {
					if(a1.equals(a2)) {
						if(!sameActions.contains(a1))
							sameActions.add(a1);
					}
				}
			}			
		}
		return sameActions;
	}
	private static List<String> addTriggerForTimingAction(Transition tran) {
		List<String> timingTriggers = new ArrayList<String>();
		List<Action> actions = tran.getActions();
		if(actions!=null && actions.size()>0) {
			for(Action action: actions) {
				String aText = action.getAction();
				if(aText.contains("runIn")) {
					String a = "";
					String s1[] = aText.split(", ");
					a = s1[1];
					a = a.substring(0,a.length() - 1);
					String timingTrigger = aText + ":" + a;
					timingTriggers.add(timingTrigger);
				}
			}
		}
		return timingTriggers;
	}
}
