package threat;

import java.util.ArrayList;
import java.util.List;

import MDSSED.handlers.UML2NuSMV;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class GenThreat4 {
	//T4
	public static String main( BehaviourStateMachine umlModel, List<Device> deviceAttrValues, String behaviourName, List<String> properties) {

		   String threat = "";
		   List<Transition> trans = umlModel.getTrans();
		   threat = threat + genVars(trans,deviceAttrValues) + genTrans(trans);
		   if(!threat.equals(""))
			   threat = "MODULE threat4\r\n" + threat;			   
//		   System.out.println("-------threat4-------\r\n" + threat);
		   properties = genProperties(trans, behaviourName, properties);
//		   System.out.println("-------threat4-------\r\n" + properties);

		return threat;
	}
	public static List<String> genProperties(List<Transition> trans, String behaviourName, List<String> properties) {
		String property = "";
		List<DeviceAttrValue> vars = genThreat(trans);
	    for(DeviceAttrValue var:vars) {
		    String d = var.getDevice();
		    String a = var.getAttribute();
		    property = "CTLSPEC !EF("+ behaviourName +"."+ d + "_" + a +" != " + d + "." + a + ")--/*For threat 4*/\r\n";
		    if(!properties.contains(property))
		    	properties.add(property);

	    }
		return properties;    
	}
	public static String genVars(List<Transition> trans, List<Device> deviceAttrValues) {
		String varsText = "";
		List<DeviceAttrValue> vars = genThreat(trans);
	    for(DeviceAttrValue var:vars) {
		    String d = var.getDevice();
		    String a = var.getAttribute();
		    String varValue = "";
			List<String> otherValues = UML2NuSMV.getPossibleValues(deviceAttrValues, d, a);
			if(otherValues!=null && otherValues.size()>0) {
				for(String otherValue:otherValues) {
					varValue = varValue + otherValue + ", ";
				}
				varValue = varValue.substring(0,varValue.length() - 2);
				varValue = d + "_" + a + ":{" + varValue + "};\r\n";
				if(!varsText.contains(varValue))
					varsText = varsText + varValue;
			}
	    }
		varsText = "VAR\r\n" + varsText; 
		return varsText;
	}
	public static String genTrans(List<Transition> trans) {
		   String transText = "";
		   List<DeviceAttrValue> vars = genThreat(trans);
		   if(vars!=null && vars.size()>0) {
			   transText = "";
			   for(DeviceAttrValue var:vars) {
				   String d = var.getDevice();
				   String a = var.getAttribute();
				   String v = var.getValue();
				   String trueOrFalse = var.getTrueOrFalse();
				   if(trueOrFalse.equals("==")) {
					   String s = "TRANS\r\ncase\r\n" + 
						   		"\t("+ d +"_"+ a +" != "+ v +"): next("+ d +"_"+ a +") = " + v + ";\r\n" + 
						   		"\tTRUE : "+ d +"_"+ a +" = "+ v +";\r\n" + 
						   		"esac;\r\n";
					   if(!transText.contains(s))
						   transText = transText + s;
				   }
				   else {
					   String s = "case\r\n" + 
						   		"\t("+ d +"_"+ a +" = "+ v +"): next("+ d +"_"+ a +") != " + v + ";\r\n" + 
						   		"\tTRUE : "+ d +"_"+ a +" != "+ v +";\r\n" + 
						   		"esac;\r\n";
					   if(!transText.contains(s))
						   transText = transText + s;
				   }
			   }
		   }
		return transText;
	}

	public static List<DeviceAttrValue> genThreat(List<Transition> trans) {
		List<DeviceAttrValue> vars = new ArrayList<DeviceAttrValue>();
		if(trans!=null && trans.size()>0) {
			for(Transition tran:trans) {
				if(satThreatOccurCondition(tran)) {
					List<Trigger> triggers = tran.getTriggers();
					if(triggers!=null && triggers.size()>0) {
						for(Trigger trigger:triggers) {
							DeviceAttrValue DAV = trigger.getDeviceAttrValue();
							vars.add(DAV);
						}
					}					
				}
			}
		}
		return vars;
	}
	
	public static boolean satThreatOccurCondition(Transition tran) {
		//The conditions for T4 to occur are met - a property of some device is subscribed to, and this is used as the trigger event to execute the action.
		if(tran.getTriggers()!=null && tran.getActions()!=null)
			return true;
		return false;
	}
}
