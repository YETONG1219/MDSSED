package threat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class FindThreat8 {
	//Design error T8

	public static String main(BehaviourStateMachine umlModel) {
		String T8Result = "";
		List<String> threatList = findT8(umlModel);
		if(threatList!=null && threatList.size()>0) {
			for(String s:threatList) {
				String trigger = s.split(" ### ")[0];
				String actions = s.split(" ### ")[1];
				if(!T8Result.contains("Conflict actions \""+ actions + "\" are triggered by the event \"" + trigger)) {
				T8Result = T8Result + "\n\n---------------Design error: action-action conflict (T8)-----------------------\n";
				T8Result = T8Result + "Warning�� the model has action-action conflict threat (T8) where conflict actions triggered by the same event.\n";
					T8Result = T8Result + "Conflict actions \""+ actions + "\" are triggered by the event \"" + trigger +  "\".\n";	
				}
			}
		}
		else {
			T8Result = T8Result + "------There is no action-action conflict error (T8) in the model.------\n";

		}
		
		return T8Result;

	}
	public static List<String> findT8(BehaviourStateMachine umlModel){

		List<String> threats = new ArrayList<String>(); 
		List<String> TCAsInT8 = new ArrayList<String>();
		List<Transition> trans = umlModel.getTrans();
		if(trans!=null && trans.size()>0) {
			for(Transition tran : trans) {
				State target = tran.getTarget();
				List<DeviceAttrValue> DAVsInTarget = target.getDeviceAttrValues();
				List<Trigger> triggers = tran.getTriggers();
				List<Condition> cons = tran.getConditions();
				String Ts = "";
				String Cs = "";
				if(triggers!=null && triggers.size()>0) {
					for(Trigger trigger : triggers) {
						Ts = Ts + trigger.getTrigger() + ",";
					}
					Ts = Ts.toString().substring(0,Ts.toString().length()-1);
				}
				if(cons!=null && cons.size()>0) {
					for(Condition con : cons) {
						Cs = Cs + con.getCondition() + ",";
					}
					Cs = Cs.toString().substring(0,Cs.toString().length()-1);
				}
				List<Action> actions = tran.getActions();
				List<String> actionList = new ArrayList<String>();
				if(actions!=null && actions.size()>0) {
					for(Action action : actions){
						if(!action.getCommandDevice().equals("phone")) {
							String actionText = action.getAction();
							if(actionText.contains("runIn")) {
								String s1[] = actionText.split(", ");
								actionText = s1[1];
								actionText = actionText.substring(0,actionText.length() - 1);
								if(!Ts.equals("") && Cs.equals("")) {
									TCAsInT8.add(actionText + " ### " + Ts);							
									if(!Cs.equals("")) {
										TCAsInT8.add(actionText + " ### " + Ts + " ### " + Cs);																	
									}
								}
							}
							else {
								if(!Ts.equals("") && Cs.equals(""))	{
									TCAsInT8.add(actionText + " ### " + Ts);							
									if(!Cs.equals("")) {
										TCAsInT8.add(actionText + " ### " + Ts + " ### " + Cs);																	
									}
								}
							}
						}
					}
				}
			}
		}
		//Determine if Design error T8 exists.
		if(TCAsInT8!=null && TCAsInT8.size()>0) {
			int size = TCAsInT8.size();
			for(int i=0;i<size;i++) {
				for(int j=i+1;j<size;j++) {
					String TCA1 = TCAsInT8.get(i);
					String TCA2 = TCAsInT8.get(j); 
					System.out.println("TCA1:"+ TCA1);
					System.out.println("TCA2:"+ TCA2);

					String action1 = TCA1.split(" ### ")[0];
					String action2 = TCA2.split(" ### ")[0];
					String T1 = TCA1.split(" ### ")[1];
					String T2 = TCA2.split(" ### ")[1];
					String C1 = "";
					String C2 = "";
					if(TCA1.split(" ### ").length > 2) {
						C1 = TCA1.split(" ### ")[2];
					}
					if(TCA2.split(" ### ").length > 2) {
						C2 = TCA2.split(" ### ")[2];
					}
					String C1s[] = null;
					String C2s[] = null;
					List<String> C1List = null;
					List<String> C2List =null;
					System.out.println("C1:"+C1);
					System.out.println("C2:"+C2);
					
					if(!C1.equals("")) {
						C1s = C1.split(",");
						C1List = Arrays.asList(C1s);
					}
					if(!C2.equals("")) {
						C2s = C2.split(",");
						C2List = Arrays.asList(C2s);
					}

					String T1s[] = T1.split(",");
					String T2s[] = T2.split(",");
					List<String> T1List = Arrays.asList(T1s);
					List<String> T2List = Arrays.asList(T2s);
					
					boolean same = true;
					for(String s1:T1List) {
						if(!T2List.contains(s1))
							same = false;
					}
					for(String s2:T2List) {
						if(!T1List.contains(s2)) {
							same = false;
						}
					}
					if(C1List != null && C2List == null)
						same = false;
					if(C2List != null && C1List == null)
						same = false;
					if(C1List != null && C1List.size()>0 && C2List != null && C2List.size()>0) {
						for(String s1:C1List) {
							System.out.println("s1:"+s1);
							if(!C2List.contains(s1)) {
								same = false;
							}
						}
						for(String s2:C2List) {
							System.out.println("s2:"+s2);
							if(!C1List.contains(s2)) {
								same = false;

							}
						}						
					}


					if(same == true && action1.split("\\.")[0].equals(action2.split("\\.")[0]) && !action1.split("\\.")[1].equals(action2.split("\\.")[1])) {
						threats.add(T1 + " ### " + action1 + ", " + action2);

					}
				}
			}
		}
		return threats;
	}
}
