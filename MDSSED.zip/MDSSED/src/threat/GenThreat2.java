package threat;


import java.util.ArrayList;
import java.util.List;

import MDSSED.handlers.UML2NuSMV;
import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class GenThreat2 {
	//T2
	public static List<String> main( BehaviourStateMachine umlModel, String inList, List<String> nextList, List<Device> deviceAttrValues){

		   List<Transition> trans = umlModel.getTrans();
		   if(trans!=null && trans.size()>0) {
			   for(Transition tran : trans) {
				   List<DeviceAttrValue> DAVchange = satThreatOccurCondition(tran);
				   if(DAVchange!=null && DAVchange.size()>0) {
					   nextList = genThreat(tran, DAVchange, nextList, deviceAttrValues);
				   }
			   }
		   }
//			System.out.println("-------threat2-------\r\n" + threat);
		return nextList;
	}
	public static List<String> genThreat(Transition tran, List<DeviceAttrValue> DAVchange,  List<String> nextList, List<Device> deviceAttrValues ) {
		//Generate the threat model.
		List<Trigger> triggers = tran.getTriggers();
		List<DeviceAttrValue> DAVsInTrigger = null;
		if(triggers!=null && triggers.size()>0) {
			DAVsInTrigger = new ArrayList<DeviceAttrValue>();
			for(Trigger trigger: triggers) {
				DeviceAttrValue DAVInTrigger = trigger.getDeviceAttrValue();
				DAVsInTrigger.add(DAVInTrigger);
			}
		}
		String caseText = "";
		String caseTexts = "";
		if(DAVchange!=null && DAVchange.size()>0) {
			if(DAVsInTrigger!=null && DAVsInTrigger.size()>0) {
				for(DeviceAttrValue DAVch:DAVchange) {
					if(DAVch.getTrueOrFalse().equals("==")) {
						caseText = DAVch.getDevice() + "_" + DAVch.getAttribute() + " = " + DAVch.getValue() + " & ";						
					}
					else {
						caseText = DAVch.getDevice() + "_" + DAVch.getAttribute() + " != " + DAVch.getValue() + " & ";						
					}							
					caseTexts = caseTexts + caseText;
				}
				caseTexts = caseTexts.substring(0,caseTexts.length() - 3);
				for(DeviceAttrValue DAVInTrigger:DAVsInTrigger) {
					   String device = DAVInTrigger.getDevice();
					   boolean isSensor = false;
					   if(device.contains("Sensor")||device.contains("Detector"))
						   isSensor = true;
					   if(!isSensor) {
						   String attr = DAVInTrigger.getAttribute();
						   String value = DAVInTrigger.getValue();
						   String next1 = "(" + caseTexts + " & "+ device + "_" + attr + " != " + value +"):" +value;
						   String next2 = "";
						   List<String> otherValues = UML2NuSMV.getPossibleValues(deviceAttrValues,device, attr);
							if(otherValues!=null && otherValues.size()>0) {
								for(String otherValue:otherValues) {
									if(!otherValue.equals(value))
										next2 = next2 + otherValue + ", "; 
								}
								next2 = next2.substring(0,next2.length() - 2);
							}
						   if(!next2.contains(","))
							   next2 = "(" + caseTexts + " & "+ device + "_" + attr + " = " + value +"):" + next2 ;
						   else						   
							   next2 = "(" + caseTexts + " & "+ device + "_" + attr + " = " + value +"):" + "{" + next2 + "}";
						   boolean alreadyIn = false;

						   if(nextList!=null && nextList.size()>0) {
							   int size = nextList.size();
							   for(int i=0;i<size;i++) {
								   if(nextList.get(i).equals("next("+ device + "_" + attr +"):=case")) {
									   nextList.add(i+1,"\t" + next1 +";--/*Threat 2*/");
									   nextList.add(i+2,"\t" + next2 +";--/*Threat 2*/");
									   size++;
									   size++;
									   alreadyIn = true;
								   } 
							   }
						   }
						   if(alreadyIn == false) {
							   nextList.add("next("+ device + "_" + attr +"):=case");
							   nextList.add("\t" + next1 +";--/*Threat 2*/");
							   nextList.add("\t" + next2 +";--/*Threat 2*/");
							   nextList.add("\tTRUE:"+ device + "_" + attr +";\r\nesac;");
							   
						   }
											   
					   }
				}

			}
		}
		return nextList;
	}
	
	public static List<DeviceAttrValue> satThreatOccurCondition(Transition tran) {
		//The conditions of T2 are met - there is an operation to change an attribute, and the trigger contains a device attribute subscription
		List<DeviceAttrValue> DAVchange = null;
		State source = tran.getSource();
		State target = tran.getTarget();
		List<Trigger> triggers = tran.getTriggers();
		List<String> attrsInTriggers = null; 
		if(triggers!=null && triggers.size()>0) {
			attrsInTriggers = new ArrayList<String>();
			for(Trigger tirgger:triggers) {
				String attr = tirgger.getDeviceAttrValue().getAttribute();
				if(!attrsInTriggers.contains(attr))
					attrsInTriggers.add(attr);
			}
		}
		List<Action> actions = tran.getActions();
		List<String> actionDeviceList = new ArrayList<String>();
		if(actions!=null && actions.size()>0) {
			for(Action action:actions) {
				if(!action.getCommandDevice().equals("phone")) 
					actionDeviceList.add(action.getCommandDevice());
			}
		}
		List<DeviceAttrValue> DAVsInSource = source.getDeviceAttrValues();
		List<DeviceAttrValue> DAVsInTarget = target.getDeviceAttrValues();
		if(DAVsInSource!=null && DAVsInSource.size()>0 && DAVsInTarget!=null && DAVsInTarget.size()>0) {
			for(DeviceAttrValue tDAV :DAVsInTarget) {
				for(DeviceAttrValue sDAV :DAVsInSource) {
					if(tDAV.getDevice().equals(sDAV.getDevice())) {
						if(tDAV.getAttribute().equals(sDAV.getAttribute())) {
							if((tDAV.getValue().equals(sDAV.getValue()) && (tDAV.getTrueOrFalse().equals(sDAV.getTrueOrFalse())==false)) || (tDAV.getValue().equals(sDAV.getValue()) ==false)) {
								if(actionDeviceList.contains(tDAV.getDevice()) ) {
									if(attrsInTriggers != null) {
										DAVchange = new ArrayList<DeviceAttrValue>();
										DAVchange.add(tDAV);
									}
						
								}
							}
						}
					}
				}
			}
		}
		return DAVchange;
	}
}
