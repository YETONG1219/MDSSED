package threat;


import java.util.ArrayList;
import java.util.List;

import MDSSED.handlers.UML2NuSMV;
import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class GenThreat2 {
	//T2:��Ϊ����ѭ������: 
	public static List<String> main( BehaviourStateMachine umlModel, String inList, List<String> nextList, List<Device> deviceAttrValues){
		   //��ȡUMLģ��
		   //����transΪ����������trans������вģ��
//		   String threat = "";
		   List<Transition> trans = umlModel.getTrans();
//		   List<String> tranTrue = new ArrayList<String>();//Ǩ����δ����caseʱĬ�ϲ������
		   if(trans!=null && trans.size()>0) {
//			   String threatForChange = "";
			   for(Transition tran : trans) {
				   List<DeviceAttrValue> DAVchange = satThreatOccurCondition(tran);
				   if(DAVchange!=null && DAVchange.size()>0) {
//					   threatForChange = threatForChange + genThreat(tran,DAVchange);
					   nextList = genThreat(tran, DAVchange, nextList, deviceAttrValues);
				   }
			   }
//				System.out.println("-------threat2ForChange------\r\n" + threatForChange);
//			  if(!threatForChange.equals("")) {
//				  threat = "MODULE threat2(" + inList + ")\r\nTRANS\r\ncase\r\n";
//				  threat = threat + threatForChange;
//				  threat = threat + "\tTRUE : TRUE;\r\nesac;\r\n";
//			  }
		   }
//			System.out.println("-------threat2-------\r\n" + threat);
		return nextList;
	}
	public static List<String> genThreat(Transition tran, List<DeviceAttrValue> DAVchange,  List<String> nextList, List<Device> deviceAttrValues ) {
		//������в��ģ�ͣ����豸����ֵ��DAVchange�ĸı����Ϊ��в��Ϊ��case��nextΪ�豸���Ե�trigger
		List<Trigger> triggers = tran.getTriggers();
		List<DeviceAttrValue> DAVsInTrigger = null;
		if(triggers!=null && triggers.size()>0) {
			DAVsInTrigger = new ArrayList<DeviceAttrValue>();
			for(Trigger trigger: triggers) {
				DeviceAttrValue DAVInTrigger = trigger.getDeviceAttrValue();
				DAVsInTrigger.add(DAVInTrigger);
			}
		}
		String caseText = "";
		String caseTexts = "";
//		String nextText = "";
		if(DAVchange!=null && DAVchange.size()>0) {
			if(DAVsInTrigger!=null && DAVsInTrigger.size()>0) {
				for(DeviceAttrValue DAVch:DAVchange) {
					if(DAVch.getTrueOrFalse().equals("==")) {
						caseText = DAVch.getDevice() + "_" + DAVch.getAttribute() + " = " + DAVch.getValue() + " & ";						
					}
					else {
						caseText = DAVch.getDevice() + "_" + DAVch.getAttribute() + " != " + DAVch.getValue() + " & ";						
					}							
					caseTexts = caseTexts + caseText;
				}
				caseTexts = caseTexts.substring(0,caseTexts.length() - 3);//ɾ������ġ� & ��
				for(DeviceAttrValue DAVInTrigger:DAVsInTrigger) {
					   String device = DAVInTrigger.getDevice();
					   boolean isSensor = false;
					   if(device.contains("Sensor")||device.contains("Detector"))
						   isSensor = true;
					   if(!isSensor) {
						   String attr = DAVInTrigger.getAttribute();
						   String value = DAVInTrigger.getValue();
						   String next1 = "(" + caseTexts + " & "+ device + "_" + attr + " != " + value +"):" +value;
						   String next2 = "";
						   List<String> otherValues = UML2NuSMV.getPossibleValues(deviceAttrValues,device, attr);
							if(otherValues!=null && otherValues.size()>0) {
								for(String otherValue:otherValues) {
									if(!otherValue.equals(value))
										next2 = next2 + otherValue + ", "; 
								}
								next2 = next2.substring(0,next2.length() - 2);//ɾ������ġ��� ��
							}
						   if(!next2.contains(","))
							   next2 = "(" + caseTexts + " & "+ device + "_" + attr + " = " + value +"):" + next2 ;
						   else						   
							   next2 = "(" + caseTexts + " & "+ device + "_" + attr + " = " + value +"):" + "{" + next2 + "}";
						   boolean alreadyIn = false;
//						   if(DAV.getTrueOrFalse().equals("==")) {
//							   next = "\t\t\t\tnext(" + DAV.getDevice() + "_" + DAV.getAttribute()+") = " + DAV.getValue() + " & \r\n";						   
//						   }
//						   if(DAV.getTrueOrFalse().equals("!=")) {
//							   next = "\t\t\t\tnext(" + DAV.getDevice() + "_" + DAV.getAttribute()+") != " + DAV.getValue() + " & \r\n";						   
//						   }	
						   if(nextList!=null && nextList.size()>0) {
							   int size = nextList.size();
							   for(int i=0;i<size;i++) {
								   if(nextList.get(i).equals("next("+ device + "_" + attr +"):=case")) {
									   nextList.add(i+1,"\t" + next1 +";--/*Threat 2*/");
									   nextList.add(i+2,"\t" + next2 +";--/*Threat 2*/");
									   size++;
									   size++;
									   alreadyIn = true;
								   } 
							   }
						   }
						   if(alreadyIn == false) {
							   nextList.add("next("+ device + "_" + attr +"):=case");
							   nextList.add("\t" + next1 +";--/*Threat 2*/");
							   nextList.add("\t" + next2 +";--/*Threat 2*/");
							   nextList.add("\tTRUE:"+ device + "_" + attr +";\r\nesac;");
							   
						   }
//						if(DAVInTrgger.getTrueOrFalse().equals("==")) {
//							 nextText = nextText + "next(" + DAVInTrgger.getDevice() + "_" + DAVInTrgger.getAttribute() + ") = " + DAVInTrgger.getValue() + " & ";						
//						}
//						else {
//							 nextText = nextText + "next(" + DAVInTrgger.getDevice() + "_" + DAVInTrgger.getAttribute() + ") != " + DAVInTrgger.getValue() + " & ";						
//						}													   
					   }
}
//				nextText = nextText.substring(0,nextText.length() - 3);//ɾ������ġ� & ��
//				nextText = nextText + ";\r\n";

			}
		}
		return nextList;
	}
	
	public static List<DeviceAttrValue> satThreatOccurCondition(Transition tran) {
		//����T2�ķ������������иı����ԵĲ���,trigger�а����豸���Զ���
		//�Ƚ�transition��source��target��״̬�仯
		List<DeviceAttrValue> DAVchange = null;
		State source = tran.getSource();
		State target = tran.getTarget();
		List<Trigger> triggers = tran.getTriggers();
		List<String> attrsInTriggers = null; //������trigger�е�����
		if(triggers!=null && triggers.size()>0) {
			attrsInTriggers = new ArrayList<String>();
			for(Trigger tirgger:triggers) {
				String attr = tirgger.getDeviceAttrValue().getAttribute();
				if(!attrsInTriggers.contains(attr))
					attrsInTriggers.add(attr);
			}
		}
		List<Action> actions = tran.getActions();
		List<String> actionDeviceList = new ArrayList<String>();
		if(actions!=null && actions.size()>0) {
			for(Action action:actions) {
				if(!action.getCommandDevice().equals("phone")) 
					actionDeviceList.add(action.getCommandDevice());
			}
		}
		List<DeviceAttrValue> DAVsInSource = source.getDeviceAttrValues();
		List<DeviceAttrValue> DAVsInTarget = target.getDeviceAttrValues();
		if(DAVsInSource!=null && DAVsInSource.size()>0 && DAVsInTarget!=null && DAVsInTarget.size()>0) {
			//����ÿһ��Ǩ�ƣ��ж�ǰ���Ƿ����豸��״̬�����仯
			for(DeviceAttrValue tDAV :DAVsInTarget) {
				for(DeviceAttrValue sDAV :DAVsInSource) {
					if(tDAV.getDevice().equals(sDAV.getDevice())) {
						if(tDAV.getAttribute().equals(sDAV.getAttribute())) {
							if((tDAV.getValue().equals(sDAV.getValue()) && (tDAV.getTrueOrFalse().equals(sDAV.getTrueOrFalse())==false)) || (tDAV.getValue().equals(sDAV.getValue()) ==false)) {
								//ǰ����ͬ���豸���Ե�ֵ�����仯
								if(actionDeviceList.contains(tDAV.getDevice()) ) {
									//��ֵ�ı仯����action�����
									if(attrsInTriggers != null) {
										//���trigger���漰���豸�����ԵĶ���
										DAVchange = new ArrayList<DeviceAttrValue>();
										DAVchange.add(tDAV);//���ı���״̬��Ϊ�б���������Ԫ�أ��ı�ǰ��״̬��Ϊ�б���ż����Ԫ��
//										DAVchange.add(sDAV);						
									}
						
								}
							}
						}
					}
				}
			}
		}
		return DAVchange;
	}
}
