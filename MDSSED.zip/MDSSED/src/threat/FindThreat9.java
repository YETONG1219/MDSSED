package threat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;
import MDSSED.utils.Condition;
import MDSSED.utils.Device;
import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class FindThreat9 {
	////T9:ͬһ�����¼�����ĳ�ͻ����
	//���ش����¼��ͳ�ͻ�Ĳ���
	public static String main(BehaviourStateMachine umlModel) {
		String T9Result = "";
		List<String> threatList = findT9(umlModel);
		if(threatList!=null && threatList.size()>0) {
			for(String s:threatList) {
				String trigger = s.split(" ### ")[0];
				String actions = s.split(" ### ")[1];
				T9Result = T9Result + "\n\n---------------Design error: action-action repeat (T9)-----------------------\n";
				T9Result = T9Result + "Warning�� the model is under action-action repeat threat (T9) where conflict actions triggered by the same event.\n";
					T9Result = T9Result + "Repeated actions \""+ actions + "\" are triggered by the event \"" + trigger +  "\".\n";					
			}
		}
		else {
			T9Result = T9Result + "------There is no action-action repeat error (T9) in the model.------\n";

		}
		
		return T9Result;

	}
	public static List<String> findT9(BehaviourStateMachine umlModel){
//		���trigger��DAV = �仯��״̬��DAV && D��action��D��ͬ
		List<String> threats = new ArrayList<String>(); 
		List<String> TCAsInT9 = new ArrayList<String>();
		List<Transition> trans = umlModel.getTrans();
		if(trans!=null && trans.size()>0) {
			for(Transition tran : trans) {
				State target = tran.getTarget();
				List<DeviceAttrValue> DAVsInTarget = target.getDeviceAttrValues();
				List<Trigger> triggers = tran.getTriggers();
//				List<Condition> cons = tran.getConditions();
				String TCs = "";
				if(triggers!=null && triggers.size()>0) {
					for(Trigger trigger : triggers) {
						TCs = TCs + trigger.getTrigger() + ",";
					}
					TCs = TCs.toString().substring(0,TCs.toString().length()-1);
				}
//				if(cons!=null && cons.size()>0) {
//					for(Condition con : cons) {
//						TCs = TCs + con.getCondition() + ",";
//					}
//					TCs = TCs.toString().substring(0,TCs.toString().length()-1);
////					System.out.println("TCs:" +TCs);
//				}
				List<Action> actions = tran.getActions();
				List<String> actionList = new ArrayList<String>();
				if(actions!=null && actions.size()>0) {
					for(Action action : actions){
						if(!action.getCommandDevice().equals("phone")) {
							String actionText = action.getAction();
							if(actionText.contains("runIn")) {
								String s1[] = actionText.split(", ");
								actionText = s1[1];
								actionText = actionText.substring(0,actionText.length() - 1);//ɾ������ġ�)��
								if(!TCs.equals(""))
									TCAsInT9.add(actionText + " ### " + TCs);							
								
							}
							else {
								if(!TCs.equals(""))
									TCAsInT9.add(actionText + " ### " + TCs);							
							}
						}
					}
				}
			}
		}
		//�ж�T9�Ƿ����
		if(TCAsInT9!=null && TCAsInT9.size()>0) {
			int size = TCAsInT9.size();
			for(int i=0;i<size;i++) {
				for(int j=i+1;j<size;j++) {
					String TCA1 = TCAsInT9.get(i);
					String TCA2 = TCAsInT9.get(j);
					String action1 = TCA1.split(" ### ")[0];
					String action2 = TCA2.split(" ### ")[0];
					String TC1 = TCA1.split(" ### ")[1];
					String TC2 = TCA2.split(" ### ")[1];
					String TC1s[] = TC1.split(",");
					String TC2s[] = TC2.split(",");
					List<String> TC1List = Arrays.asList(TC1s);
					List<String> TC2List = Arrays.asList(TC2s);

					boolean same = true;
					for(String s1:TC1List) {
						if(!TC2List.contains(s1))
							same = false;
					}
					for(String s2:TC2List) {
						if(!TC1List.contains(s2)) {
							same = false;
						}
					}

					if(same == true && action1.equals(action2)) {
						threats.add(TC1 + " ### " + action1 + ", " + action2);
					}
				}
			}
		}
		return threats;
	}
}
