package threat;

import java.util.ArrayList;
import java.util.List;

import MDSSED.utils.Action;
import MDSSED.utils.BehaviourStateMachine;

import MDSSED.utils.DeviceAttrValue;
import MDSSED.utils.State;
import MDSSED.utils.Transition;
import MDSSED.utils.Trigger;

public class FindThreat10 {
//Design error T10.

	public static String main(BehaviourStateMachine umlModel) {
		String T10Result = "";
		List<DeviceAttrValue> threatList = findT10(umlModel);
		if(threatList!=null && threatList.size()>0) {
			for(DeviceAttrValue DAV:threatList) {
				String device = DAV.getDevice();
				String attr = DAV.getAttribute();
				String trueOrFalse = DAV.getTrueOrFalse();
				String value = DAV.getValue();
				T10Result = T10Result + "\n\n---------------Design error: self coordination (T10)-----------------------\n";
				T10Result = T10Result + "Warning�� the model is under self coordination threat (T10) where the action triggers itself.\n";
				if(trueOrFalse.equals("==")) {
					T10Result = T10Result + "An action sets the value of the attribute \""+ attr + "\" of the device \"" + device + "\" to \"" + value + "\" which is the trigger of this action.\n";					
				}
				else {
					T10Result = T10Result + "An action sets the value of the attribute \""+ attr + "\" of the device \"" + device + "\" to not be \"" + value + "\" which is the trigger of this action.\n";					
				}
			}
		}
		else {
			T10Result = T10Result + "------There is no self coordination error (T10) in the model.------\n";

		}
		
		return T10Result;

	}
	public static List<DeviceAttrValue> findT10(BehaviourStateMachine umlModel){
		List<DeviceAttrValue> DAVsInT10 = new ArrayList<DeviceAttrValue>();
		List<Transition> trans = umlModel.getTrans();
		if(trans!=null && trans.size()>0) {
			for(Transition tran : trans) {
				State target = tran.getTarget();
				List<DeviceAttrValue> DAVsInTarget = target.getDeviceAttrValues();
				List<Trigger> triggers = tran.getTriggers();
				List<DeviceAttrValue> DAVsInTrigger = new ArrayList<DeviceAttrValue>();
				if(triggers!=null && triggers.size()>0) {
					for(Trigger trigger : triggers) {
						DAVsInTrigger.add(trigger.getDeviceAttrValue());
					}
				}
				List<Action> actions = tran.getActions();
				List<String> devicesInActions = new ArrayList<String>();
				if(actions!=null && actions.size()>0) {
					for(Action action : actions){
						if(!action.getCommandDevice().equals("phone")) 
							devicesInActions.add(action.getCommandDevice());
					}
				}
				if(DAVsInTrigger != null && DAVsInTrigger.size()>0) {
					for(DeviceAttrValue DAVInTrigger:DAVsInTrigger) {
						String deviceTrigger = DAVInTrigger.getDevice();
						String attrTrigger = DAVInTrigger.getAttribute();
						String trueOrFalseTrigger = DAVInTrigger.getTrueOrFalse();
						String valueTrigger = DAVInTrigger.getValue();
						if(DAVsInTarget !=null && DAVsInTarget.size()>0) {
							for(DeviceAttrValue DAVInTarget:DAVsInTarget) {
								String deviceTarget = DAVInTarget.getDevice();
								String attrTarget = DAVInTarget.getAttribute();
								String trueOrFalseTarget = DAVInTarget.getTrueOrFalse();
								String valueTarget = DAVInTarget.getValue();
								if(deviceTrigger.equals(deviceTarget) && attrTrigger.equals(attrTarget) && trueOrFalseTrigger.equals(trueOrFalseTarget) && valueTrigger.equals(valueTarget)) {
									if(devicesInActions != null && devicesInActions.size()>0) {
										if(devicesInActions.contains(deviceTrigger)) {
											DAVsInT10.add(DAVInTrigger);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return DAVsInT10;
	}
}
