/* Automatically generated from UML model.*/
definition(
	name: "LocationSubscribeFailure",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
	section("Home mode..") {
		input "Location", "mode", title: "Mode?"
	}
    section("Controlling the lock..") {
		input "Lock", "capability.lock", title: "Which lock?"
	}
}
def initialize() {
	subscribe(PresenceSensor, "presence", p0)
	subscribe(PresenceSensor, "presence", p1)
	subscribe(Location, "mode", p2)
	subscribe(Location, "mode", p3)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(PresenceSensor.presence == "not present"){
		Location.setLocationMode("Away")
	}
}
def p1(evt){
	if(PresenceSensor.presence == "present"){
		Location.setLocationMode("Home")
	}
}
def p2(evt){
	if(Location.mode == "Home"){
		Lock.unlock()
	}
}
def p3(evt){
	if(Location.mode == "Away"){
		Lock.lock()
	}
}