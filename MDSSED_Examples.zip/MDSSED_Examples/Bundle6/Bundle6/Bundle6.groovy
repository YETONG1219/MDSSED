/* Automatically generated from UML model.*/
definition(
	name: "Bundle6",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
    section("Controlling the illuminanceMeasurement..") {
		input "IlluminanceMeasurement", "capability.illuminanceMeasurement", title: "Which illuminanceMeasurement?"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
}
def initialize() {
	subscribe(IlluminanceMeasurement, "illuminance", p0)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(IlluminanceMeasurement.illuminance == "1000" ){
		Switch.off()
	}
}