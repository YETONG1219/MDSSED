/* Automatically generated from UML model.*/
definition(
	name: "Bundle6Error",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
    section("Controlling the illuminanceMeasurement..") {
		input "IlluminanceMeasurement", "capability.illuminanceMeasurement", title: "Which illuminanceMeasurement?"
	}
}
def initialize() {
	subscribe(Switch, "switch", p0)
	subscribe(IlluminanceMeasurement, "illuminance", p1)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(Switch.switch == "off"){
		Switch.on()
		runIn(60, switchoffAfter60)
	}
}
def switchoffAfter60(){
		Switch.off()
}
def p1(evt){
	if(IlluminanceMeasurement.illuminance == "1000" ){
		Switch.off()
	}
}