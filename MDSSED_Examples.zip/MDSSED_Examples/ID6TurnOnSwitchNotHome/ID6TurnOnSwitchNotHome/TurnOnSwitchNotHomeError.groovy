/* Automatically generated from UML model.*/
definition(
	name: "TurnOnSwitchNotHomeError",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
    section("Controlling the switchLevel..") {
		input "SwitchLevel", "capability.switchLevel", title: "Which switchLevel?"
	}
    section("Controlling the lock..") {
		input "Lock", "capability.lock", title: "Which lock?"
	}
}
def initialize() {
	subscribe(PresenceSensor, "presence", p0)
	subscribe(PresenceSensor, "presence", p1)
	subscribe(PresenceSensor, "presence", p2)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(PresenceSensor.presence == "not present"){
		SwitchLevel.setLevel(0)
		runIn(6, switchLevelsetLevel20After6)
	}
}
def switchLevelsetLevel20After6(){
		SwitchLevel.setLevel(20)
}
def p1(evt){
	if(PresenceSensor.presence == "not present"){
		Lock.lock()
		runIn(6, lockunlockAfter6)
	}
}
def lockunlockAfter6(){
		Lock.unlock()
}
def p2(evt){
	if(PresenceSensor.presence == "present"){
		SwitchLevel.setLevel(80)
	}
}