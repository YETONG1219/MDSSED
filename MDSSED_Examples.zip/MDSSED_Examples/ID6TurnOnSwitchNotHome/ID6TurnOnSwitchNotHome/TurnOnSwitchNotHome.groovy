/* Automatically generated from UML model.*/
definition(
	name: "TurnOnSwitchNotHome",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
    section("Controlling the switchLevel..") {
		input "SwitchLevel", "capability.switchLevel", title: "Which switchLevel?"
	}
    section("Controlling the lock..") {
		input "Lock", "capability.lock", title: "Which lock?"
	}
}
def initialize() {
	subscribe(PresenceSensor, "presence", p0)
	subscribe(PresenceSensor, "presence", p1)
	subscribe(PresenceSensor, "presence", p2)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(PresenceSensor.presence == "not present"){
		SwitchLevel.setLevel(0)
	}
}
def p1(evt){
	if(PresenceSensor.presence == "not present"){
		Lock.lock()
	}
}
def p2(evt){
	if(PresenceSensor.presence == "present"){
		SwitchLevel.setLevel(80)
	}
}