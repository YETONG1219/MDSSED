/* Automatically generated from UML model.*/
definition(
	name: "Bundle2Enhanced",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
	section("Home mode..") {
		input "Location", "mode", title: "Mode?"
	}
}
def initialize() {
	subscribe(Switch, "switch", p0)
	subscribe(Switch, "switch", p1)
	subscribe(Switch, "switch", p2)
	subscribe(Switch, "switch", p3)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(Switch.switch == "off" && now() > getSunriseAndSunset().sunrise.time && now() < getSunriseAndSunset().sunset.time && Location.mode != "AwayDay"){
		Location.setLocationMode("AwayDay")
	}
}
def p1(evt){
	if(Switch.switch == "on" && now() > getSunriseAndSunset().sunrise.time && now() < getSunriseAndSunset().sunset.time && Location.mode != "HomeDay"){
		Location.setLocationMode("HomeDay")
	}
}
def p2(evt){
	if(Switch.switch == "off" && now() > getSunriseAndSunset().sunset.time && Location.mode != "AwayNight"){
		Location.setLocationMode("AwayNight")
	}
}
def p3(evt){
	if(Switch.switch == "on" && now() > getSunriseAndSunset().sunset.time && Location.mode != "HomeNight"){
		Location.setLocationMode("HomeNight")
		sendSms(Phone, "The location mode is set to 'HomeNight' as the switch is on and the current time is after sunset.")
	}
}