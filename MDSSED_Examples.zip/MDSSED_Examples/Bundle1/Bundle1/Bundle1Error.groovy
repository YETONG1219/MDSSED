/* Automatically generated from UML model.*/
definition(
	name: "Bundle1Error",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
    section("Controlling the motionSensor..") {
		input "MotionSensor", "capability.motionSensor", title: "Which motionSensor?"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
}
def initialize() {
	subscribe(PresenceSensor, "presence", p0)
	subscribe(PresenceSensor, "presence", p1)
	subscribe(MotionSensor, "motion", p2)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(PresenceSensor.presence == "not present"){
		Switch.off()
	}
}
def p1(evt){
	if(PresenceSensor.presence == "present"){
		Switch.on()
	}
}
def p2(evt){
	if(MotionSensor.motion == "active"){
		Switch.on()
		Switch.off()
	}
}