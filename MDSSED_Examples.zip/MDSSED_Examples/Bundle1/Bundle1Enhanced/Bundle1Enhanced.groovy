/* Automatically generated from UML model.*/
definition(
	name: "Bundle1Enhanced",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
    section("Controlling the motionSensor..") {
		input "MotionSensor", "capability.motionSensor", title: "Which motionSensor?"
	}
}
def initialize() {
	subscribe(PresenceSensor, "presence", p0)
	subscribe(PresenceSensor, "presence", p1)
	subscribe(MotionSensor, "motion", p2)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(PresenceSensor.presence == "not present" && Switch.switch != "off"){
		Switch.off()
	}
}
def p1(evt){
	if(PresenceSensor.presence == "present" && Switch.switch != "on"){
		Switch.on()
		sendSms(Phone, "An attacker can infer whether you are present according to the switch status. Please grant permissions carefully!")
	}
}
def p2(evt){
	if(MotionSensor.motion == "active" && Switch.switch != "on"){
		Switch.on()
		sendSms(Phone, "The switch is on triggered by motion.")
	}
}