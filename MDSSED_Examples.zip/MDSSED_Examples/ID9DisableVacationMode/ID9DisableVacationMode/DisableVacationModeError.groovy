/* Automatically generated from UML model.*/
definition(
	name: "DisableVacationModeError",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
	section("Home mode..") {
		input "Location", "mode", title: "Mode?"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
}
def initialize() {
	subscribe(PresenceSensor, "presence", p0)
	subscribe(PresenceSensor, "presence", p1)
	subscribe(Location, "sunset", p2)
	subscribe(Location, "sunrise", p3)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(PresenceSensor.presence == "not present" && Location.mode != "Vacation"){
		Location.setLocationMode("Vacation")
		sendSms(Phone, "Your mode is changed to vacation because everyone left home.")
		runIn(60, locationsetLocationModeHomeAfter60)
	}
}
def locationsetLocationModeHomeAfter60(){
	if(Location.mode != "Vacation"){
		Location.setLocationMode("Home")
	}
}
def p1(evt){
	if(PresenceSensor.presence == "present"){
		Location.setLocationMode("Home")
	}
}
def p2(evt){
	if(Location.sunset == "true" && Location.mode == "Vacation"){
		Switch.on()
	}
}
def p3(evt){
	if(Location.sunrise == "true" && Location.mode == "Vacation"){
		Switch.off()
	}
}