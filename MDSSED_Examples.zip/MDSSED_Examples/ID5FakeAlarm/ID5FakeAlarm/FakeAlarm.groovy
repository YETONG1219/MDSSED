/* Automatically generated from UML model.*/
definition(
	name: "FakeAlarm",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
    section("Controlling the smokeDetector..") {
		input "SmokeDetector", "capability.smokeDetector", title: "Which smokeDetector?"
	}
    section("Controlling the alarm..") {
		input "Alarm", "capability.alarm", title: "Which alarm?"
	}
}
def initialize() {
	subscribe(SmokeDetector, "smoke", p0)
	subscribe(SmokeDetector, "smoke", p1)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(SmokeDetector.smoke == "detected"){
		Alarm.strobe()
		sendSms(Phone, "Smoke is detected!")
	}
}
def p1(evt){
	if(SmokeDetector.smoke == "clear"){
		Alarm.off()
		sendSms(Phone, "Smoke is clear!")
	}
}