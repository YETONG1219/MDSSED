/* Automatically generated from UML model.*/
definition(
	name: "ConflictTimeandPresenceSensorEnhanced",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
}
def initialize() {
	subscribe(PresenceSensor, "presence", p0)
	schedule(60, "switchonAfter60")
	subscribe(PresenceSensor, "presence", p2)
	schedule(60000, "switchoffAfter60000")
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(PresenceSensor.presence == "present" && Switch.switch != "on"){
		Switch.on()
		sendSms(Phone, "The switch is on triggered by your presence.")
	}
}
def switchonAfter60(){
	if(PresenceSensor.presence == "present" && Switch.switch != "on"){
		Switch.on()
	}
}
def p2(evt){
	if(PresenceSensor.presence == "not present" && Switch.switch != "off"){
		Switch.off()
		sendSms(Phone, "An attacker can infer whether you are present according to the switch status. Please grant permissions carefully!")
	}
}
def switchoffAfter60000(){
	if(PresenceSensor.presence == "not present" && Switch.switch != "off"){
		Switch.off()
	}
}