/* Automatically generated from UML model.*/
definition(
	name: "Bundle4Enhanced",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
	section("Home mode..") {
		input "Location", "mode", title: "Mode?"
	}
    section("Controlling the ovenMode..") {
		input "OvenMode", "capability.ovenMode", title: "Which ovenMode?"
	}
    section("Controlling the smokeDetector..") {
		input "SmokeDetector", "capability.smokeDetector", title: "Which smokeDetector?"
	}
    section("Controlling the doorControl..") {
		input "DoorControl", "capability.doorControl", title: "Which doorControl?"
	}
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
    section("Controlling the contactSensor..") {
		input "ContactSensor", "capability.contactSensor", title: "Which contactSensor?"
	}
}
def initialize() {
	subscribe(Location, "mode", p0)
	subscribe(SmokeDetector, "smoke", p1)
	subscribe(PresenceSensor, "presence", p2)
	subscribe(PresenceSensor, "presence", p3)
	schedule(400, "doorControlopenAfter400")
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(Location.mode == "Home" && OvenMode.ovenMode != "heating"){
		OvenMode.setOvenMode("heating")
		sendSms(Phone, "An attacker can infer whether you are at home according to the mode of the oven. Please grant permissions carefully!")
	}
}
def p1(evt){
	if(SmokeDetector.smoke == "detected" && DoorControl.door != "open"){
		runIn(400, doorControlopenAfter400)
		sendSms(Phone, "The door is opened as the smoke detector has detected smoke.")
	}
}
def doorControlopenAfter400(){
	if(DoorControl.door != "open"){
		DoorControl.open()
	}
}
def p2(evt){
	if(PresenceSensor.presence == "present" && Location.mode != "Home"){
		Location.setLocationMode("Home")
	}
}
def p3(evt){
	if(PresenceSensor.presence == "not present" && Location.mode != "Away"){
		Location.setLocationMode("Away")
	}
}
def doorControlopenAfter400(){
	if(SmokeDetector.smoke == "detected" && DoorControl.door != "open"){
		DoorControl.open()
	}
}