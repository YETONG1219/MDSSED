/* Automatically generated from UML model.*/
definition(
	name: "Bundle4",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Home mode..") {
		input "Location", "mode", title: "Mode?"
	}
    section("Controlling the smokeDetector..") {
		input "SmokeDetector", "capability.smokeDetector", title: "Which smokeDetector?"
	}
    section("Controlling the contactSensor..") {
		input "ContactSensor", "capability.contactSensor", title: "Which contactSensor?"
	}
    section("Controlling the presenceSensor..") {
		input "PresenceSensor", "capability.presenceSensor", title: "Which presenceSensor?"
	}
    section("Controlling the ovenMode..") {
		input "OvenMode", "capability.ovenMode", title: "Which ovenMode?"
	}
    section("Controlling the doorControl..") {
		input "DoorControl", "capability.doorControl", title: "Which doorControl?"
	}
}
def initialize() {
	subscribe(Location, "mode", p0)
	subscribe(SmokeDetector, "smoke", p1)
	subscribe(PresenceSensor, "presence", p2)
	subscribe(PresenceSensor, "presence", p3)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(Location.mode == "Home"){
		OvenMode.setOvenMode("heating")
	}
}
def p1(evt){
	if(SmokeDetector.smoke == "detected" && ContactSensor.contact == "closed"){
		runIn(400, doorControlopenAfter400)
	}
}
def doorControlopenAfter400(){
	if(ContactSensor.contact == "closed"){
		DoorControl.open()
	}
}
def p2(evt){
	if(PresenceSensor.presence == "present"){
		Location.setLocationMode("Home")
	}
}
def p3(evt){
	if(PresenceSensor.presence == "not present"){
		Location.setLocationMode("Away")
	}
}