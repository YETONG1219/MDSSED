/* Automatically generated from UML model.*/
definition(
	name: "Bundle3Enhanced",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
    section("Controlling the smokeDetector..") {
		input "SmokeDetector", "capability.smokeDetector", title: "Which smokeDetector?"
	}
    section("Controlling the alarm..") {
		input "Alarm", "capability.alarm", title: "Which alarm?"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
	section("Home mode..") {
		input "Location", "mode", title: "Mode?"
	}
    section("Controlling the lock..") {
		input "Lock", "capability.lock", title: "Which lock?"
	}
}
def initialize() {
	subscribe(SmokeDetector, "smoke", p0)
	subscribe(SmokeDetector, "smoke", p1)
	subscribe(Switch, "switch", p2)
	subscribe(Location, "mode", p3)
	subscribe(SmokeDetector, "smoke", p4)
	subscribe(SmokeDetector, "smoke", p5)
	subscribe(SmokeDetector, "smoke", p7)
	subscribe(Location, "mode", p8)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(SmokeDetector.smoke == "detected" && Alarm.alarm != "siren" && Switch.switch != "on"){
		Alarm.siren()
		Switch.on()
	}
}
def p1(evt){
	if(SmokeDetector.smoke == "clear" && Alarm.alarm != "off"){
		Alarm.off()
	}
}
def p2(evt){
	if(Switch.switch == "on" && Location.mode != "Home"){
		Location.setLocationMode("Home")
		sendSms(Phone, "SmartThings changed your mode to 'Home', welcome back home!")
	}
}
def p3(evt){
	if(Location.mode == "Home" && Lock.lock != "locked"){
		Lock.lock()
		sendSms(Phone, "An attacker can infer whether you are at home according to the lock status. Please grant permissions carefully!")
	}
}
def p4(evt){
	if(SmokeDetector.smoke == "detected" && Alarm.alarm != "siren"){
		Alarm.siren()
	}
}
def p5(evt){
	if(SmokeDetector.smoke == "detected" && Switch.switch != "on"){
		Switch.on()
	}
}
def p7(evt){
	if(SmokeDetector.smoke == "clear" && Switch.switch != "off"){
		Switch.off()
	}
}
def p8(evt){
	if(Location.mode == "Home" && Switch.switch != "on"){
		Switch.on()
	}
}