/* Automatically generated from UML model.*/
definition(
	name: "PowerAllowanceEnhanced",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
	section("Send Notifications") {
		input "Phone", "phone", title: "Send a text message to:"
	}
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
}
def initialize() {
	subscribe(Switch, "switch", p0)
	subscribe(Switch, "switch", p1)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(Switch.switch == "on"){
		runIn(3600, switchoffAfter3600)
	}
}
def switchoffAfter3600(){
		state.switchoff = now()
		Switch.off()
}
def p1(evt){
	def time1 = state.switchoff
	if(Switch.switch == "on" && now() - time1 < 60){
		Switch.off()
		sendSms(Phone, "The switch was turned on immediately after being turned off.")
	}
}