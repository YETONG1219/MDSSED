/* Automatically generated from UML model.*/
definition(
	name: "PowerAllowance",
	namespace: "MDSSED",
	author: "MDSSED",
	description: "Safety and Security",
	category: "Safety & Security",
	iconUrl: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience.png",
	iconX2Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png",
	iconX3Url: "https://s3.amazonaws.com/smartapp-icons/Convenience/Cat-Convenience@2x.png"
)
preferences {
    section("Controlling the switch..") {
		input "Switch", "capability.switch", title: "Which switch?"
	}
}
def initialize() {
	subscribe(Switch, "switch", p0)
}
def installed() {
	initialize()
}
def updated() {
	unsubscribe()
	initialize()
}
def p0(evt){
	if(Switch.switch == "on"){
		runIn(3600, switchoffAfter3600)
	}
}
def switchoffAfter3600(){
		Switch.off()
}